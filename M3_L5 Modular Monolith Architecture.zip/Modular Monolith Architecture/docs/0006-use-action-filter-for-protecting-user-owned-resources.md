# 6. Use action filter for protecting user-owned resources

Date: 2025-07-15

## Status

Accepted

## Context

We need to implement a security strategy for protecting user-owned resources such as products, taxes, customers, and invoices. In a multi-tenant application where users should only access their own data, we need to ensure that authorization checks are consistently applied across all endpoints that operate on user-specific resources.

The main options considered were:

- **Action filters (Minimal API endpoint filters)**

  - ✅ Declarative and explicit - security is visible at the endpoint level
  - ✅ Reusable across different resource types through generics
  - ✅ Integrates well with Minimal API architecture
  - ✅ Centralized authorization logic in a single filter
  - ✅ Early termination - prevents unauthorized access before reaching business logic
  - ✅ Type-safe through generic constraints
  - ❌ Requires additional database query to verify ownership
  - ❌ Must be explicitly applied to each endpoint

- **Handling in use cases**

  - ✅ Business logic controls its own security
  - ✅ No additional database queries needed if already fetching the entity
  - ✅ Can provide more specific error messages
  - ❌ Security logic scattered across multiple use cases
  - ❌ Easy to forget to implement in new use cases
  - ❌ Inconsistent implementation across different features
  - ❌ Harder to audit and maintain security rules
  - ❌ Violates single responsibility principle

- **Global EF query filters**

  - ✅ Automatic filtering at the database level
  - ✅ Impossible to forget - always applied
  - ✅ No additional code needed in endpoints or use cases
  - ✅ Performance benefits - filtering happens in SQL
  - ❌ Hidden behavior - not obvious that filtering is happening
  - ❌ Difficult to debug when queries don't return expected results
  - ❌ Complex to implement with current user context injection
  - ❌ Can cause issues with administrative operations
  - ❌ Less flexible for different authorization scenarios

## Decision

We will use action filters (specifically Minimal API endpoint filters) for protecting user-owned resources.

The filter verifies that the authenticated user owns the requested resource by checking the `AppUserId` property against the current user's ID.

It returns appropriate HTTP status codes (401 for unauthenticated, 404 for not found, 403 for forbidden).

## Consequences

- Security requirements are clearly visible at the endpoint level, making it easy to audit which endpoints are protected.
- All user-owned resource endpoints use the same authorization logic, reducing the chance of security gaps.
- Generic constraints ensure the filter can only be applied to entities that implement `IUserOwnedResource`.
- Business logic in use cases remains focused on business rules, not security concerns.
- Unauthorized requests are blocked before reaching business logic, improving performance and security.
- Security logic is centralized in a single filter, making it easier to update or enhance.
- Each protected endpoint requires an additional database query to verify ownership, which may impact performance.
- Developers must remember to apply the filter to new endpoints, creating potential for human error.
- The filter assumes resource ID is available in the route as `{id}`, limiting flexibility in endpoint design.
