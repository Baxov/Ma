# 3. Use Docker

Date: 2025-02-21

## Status

Accepted

## Context

We need a consistent way to manage dependencies, simplify application deployment, and ensure that our application runs consistently across different environments.

The main options considered were:

- **Traditional deployment**

  - ✅ Simple and familiar
  - ❌ Environment inconsistencies
  - ❌ Complex dependency management
  - ❌ "Works on my machine" problems

- **Virtual machines**

  - ✅ Environment isolation
  - ❌ Resource overhead
  - ❌ Slow startup times
  - ❌ Large image sizes

- **Docker containerization**

  - ✅ Lightweight and portable
  - ✅ Consistent environments
  - ✅ Easy deployment and scaling
  - ✅ Simplified dependency management
  - ❌ Learning curve for team
  - ❌ Additional infrastructure complexity

## Decision

We will use Docker, a containerization platform that enables us to package our application and its dependencies into lightweight, portable containers. Docker containers are self-contained, easily shareable, and provide a consistent environment for our application regardless of the underlying infrastructure.

Our Docker setup includes:

- Multi-stage Dockerfiles for optimized builds
- Docker Compose for local development orchestration
- Separate containers for API, frontend, and database
- Development tools like Papercut SMTP and Adminer

## Consequences

- Containers encapsulate the application and its dependencies, making it easier to manage and maintain.
- Docker ensures that our application runs consistently across different environments (development, testing, and production) by packaging it with its runtime environment.
- Containers can be easily deployed to any environment that supports Docker, streamlining the deployment process and reducing potential deployment issues.
- Sharing Docker images or Dockerfiles allows team members to quickly set up their development environment with the correct dependencies and configurations.
- Developers may need time to learn Docker and its best practices.
- Introducing Docker adds another layer of complexity to our application infrastructure, which could potentially result in new challenges and issues.
- Build times may increase due to Docker layer creation and image building processes.
