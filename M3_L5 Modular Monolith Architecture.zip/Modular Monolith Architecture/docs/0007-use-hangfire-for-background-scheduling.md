# 7. Use Hangfire for background scheduling

Date: 2025-08-04

## Status

Accepted

## Context

We need to implement background job scheduling for various tasks in our application, including recurring invoice generation, due date reminders, and other time-based operations. A reliable background scheduling library is essential for handling these asynchronous tasks efficiently.

The main options considered were:

- **Hangfire**

  - ✅ Established and mature library with proven track record
  - ✅ Built-in dashboard for monitoring and managing jobs
  - ✅ Persistent job storage with SQL Server support
  - ✅ Automatic retry mechanisms and failure handling
  - ✅ Team has existing experience with the library
  - ✅ Comprehensive documentation and community support
  - ✅ Supports various job types (fire-and-forget, delayed, recurring)
  - ❌ Additional database overhead for job storage
  - ❌ Heavier footprint compared to simpler alternatives

- **Quartz.NET**

  - ✅ Lightweight and performant
  - ✅ Flexible scheduling capabilities
  - ✅ Good for complex scheduling scenarios
  - ✅ No additional database required for simple setups
  - ❌ More complex configuration and setup
  - ❌ Limited built-in monitoring capabilities
  - ❌ Requires more custom implementation for job persistence
  - ❌ Team has limited experience with the library

- **TickerQ**

  - ✅ Modern and lightweight approach
  - ✅ Potentially simpler API design
  - ✅ May offer better performance characteristics
  - ❌ New and unestablished library with limited adoption
  - ❌ Lack of proven track record in production environments
  - ❌ Limited documentation and community support
  - ❌ Unknown long-term maintenance and support
  - ❌ Team has no experience with the library

## Decision

We will use Hangfire for background job scheduling in our application.

The decision is primarily driven by the team's existing experience with Hangfire and its established reputation in the .NET ecosystem. Hangfire provides a comprehensive solution for background job processing with built-in persistence, monitoring, and retry mechanisms that align well with our requirements.

The library handles our key use cases including recurring invoice generation, due date reminder emails, and other time-sensitive operations that require reliable background processing.

## Consequences

- Reliable job execution with automatic retry mechanisms reduces the risk of missed scheduled tasks.
- Built-in dashboard provides visibility into job status and performance, making debugging and monitoring easier.
- Persistent job storage ensures jobs survive application restarts and server failures.
- Team's existing experience with Hangfire reduces learning curve and implementation time.
- Comprehensive documentation and community support provide resources for troubleshooting and advanced scenarios.
- Additional database overhead for job storage increases infrastructure complexity and resource usage.
- Heavier footprint compared to simpler alternatives may impact application startup time and memory usage.
- Dependency on an external library creates potential vendor lock-in and upgrade considerations.
- Dashboard security requires careful configuration to prevent unauthorized access in production environments.
