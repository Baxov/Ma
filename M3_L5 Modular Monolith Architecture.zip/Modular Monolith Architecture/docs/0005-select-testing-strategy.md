# 5. Select testing strategy

Date: 2025-03-24

## Status

Accepted

## Context

We need to decide on an effective testing strategy for our backend API to ensure the quality, reliability, and maintainability of our application.

The main options considered were:

- **Manual testing only**

  - ✅ Simple to start
  - ❌ Time-consuming and error-prone
  - ❌ Not scalable
  - ❌ No regression protection

- **Unit tests only**

  - ✅ Fast execution
  - ✅ Good for testing business logic
  - ❌ Limited coverage of integration scenarios
  - ❌ May miss system-level issues

- **Integration tests only**

  - ✅ Tests real system behavior
  - ✅ Catches integration issues
  - ❌ Slower execution
  - ❌ Harder to isolate failures

- **Combined unit and integration tests**
  - ✅ Comprehensive coverage
  - ✅ Fast feedback from unit tests
  - ✅ Confidence from integration tests
  - ❌ More complex test setup
  - ❌ Higher maintenance overhead

## Decision

We will adopt a testing strategy that combines both unit and integration tests for our backend API. This approach will allow us to validate individual components and their interactions within the system.

We will write unit tests to validate the behavior of individual components, such as classes and methods. These tests will be focused on the functionality of a single component, isolating it from external dependencies using techniques like mocking or stubbing.

We will write integration tests to validate the interactions between different components and subsystems, such as APIs, databases, and external services. These tests will verify that the various parts of our system work together correctly using real database containers and HTTP clients.

Our testing setup includes:

- `InvadePay.UnitTests`: Fast unit tests with SQLite in-memory database
- `InvadePay.ApiTests`: Integration tests with SQL Server containers using Testcontainers
- Refit for type-safe HTTP client testing
- Respawn for database cleanup between tests

## Consequences

- A robust testing strategy ensures that our code meets the desired functionality and adheres to established coding standards
- Regular testing helps identify and fix issues early in the development process, reducing the likelihood of defects making it to production
- A comprehensive test suite makes it easier to refactor code and add new features with confidence, ensuring that existing functionality is not inadvertently affected
- With a reliable test suite, developers can quickly identify and resolve issues, enabling more efficient development cycles and reducing the risk of introducing regressions
- Developers may need time to learn best practices for writing effective unit and integration tests
- As the codebase evolves, tests may need to be updated or refactored to remain relevant and effective
- Integration tests require more setup and may run slower than unit tests
- Test containers add complexity but provide realistic testing environments
