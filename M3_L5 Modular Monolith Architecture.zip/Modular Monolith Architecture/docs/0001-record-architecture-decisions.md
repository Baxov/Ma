# 1. Record architecture decisions

Date: 2025-02-21

## Status

Accepted

## Context

We need to record the architectural decisions made on this project and store it as close to code as possible.

There are a few the following options:

- Using a wiki (e.g., Confluence)
  - ✅ Easy to write and share
  - ❌ Too far removed from the codebase
- Using README files scattered across the repo
  - ✅ Close to code
  - ❌ Hard to keep consistent and discoverable
- Using Architecture Decision Records (ADR)
  - ✅ Close to code
  - ✅ Easy to write and share
  - ✅ Discoverable
  - ✅ Immutable

## Decision

We will use the concept of Architecture Decision Records (ARD).

Each ADR will be recorded using [Michael Nygard template](http://thinkrelevance.com/blog/2011/11/15/documenting-architecture-decisions), which contains following sections: Status, Context, Decision and Consequences.

## Consequences

- Every time new architecture decision comes in, it is required to add new architecture decision record.
- Existing architecture decision records are immutable. Whenever there is a need to update old record, a new one is created.
