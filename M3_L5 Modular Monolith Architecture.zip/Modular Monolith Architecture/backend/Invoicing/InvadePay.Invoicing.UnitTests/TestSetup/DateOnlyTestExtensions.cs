﻿using Shouldly;

namespace InvadePay.Invoicing.UnitTests.TestSetup;

public static class DateOnlyTestExtensions
{
    public static void ShouldBe(this DateOnly actual, DateOnly expected, string? customMessage = null)
    {
        actual.Equals(expected).ShouldBeTrue(customMessage ?? $"Expected {expected} but was {actual}");
    }

    public static void ShouldBe(this DateOnly? actual, DateOnly? expected, string? customMessage = null)
    {
        if (expected == null)
        {
            actual.ShouldBeNull(customMessage);
        }
        else
        {
            actual.ShouldNotBeNull(customMessage);
            actual.Value.Equals(expected.Value).ShouldBeTrue(customMessage ?? $"Expected {expected} but was {actual}");
        }
    }

    public static void ShouldBe(this DateOnly? actual, DateOnly expected, string? customMessage = null)
    {
        actual.ShouldNotBeNull(customMessage);
        actual.Value.Equals(expected).ShouldBeTrue(customMessage ?? $"Expected {expected} but was {actual}");
    }
}
