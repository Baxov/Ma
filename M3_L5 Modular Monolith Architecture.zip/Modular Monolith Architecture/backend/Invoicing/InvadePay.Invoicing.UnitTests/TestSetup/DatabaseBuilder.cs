﻿using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Infrastructure.Database;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.UnitTests.TestSetup;

public class DatabaseBuilder : IDisposable
{
    private readonly SqliteConnection _connection;
    private readonly InvoicingContext _context;
    private bool _disposed;

    public DatabaseBuilder()
    {
        _connection = new SqliteConnection("DataSource=:memory:");
        _connection.Open();

        var options = new DbContextOptionsBuilder<InvoicingContext>()
            .UseSqlite(_connection)
            .Options;

        _context = new InvoicingContext(options);
        _context.Database.EnsureCreated();
    }

    public IDbContext CreateDbContext()
    {
        // Reset database state
        _context.Database.EnsureDeleted();
        _context.Database.EnsureCreated();

        return _context;
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposed)
        {
            if (disposing)
            {
                _context.Dispose();
                _connection.Dispose();
            }

            _disposed = true;
        }
    }
}
