﻿using InvadePay.Common.Extensions;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Create;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;

namespace InvadePay.Invoicing.UnitTests.TestSetup;

public class RecurringInvoiceTestBuilder
{
    private string _appUserId = "test-user-id";
    private Customer? _customer;
    private RecurringFrequency _frequency = RecurringFrequency.Monthly;
    private DateOnly _startDate = DateOnlyCreator.Today().AddDays(1);
    private DateOnly? _endDate = DateOnlyCreator.Today().AddDays(90);
    private string _time = "17:00";
    private long? _taxId;
    private readonly List<RecurringInvoiceItem> _items = new();
    private bool _isActive = true;
    private string? _hangfireJobId;

    public static RecurringInvoiceTestBuilder Create() => new();

    public RecurringInvoiceTestBuilder WithAppUserId(string appUserId)
    {
        _appUserId = appUserId;
        return this;
    }

    public RecurringInvoiceTestBuilder WithCustomer(Customer customer)
    {
        _customer = customer;
        return this;
    }

    public RecurringInvoiceTestBuilder WithFrequency(RecurringFrequency frequency)
    {
        _frequency = frequency;
        return this;
    }

    public RecurringInvoiceTestBuilder WithStartDate(DateOnly startDate)
    {
        _startDate = startDate;
        return this;
    }

    public RecurringInvoiceTestBuilder WithEndDate(DateOnly? endDate)
    {
        _endDate = endDate;
        return this;
    }

    public RecurringInvoiceTestBuilder WithTime(string time)
    {
        _time = time;
        return this;
    }

    public RecurringInvoiceTestBuilder WithTaxId(long? taxId)
    {
        _taxId = taxId;
        return this;
    }

    public RecurringInvoiceTestBuilder WithItem(long productId, decimal quantity = 1.0m, decimal price = 100.0m, decimal? discount = null)
    {
        var item = new RecurringInvoiceItem
        {
            ProductId = productId,
            Quantity = quantity,
            Price = price,
            Discount = discount
        };
        _items.Add(item);
        return this;
    }

    public RecurringInvoiceTestBuilder WithIsActive(bool isActive)
    {
        _isActive = isActive;
        return this;
    }

    public RecurringInvoiceTestBuilder WithHangfireJobId(string? hangfireJobId)
    {
        _hangfireJobId = hangfireJobId;
        return this;
    }

    public RecurringInvoice Build()
    {
        var customer = _customer ?? CreateDefaultCustomer();

        var result = RecurringInvoice.Create(
            _appUserId,
            customer.Id,
            _frequency,
            _startDate,
            _endDate,
            _time,
            _taxId);

        if (result.IsError)
        {
            throw new InvalidOperationException($"Failed to create recurring invoice: {result.ErrorMessage}");
        }

        var recurringInvoice = result.Value;
        recurringInvoice.Items = _items;
        recurringInvoice.IsActive = _isActive;
        recurringInvoice.HangfireJobId = _hangfireJobId;
        return recurringInvoice;
    }

    public CreateRecurringInvoiceRequest BuildCreateRequest()
    {
        var customer = _customer ?? CreateDefaultCustomer();

        var items = _items.Select(i => new CreateRecurringInvoiceLineRequest(
            i.ProductId,
            i.Quantity,
            i.Price,
            i.Discount)).ToList();

        return new CreateRecurringInvoiceRequest(
            customer.Id,
            _time,
            _frequency.ToString(),
            _startDate,
            _endDate,
            items,
            _taxId);
    }

    private Customer CreateDefaultCustomer()
    {
        var customerResult = Customer.Create("Test Customer", "test@example.com", _appUserId);
        if (customerResult.IsError)
        {
            throw new InvalidOperationException($"Failed to create test customer: {customerResult.ErrorMessage}");
        }
        return customerResult.Value;
    }
}
