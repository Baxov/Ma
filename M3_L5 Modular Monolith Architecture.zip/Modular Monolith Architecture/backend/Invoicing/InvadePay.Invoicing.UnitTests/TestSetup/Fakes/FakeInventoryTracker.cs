﻿using InvadePay.Common.Models;
using InvadePay.Inventory.Contracts;

namespace InvadePay.Invoicing.UnitTests.TestSetup.Fakes;

public class FakeInventoryTracker : IInventoryTracker
{
    public Task<Result> ValidateStockAvailability(Dictionary<long, decimal> productQuantities, string appUserId)
    {
        return Task.FromResult(Result.Success());
    }

    public Task<Result> DeductStock(Dictionary<long, decimal> productQuantities, string appUserId)
    {
        return Task.FromResult(Result.Success());
    }

    public Task<Result> RestoreStock(Dictionary<long, decimal> productQuantities, string appUserId)
    {
        return Task.FromResult(Result.Success());
    }
}