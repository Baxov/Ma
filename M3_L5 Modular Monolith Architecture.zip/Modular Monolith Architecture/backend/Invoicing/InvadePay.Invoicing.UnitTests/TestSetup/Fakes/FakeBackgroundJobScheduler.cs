﻿using System.Linq.Expressions;
using InvadePay.Common.BackgroundJobs;

namespace InvadePay.Invoicing.UnitTests.TestSetup.Fakes;

public class FakeBackgroundJobScheduler: IBackgroundJobScheduler
{
    public TimeSpan Delay { get; set; }
    public DateTimeOffset EnqueueAt { get; set; }

    public string Schedule(Expression<Func<Task>> methodCall, TimeSpan delay)
    {
        CheckCalledMethodIsPublic(methodCall);
        Delay = delay;
        return "job-id";
    }

    public string Schedule(Expression<Func<Task>> methodCall, DateTimeOffset enqueueAt)
    {
        CheckCalledMethodIsPublic(methodCall);
        EnqueueAt = enqueueAt;
        return "job-id";
    }

    private static void CheckCalledMethodIsPublic(Expression<Func<Task>> methodCall)
    {
        if (methodCall.Body is MethodCallExpression methodCallExpression)
        {
            var methodInfo = methodCallExpression.Method;
            var isPublic = methodInfo.IsPublic;
            if (!isPublic)
            {
                ThrowSameExceptionAsHangfire();
            }
        }
    }

    public string Enqueue(Expression<Func<Task>> methodCall)
    {
        CheckCalledMethodIsPublic(methodCall);
        return "job-id";
    }

    private static void ThrowSameExceptionAsHangfire()
    {
        throw new NotSupportedException("Only public methods can be invoked in the background.");
    }
}
