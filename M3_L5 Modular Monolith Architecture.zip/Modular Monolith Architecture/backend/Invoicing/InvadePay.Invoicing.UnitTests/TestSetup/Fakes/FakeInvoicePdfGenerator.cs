﻿using InvadePay.Invoicing.Core.Features.Invoices.GeneratePdf;

namespace InvadePay.Invoicing.UnitTests.TestSetup.Fakes;

public class FakeInvoicePdfGenerator : IInvoicePdfGenerator
{
    public Task<byte[]> GeneratePdf(InvoicePdfData invoice)
    {
        return Task.FromResult("%PDF"u8.ToArray());
    }
}