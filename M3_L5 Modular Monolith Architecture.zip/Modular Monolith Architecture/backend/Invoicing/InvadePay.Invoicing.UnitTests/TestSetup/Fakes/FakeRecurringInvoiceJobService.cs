﻿using InvadePay.Invoicing.Core.Features.RecurringInvoices.Shared;

namespace InvadePay.Invoicing.UnitTests.TestSetup.Fakes;

public class FakeRecurringInvoiceJobService : IRecurringInvoiceJobService
{
    public List<long> ScheduledRecurringInvoiceIds { get; } = new();
    public List<string> UnscheduledHangfireJobIds { get; } = new();

    public Task ScheduleRecurringInvoice(long recurringInvoiceId)
    {
        ScheduledRecurringInvoiceIds.Add(recurringInvoiceId);
        return Task.CompletedTask;
    }

    public void UnscheduleRecurringInvoice(string hangfireJobId)
    {
        UnscheduledHangfireJobIds.Add(hangfireJobId);
    }
}
