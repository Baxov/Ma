﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;

namespace InvadePay.Invoicing.UnitTests.TestSetup.Fakes;

public class FakeInvoicingEmailSender : IInvoicingEmailSender
{
    public bool ShouldFail { get; set; } = false;
    public List<(string CustomerEmail, string CustomerName, string InvoiceNumber, byte[] PdfAttachment)> SentInvoiceEmails { get; } = new();
    public List<(string Email, string Name, string InvoiceNumber, DateTime DueDate)> SentReminders { get; } = new();

    public Task<Result> SendInvoiceEmail(string customerEmail, string customerName, string invoiceNumber, byte[] pdfAttachment)
    {
        if (ShouldFail)
        {
            return Task.FromResult<Result>(Result.Error("Email sending failed"));
        }

        SentInvoiceEmails.Add((customerEmail, customerName, invoiceNumber, pdfAttachment));
        return Task.FromResult(Result.Success());
    }

    public Task<Result> SendInvoiceDueDateReminderEmail(string customerEmail, string customerName, string invoiceNumber, DateTime dueDate)
    {
        SentReminders.Add((customerEmail, customerName, invoiceNumber, dueDate));
        return Task.FromResult(Result.Success());
    }
}
