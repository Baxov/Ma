﻿using InvadePay.Common.Extensions;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Customers.Delete;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using InvadePay.Invoicing.UnitTests.TestSetup;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.Invoicing.UnitTests.Customers;

public class DeleteCustomerUseCaseTests
{
    private static DeleteCustomerUseCase CreateUseCase(IDbContext dbContext)
    {
        return new DeleteCustomerUseCase(dbContext);
    }

    [Fact]
    public async Task Customer_deletion_fails_when_customer_is_not_found()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var nonExistentCustomerId = 999L;

        var result = await useCase.Execute(nonExistentCustomerId);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Customer_deletion_fails_when_customer_has_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(customer.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.Conflict);

        // Verify customer still exists
        var customerStillExists = await dbContext.Set<Customer>()
            .FirstOrDefaultAsync(x => x.Id == customer.Id);
        customerStillExists.ShouldNotBeNull();
    }

    [Fact]
    public async Task Customer_can_be_deleted_when_customer_exists_and_has_no_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(customer.Id);

        result.IsSuccess.ShouldBeTrue();
        
        var deletedCustomer = await dbContext.Set<Customer>()
            .FirstOrDefaultAsync(x => x.Id == customer.Id);
        deletedCustomer.ShouldBeNull();
    }
}
