﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.CompanySettings.Get;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.CompanySettings;
using InvadePay.Invoicing.UnitTests.TestSetup;
using Shouldly;

namespace InvadePay.Invoicing.UnitTests.CompanySettings;

public class CompanySettingsUseCaseTests
{
    private static CompanySettingsUseCase CreateUseCase(IDbContext dbContext)
    {
        return new CompanySettingsUseCase(dbContext);
    }

    [Fact]
    public async Task Existing_company_settings_can_be_retrieved()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var companySettings = Company.Create(
            "Test Company Ltd",
            "123 Test Street, Test City, TC 12345",
            "contact@testcompany.com",
            "test-user-id"
        ).Value;
        dbContext.Set<Company>().Add(companySettings);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var result = await useCase.Execute("test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Id.ShouldBe(companySettings.Id);
        result.Value.CompanyName.ShouldBe("Test Company Ltd");
        result.Value.Address.ShouldBe("123 Test Street, Test City, TC 12345");
        result.Value.Email.ShouldBe("contact@testcompany.com");
    }

    [Fact]
    public async Task Not_found_is_returned_when_no_company_settings_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var useCase = CreateUseCase(dbContext);

        var result = await useCase.Execute("test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
        result.ErrorMessage.ShouldBe("Company settings not found.");
    }

    [Fact]
    public async Task Only_company_settings_for_the_given_user_are_returned()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var companySettings1 = Company.Create(
            "User 1 Company",
            "User 1 Address",
            "user1@company.com",
            "user1-id"
        ).Value;
        
        var companySettings2 = Company.Create(
            "User 2 Company",
            "User 2 Address",
            "user2@company.com",
            "user2-id"
        ).Value;
        
        dbContext.Set<Company>().AddRange(companySettings1, companySettings2);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var result = await useCase.Execute("user1-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Id.ShouldBe(companySettings1.Id);
        result.Value.CompanyName.ShouldBe("User 1 Company");
        result.Value.Address.ShouldBe("User 1 Address");
        result.Value.Email.ShouldBe("user1@company.com");
    }
}
