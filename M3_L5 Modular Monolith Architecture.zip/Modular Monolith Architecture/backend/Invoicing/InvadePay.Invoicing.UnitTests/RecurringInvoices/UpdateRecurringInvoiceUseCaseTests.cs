﻿using InvadePay.Common.Extensions;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Update;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using InvadePay.Invoicing.UnitTests.TestSetup;
using InvadePay.Invoicing.UnitTests.TestSetup.Fakes;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.Invoicing.UnitTests.RecurringInvoices;

public class UpdateRecurringInvoiceUseCaseTests
{
    private static UpdateRecurringInvoiceUseCase CreateUseCase(IDbContext dbContext, FakeRecurringInvoiceJobService? jobService = null)
    {
        return new UpdateRecurringInvoiceUseCase(dbContext, jobService ?? new FakeRecurringInvoiceJobService());
    }

    [Fact]
    public async Task Recurring_invoice_is_updated_successfully_when_all_parameters_are_valid()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .WithFrequency(RecurringFrequency.Monthly)
            .WithStartDate(DateOnlyCreator.Today().AddDays(1))
            .WithEndDate(DateOnlyCreator.Today().AddDays(30))
            .WithIsActive(true)
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var newStartDate = DateOnlyCreator.Today().AddDays(5);
        var newEndDate = DateOnlyCreator.Today().AddDays(60);

        var request = new UpdateRecurringInvoiceRequest(
            "Weekly",
            newStartDate,
            newEndDate,
            false);

        var result = await useCase.Execute(recurringInvoice.Id, request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Id.ShouldBe(recurringInvoice.Id);
        result.Value.Frequency.ShouldBe("Weekly");
        result.Value.StartDate.ShouldBe(newStartDate);
        ShouldBeTestExtensions.ShouldBe(result.Value.EndDate, newEndDate);
        result.Value.IsActive.ShouldBeFalse();
        ShouldBeTestExtensions.ShouldBe(result.Value.NextRunDate, newStartDate);
    }

    [Fact]
    public async Task Updating_recurring_invoice_fails_when_it_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var useCase = CreateUseCase(dbContext);
        var request = new UpdateRecurringInvoiceRequest(
            "Weekly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            true);

        var result = await useCase.Execute(999L, request, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Updating_recurring_invoice_fails_when_it_belongs_to_different_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new UpdateRecurringInvoiceRequest(
            "Weekly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            true);

        var result = await useCase.Execute(recurringInvoice.Id, request, "other-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Updating_recurring_invoice_fails_when_frequency_is_invalid()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new UpdateRecurringInvoiceRequest(
            "invalidFrequency",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            true);

        var result = await useCase.Execute(recurringInvoice.Id, request, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.UnprocessableEntity);
        result.ErrorMessage.ShouldContain("Invalid frequency");
    }

    [Fact]
    public async Task Updating_recurring_invoice_can_change_frequency_to_different_values()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .WithFrequency(RecurringFrequency.Monthly)
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var quarterlyRequest = new UpdateRecurringInvoiceRequest(
            "Quarterly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(90),
            true);

        var quarterlyResult = await useCase.Execute(recurringInvoice.Id, quarterlyRequest, "test-user-id");
        quarterlyResult.IsSuccess.ShouldBeTrue();
        quarterlyResult.Value.Frequency.ShouldBe("Quarterly");
    }

    [Fact]
    public async Task Updating_recurring_invoice_can_remove_end_date()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .WithEndDate(DateOnlyCreator.Today().AddDays(30))
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new UpdateRecurringInvoiceRequest(
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            null,
            true);

        var result = await useCase.Execute(recurringInvoice.Id, request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.EndDate.ShouldBeNull();

        var updatedInvoice = await dbContext.Set<RecurringInvoice>()
            .FirstAsync(ri => ri.Id == recurringInvoice.Id);
        updatedInvoice.EndDate.ShouldBeNull();
    }

    [Fact]
    public async Task Updating_recurring_invoice_can_toggle_active_status()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .WithIsActive(true)
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var deactivateRequest = new UpdateRecurringInvoiceRequest(
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            false);

        var deactivateResult = await useCase.Execute(recurringInvoice.Id, deactivateRequest, "test-user-id");
        deactivateResult.IsSuccess.ShouldBeTrue();
        deactivateResult.Value.IsActive.ShouldBeFalse();
    }

    [Fact]
    public async Task Should_reschedule_job_when_updating_active_recurring_invoice()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .WithFrequency(RecurringFrequency.Monthly)
            .WithStartDate(DateOnlyCreator.Today().AddDays(1))
            .WithEndDate(DateOnlyCreator.Today().AddDays(30))
            .WithIsActive(true)
            .WithHangfireJobId("old-job-123")
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var newStartDate = DateOnlyCreator.Today().AddDays(5);
        var newEndDate = DateOnlyCreator.Today().AddDays(60);

        var request = new UpdateRecurringInvoiceRequest(
            "Weekly",
            newStartDate,
            newEndDate,
            true);

        var result = await useCase.Execute(recurringInvoice.Id, request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();

        // Should unschedule the old job
        jobService.UnscheduledHangfireJobIds.ShouldContain("old-job-123");

        // Should schedule a new job
        jobService.ScheduledRecurringInvoiceIds.ShouldContain(recurringInvoice.Id);
    }

    [Fact]
    public async Task Should_unschedule_job_when_deactivating_recurring_invoice()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .WithFrequency(RecurringFrequency.Monthly)
            .WithStartDate(DateOnlyCreator.Today().AddDays(1))
            .WithEndDate(DateOnlyCreator.Today().AddDays(30))
            .WithIsActive(true)
            .WithHangfireJobId("active-job-456")
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);

        var request = new UpdateRecurringInvoiceRequest(
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            false); // Deactivating

        var result = await useCase.Execute(recurringInvoice.Id, request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.IsActive.ShouldBeFalse();

        // Should unschedule the job
        jobService.UnscheduledHangfireJobIds.ShouldContain("active-job-456");

        // Should not schedule a new job since it's deactivated
        jobService.ScheduledRecurringInvoiceIds.ShouldNotContain(recurringInvoice.Id);
    }
}
