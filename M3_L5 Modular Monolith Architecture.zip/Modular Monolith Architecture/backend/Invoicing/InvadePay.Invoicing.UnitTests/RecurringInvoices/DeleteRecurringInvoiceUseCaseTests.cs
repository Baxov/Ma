﻿using InvadePay.Common.Extensions;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Delete;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using InvadePay.Invoicing.UnitTests.TestSetup;
using InvadePay.Invoicing.UnitTests.TestSetup.Fakes;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.Invoicing.UnitTests.RecurringInvoices;

public class DeleteRecurringInvoiceUseCaseTests
{
    private static DeleteRecurringInvoiceUseCase CreateUseCase(IDbContext dbContext, IRecurringInvoiceJobService jobService)
    {
        return new DeleteRecurringInvoiceUseCase(dbContext, jobService);
    }

    [Fact]
    public async Task Recurring_invoice_deletion_fails_when_recurring_invoice_not_found()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();
        var useCase = CreateUseCase(dbContext, jobService);

        var recurringInvoiceId = 999L;
        var appUserId = "user123";

        var result = await useCase.Execute(recurringInvoiceId, appUserId);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Recurring_invoice_is_deleted_successfully_when_it_exists_and_has_hangfire_job()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();
        var useCase = CreateUseCase(dbContext, jobService);

        var customer = new Customer { Name = "Test Customer", Email = "test@example.com", AppUserId = "test-user-id" };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var hangfireJobId = "job123";
        var recurringInvoiceResult = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            DateOnlyCreator.Today(),
            null,
            "17:00");

        var recurringInvoice = recurringInvoiceResult.Value;
        recurringInvoice.HangfireJobId = hangfireJobId;

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(recurringInvoice.Id, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        jobService.UnscheduledHangfireJobIds.ShouldContain(hangfireJobId);

        var deletedInvoice = await dbContext.Set<RecurringInvoice>()
            .FirstOrDefaultAsync(x => x.Id == recurringInvoice.Id);
        deletedInvoice.ShouldBeNull();
    }
}
