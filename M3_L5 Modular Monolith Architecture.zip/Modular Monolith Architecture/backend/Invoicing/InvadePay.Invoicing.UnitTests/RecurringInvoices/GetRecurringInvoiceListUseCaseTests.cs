﻿using InvadePay.Common.Extensions;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.GetList;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using InvadePay.Invoicing.UnitTests.TestSetup;
using Shouldly;

namespace InvadePay.Invoicing.UnitTests.RecurringInvoices;

public class GetRecurringInvoiceListUseCaseTests
{
    private static GetRecurringInvoiceListUseCase CreateUseCase(IDbContext dbContext)
    {
        return new GetRecurringInvoiceListUseCase(dbContext);
    }

    [Fact]
    public async Task Recurring_invoice_list_is_retrieved_successfully_when_user_has_recurring_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoice1 = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .WithFrequency(RecurringFrequency.Monthly)
            .Build();

        var recurringInvoice2 = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .WithFrequency(RecurringFrequency.Weekly)
            .Build();

        dbContext.Set<RecurringInvoice>().AddRange(recurringInvoice1, recurringInvoice2);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(1, 10, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Items.Count.ShouldBe(2);
        result.Value.TotalCount.ShouldBe(2);
        result.Value.Page.ShouldBe(1);
        result.Value.PageSize.ShouldBe(10);

        var firstInvoice = result.Value.Items.First();
        firstInvoice.CustomerName.ShouldBe("Test Customer");
        firstInvoice.CustomerEmail.ShouldBe("customer@test.com");
        firstInvoice.IsActive.ShouldBeTrue();
    }

    [Fact]
    public async Task Recurring_invoice_list_returns_empty_when_user_has_no_recurring_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(1, 10, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Items.ShouldBeEmpty();
        result.Value.TotalCount.ShouldBe(0);
        result.Value.Page.ShouldBe(1);
        result.Value.PageSize.ShouldBe(10);
    }

    [Fact]
    public async Task Recurring_invoice_list_only_returns_invoices_for_current_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customer1Result = Customer.Create("Customer 1", "customer1@test.com", "test-user-id");
        var customer1 = customer1Result.Value;
        var customer2Result = Customer.Create("Customer 2", "customer2@test.com", "other-user-id");
        var customer2 = customer2Result.Value;
        dbContext.Set<Customer>().AddRange(customer1, customer2);

        await dbContext.SaveChangesAsync();

        var recurringInvoice1 = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer1)
            .WithItem(1)
            .Build();

        var recurringInvoice2 = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("other-user-id")
            .WithCustomer(customer2)
            .WithItem(2)
            .Build();

        dbContext.Set<RecurringInvoice>().AddRange(recurringInvoice1, recurringInvoice2);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(1, 10, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Items.Count.ShouldBe(1);
        result.Value.Items.First().CustomerName.ShouldBe("Customer 1");
    }

    [Fact]
    public async Task Recurring_invoice_list_supports_pagination()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoices = new List<RecurringInvoice>();
        for (var i = 0; i < 5; i++)
        {
            var recurringInvoice = RecurringInvoiceTestBuilder.Create()
                .WithAppUserId("test-user-id")
                .WithCustomer(customer)
                .WithItem(1)
                .Build();
            recurringInvoices.Add(recurringInvoice);
        }

        dbContext.Set<RecurringInvoice>().AddRange(recurringInvoices);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var firstPageResult = await useCase.Execute(1, 2, "test-user-id");
        firstPageResult.IsSuccess.ShouldBeTrue();
        firstPageResult.Value.Items.Count.ShouldBe(2);
        firstPageResult.Value.TotalCount.ShouldBe(5);
        firstPageResult.Value.Page.ShouldBe(1);
        firstPageResult.Value.PageSize.ShouldBe(2);

        var secondPageResult = await useCase.Execute(2, 2, "test-user-id");
        secondPageResult.IsSuccess.ShouldBeTrue();
        secondPageResult.Value.Items.Count.ShouldBe(2);
        secondPageResult.Value.TotalCount.ShouldBe(5);
        secondPageResult.Value.Page.ShouldBe(2);
        secondPageResult.Value.PageSize.ShouldBe(2);

        var thirdPageResult = await useCase.Execute(3, 2, "test-user-id");
        thirdPageResult.IsSuccess.ShouldBeTrue();
        thirdPageResult.Value.Items.Count.ShouldBe(1);
        thirdPageResult.Value.TotalCount.ShouldBe(5);
        thirdPageResult.Value.Page.ShouldBe(3);
        thirdPageResult.Value.PageSize.ShouldBe(2);
    }

    [Fact]
    public async Task Recurring_invoice_list_shows_correct_frequency_and_dates()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var startDate = DateOnlyCreator.Today().AddDays(5);
        var endDate = DateOnlyCreator.Today().AddDays(35);

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .WithFrequency(RecurringFrequency.Quarterly)
            .WithStartDate(startDate)
            .WithEndDate(endDate)
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(1, 10, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        var invoice = result.Value.Items.First();
        invoice.Frequency.ShouldBe("Quarterly");
        invoice.StartDate.ShouldBe(startDate);
        ShouldBeTestExtensions.ShouldBe(invoice.EndDate, endDate);
        ShouldBeTestExtensions.ShouldBe(invoice.NextRunDate, startDate);
    }
}
