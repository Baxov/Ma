﻿using InvadePay.Common.Extensions;
using InvadePay.Common.Models;
using InvadePay.Inventory.Contracts;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Create;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using InvadePay.Invoicing.UnitTests.TestSetup;
using InvadePay.Invoicing.UnitTests.TestSetup.Fakes;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.Invoicing.UnitTests.RecurringInvoices;

public class FakeProductDetailsHandler() : IProductDetailsHandler
{
    private readonly List<ProductDetailsResponse> _products = new();
    
    public void AddProduct(ProductDetailsResponse product)
    {
        _products.Add(product);
    }

    public Task<Result<List<ProductDetailsResponse>>> GetMultipleProducts(IEnumerable<long> productIds, string userId)
    {
        return Task.FromResult(Result<List<ProductDetailsResponse>>.Success(_products.Where(p => productIds.Contains(p.Id)).ToList()));
    }
}

public class CreateRecurringInvoiceUseCaseTests
{
    private static CreateRecurringInvoiceUseCase CreateUseCase(IDbContext dbContext, IRecurringInvoiceJobService jobService, FakeProductDetailsHandler? productDetailsHandler = null)
    {
        productDetailsHandler ??= CreateFakeProductDetailsHandler();
        return new CreateRecurringInvoiceUseCase(dbContext, jobService, new InvoiceValidator(dbContext, productDetailsHandler));
    }

    private static FakeProductDetailsHandler CreateFakeProductDetailsHandler()
    {
        var handler = new FakeProductDetailsHandler();
        // Add default products that tests use
        handler.AddProduct(new ProductDetailsResponse
        {
            Id = 1,
            Name = "Test Product 1",
            DefaultPrice = 100.0m,
            UnitOfMeasure = "Unit",
            StockQuantity = 100,
            TrackInventory = false
        });
        handler.AddProduct(new ProductDetailsResponse
        {
            Id = 2,
            Name = "Test Product 2",
            DefaultPrice = 200.0m,
            UnitOfMeasure = "Unit",
            StockQuantity = 100,
            TrackInventory = false
        });
        return handler;
    }

    [Fact]
    public async Task Recurring_invoice_is_created_successfully_when_all_parameters_are_valid()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = RecurringInvoiceTestBuilder.Create()
            .WithCustomer(customer)
            .WithItem(1, 2.0m, 50.0m, 10.0m)
            .BuildCreateRequest();

        var result = await useCase.Execute(request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Id.ShouldBeGreaterThan(0);
        result.Value.CustomerName.ShouldBe("Test Customer");
        result.Value.CustomerEmail.ShouldBe("customer@test.com");
        result.Value.Frequency.ShouldBe("Monthly");
        result.Value.IsActive.ShouldBeTrue();
        result.Value.NextRunDate.ShouldNotBeNull();

        jobService.ScheduledRecurringInvoiceIds.ShouldContain(result.Value.Id);

        var savedRecurringInvoice = await dbContext.Set<RecurringInvoice>()
            .Include(ri => ri.Items)
            .FirstAsync(ri => ri.Id == result.Value.Id);

        savedRecurringInvoice.Items.Count.ShouldBe(1);
        savedRecurringInvoice.Items.First().Quantity.ShouldBe(2.0m);
        savedRecurringInvoice.Items.First().Price.ShouldBe(50.0m);
        savedRecurringInvoice.Items.First().Discount.ShouldBe(10.0m);
    }

    [Fact]
    public async Task Creating_recurring_invoice_fails_when_customer_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            999L,
            "17:00",
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            []);

        var result = await useCase.Execute(request, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
        result.ErrorMessage.ShouldBe("Customer with id 999 was not found.");

        jobService.ScheduledRecurringInvoiceIds.ShouldBeEmpty();
    }

    [Fact]
    public async Task Creating_recurring_invoice_fails_when_customer_belongs_to_different_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            customer.Id,
            "17:00",
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            []);

        var result = await useCase.Execute(request, "other-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Creating_recurring_invoice_fails_when_frequency_is_invalid()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            customer.Id,
            "17:00",
            "invalidFrequency",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            []);

        var result = await useCase.Execute(request, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.UnprocessableEntity);
        result.ErrorMessage.ShouldContain("Invalid frequency");
    }

    [Fact]
    public async Task Creating_recurring_invoice_fails_when_product_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            customer.Id,
            "17:00",
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            [
                new(999L, 1.0m, 100.0m)
            ]);

        var result = await useCase.Execute(request, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
        result.ErrorMessage.ShouldContain("Products with ids 999 were not found");
    }

    [Fact]
    public async Task Creating_recurring_invoice_fails_when_tax_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            customer.Id,
            "17:00",
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            [
                new(1, 1.0m, 100.0m)
            ],
            999L);

        var result = await useCase.Execute(request, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
        result.ErrorMessage.ShouldContain("Tax");
    }

    [Fact]
    public async Task Creating_recurring_invoice_with_multiple_items_succeeds()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            customer.Id,
            "17:00",
            "Weekly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            [
                new(1, 2.0m, 100.0m, 5.0m),
                new(2, 1.0m, 200.0m, null)
            ]);

        var result = await useCase.Execute(request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();

        var savedRecurringInvoice = await dbContext.Set<RecurringInvoice>()
            .Include(ri => ri.Items)
            .FirstAsync(ri => ri.Id == result.Value.Id);

        savedRecurringInvoice.Items.Count.ShouldBe(2);
        savedRecurringInvoice.Frequency.ShouldBe(RecurringFrequency.Weekly);

        jobService.ScheduledRecurringInvoiceIds.ShouldContain(result.Value.Id);
    }
    
    
    [Theory]
    [InlineData("Weekly")]
    [InlineData("Monthly")]
    [InlineData("Quarterly")]
    [InlineData("Yearly")]
    public async Task Create_recurring_invoice_supports_all_frequency_types(string frequency)
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            customer.Id,
            "17:00",
            frequency,
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            [
                new(1, 1.0m, 100.0m)
            ]);

        var result = await useCase.Execute(request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Frequency.ShouldBe(frequency);
    }
}
