﻿using InvadePay.Common.Models;
using InvadePay.Inventory.Contracts;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.GetById;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using InvadePay.Invoicing.UnitTests.TestSetup;
using Shouldly;

namespace InvadePay.Invoicing.UnitTests.RecurringInvoices;

public class GetRecurringInvoiceByIdUseCaseTests
{
    private static GetRecurringInvoiceByIdUseCase CreateUseCase(IDbContext dbContext, IProductDetailsHandler? productDetailsHandler = null)
    {
        productDetailsHandler ??= CreateFakeProductDetailsHandler();
        return new GetRecurringInvoiceByIdUseCase(dbContext, productDetailsHandler);
    }

    private static FakeProductDetailsHandler CreateFakeProductDetailsHandler()
    {
        var handler = new FakeProductDetailsHandler();
        handler.AddProduct(new ProductDetailsResponse
        {
            Id = 1,
            Name = "Test Product 1",
            DefaultPrice = 50.0m,
            UnitOfMeasure = "Unit",
            StockQuantity = 100,
            TrackInventory = false
        });
        handler.AddProduct(new ProductDetailsResponse
        {
            Id = 2,
            Name = "Test Product 2",
            DefaultPrice = 200.0m,
            UnitOfMeasure = "Unit",
            StockQuantity = 100,
            TrackInventory = false
        });
        return handler;
    }

    [Fact]
    public async Task Recurring_invoice_is_retrieved_successfully_when_it_exists()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1, 2.0m, 50.0m, 10.0m)
            .WithFrequency(RecurringFrequency.Weekly)
            .WithTime("09:30")
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(recurringInvoice.Id, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Id.ShouldBe(recurringInvoice.Id);
        result.Value.CustomerName.ShouldBe("Test Customer");
        result.Value.CustomerEmail.ShouldBe("customer@test.com");
        result.Value.Time.ShouldBe("09:30");
        result.Value.Frequency.ShouldBe("Weekly");
        result.Value.IsActive.ShouldBeTrue();
        result.Value.Items.Count.ShouldBe(1);

        var item = result.Value.Items.First();
        item.ProductName.ShouldBe("Test Product 1");
        item.Quantity.ShouldBe(2.0m);
        item.Price.ShouldBe(50.0m);
        item.Discount.ShouldBe(10.0m);
        item.Total.ShouldBe(90.0m);
    }

    [Fact]
    public async Task Recurring_invoice_is_retrieved_with_tax_information_when_tax_is_assigned()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        var taxResult = Tax.Create("VAT", "Value Added Tax", 20.0m, "test-user-id");
        var tax = taxResult.Value;
        dbContext.Set<Tax>().Add(tax);

        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .WithTaxId(tax.Id)
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(recurringInvoice.Id, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.TaxId.ShouldBe(tax.Id);
        result.Value.TaxName.ShouldBe("VAT");
        result.Value.TaxRate.ShouldBe(20.0m);
    }

    [Fact]
    public async Task Getting_recurring_invoice_fails_when_it_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(999L, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Getting_recurring_invoice_fails_when_it_belongs_to_different_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1)
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(recurringInvoice.Id, "other-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Recurring_invoice_with_multiple_items_is_retrieved_correctly()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customerResult = Customer.Create("Test Customer", "customer@test.com", "test-user-id");
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId("test-user-id")
            .WithCustomer(customer)
            .WithItem(1, 2.0m, 100.0m, 5.0m)
            .WithItem(2, 1.0m, 200.0m, null)
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(recurringInvoice.Id, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Items.Count.ShouldBe(2);

        var item1 = result.Value.Items.First(i => i.ProductId == 1);
        item1.Quantity.ShouldBe(2.0m);
        item1.Price.ShouldBe(100.0m);
        item1.Discount.ShouldBe(5.0m);
        item1.Total.ShouldBe(190.0m);

        var item2 = result.Value.Items.First(i => i.ProductId == 2);
        item2.Quantity.ShouldBe(1.0m);
        item2.Price.ShouldBe(200.0m);
        item2.Discount.ShouldBeNull();
        item2.Total.ShouldBe(200.0m);
    }
}
