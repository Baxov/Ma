﻿using InvadePay.Common.Extensions;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Invoices.Create;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using InvadePay.Invoicing.UnitTests.RecurringInvoices;
using InvadePay.Invoicing.UnitTests.TestSetup;
using InvadePay.Invoicing.UnitTests.TestSetup.Fakes;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.Invoicing.UnitTests.Invoices;

public class CreateInvoiceUseCaseTests
{
    [Fact]
    public async Task Invoice_creation_fails_when_product_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = "test-user-id" };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnly.FromDateTime(DateTime.Today),
            DueDate: DateOnly.FromDateTime(DateTime.Today.AddDays(30)),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(
                    ProductId: 9999,
                    Quantity: 1,
                    Price: 100.00m,
                    Discount: 0m
                )
            }
        );

        var result = await useCase.Execute(request, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }
    
    [Fact]
    public async Task Invoice_creation_fails_when_customer_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var useCase = CreateUseCase(dbContext);

        var request = new CreateInvoiceRequest(
            CustomerId: 9999, // Non-existent customer
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(
                    ProductId: 1,
                    Quantity: 1,
                    Price: 100.00m,
                    Discount: 0m
                )
            }
        );

        var result = await useCase.Execute(request, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
        result.ErrorMessage.ShouldContain("Customer with id 9999 was not found");
    }

    [Fact]
    public async Task Invoice_creation_creates_new_invoice()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = "test-user-id" };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(
                    ProductId: 1,
                    Quantity: 1,
                    Price: 100.00m,
                    Discount: 0m
                )
            }
        );

        var result = await useCase.Execute(request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        var invoice = await dbContext.Set<Invoice>().FirstOrDefaultAsync(x => x.Id == result.Value.Id);
        invoice.ShouldNotBeNull();
        invoice!.CustomerId.ShouldBe(customer.Id);
        invoice.Date.ShouldBe(request.Date);
        invoice.Items.Count.ShouldBe(1);
        var firstItem = request.Items.First();
        invoice.Items.First().Price.ShouldBe(firstItem.Price);
        invoice.Items.First().Quantity.ShouldBe(firstItem.Quantity);
        invoice.Items.First().Discount.ShouldBe(firstItem.Discount);
        invoice.Items.First().ProductId.ShouldBe(firstItem.ProductId);
        invoice.AppUserId.ShouldBe("test-user-id");
        invoice.InvoiceNumber.ShouldBeGreaterThan(0);
        invoice.Status.ShouldBe(InvoiceStatus.Draft);
        invoice.Time.ShouldBe(request.Time);
    }

    [Fact]
    public async Task Invoice_creation_assigns_next_invoice_number()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        dbContext.Set<Customer>().Add(new Customer
        {
            Name = "John Doe",
            Email = "john@example.com",
            AppUserId = "test-user-id"
        });

        var customer = Customer.Create("Test Customer", "test@example.com", "test-user-id").Value;
        dbContext.Set<Customer>().Add(customer);

        // Save customer first to get their IDs
        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var request = new CreateInvoiceRequest(
            CustomerId: 1, // Use the customer we created above
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(
                    ProductId: 1,
                    Quantity: 1,
                    Price: 100.00m,
                    Discount: 0m
                )
            }
        );

        var result = await useCase.Execute(request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.InvoiceId.ShouldBe("2-1-1");
    }

    [Fact]
    public async Task Invoice_creation_supports_multiple_invoice_lines()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = "test-user-id" };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(
                    ProductId: 1,
                    Quantity: 2,
                    Price: 1000.00m,
                    Discount: 10.00m
                ),
                new(
                    ProductId: 2,
                    Quantity: 1,
                    Price: 50.00m,
                    Discount: 0m
                )
            }
        );

        var result = await useCase.Execute(request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        var invoice = await dbContext.Set<Invoice>().FirstOrDefaultAsync(x => x.Id == result.Value.Id);
        invoice.ShouldNotBeNull();
        invoice!.Items.Count.ShouldBe(2);

        var firstItem = invoice.Items.First(i => i.ProductId == 1);
        firstItem.Quantity.ShouldBe(2);
        firstItem.Price.ShouldBe(1000.00m);
        firstItem.Discount.ShouldBe(10.00m);

        var secondItem = invoice.Items.First(i => i.ProductId == 2);
        secondItem.Quantity.ShouldBe(1);
        secondItem.Price.ShouldBe(50.00m);
        secondItem.Discount.ShouldBe(0m);

        result.Value.TotalAmount.ShouldBe(1850.00m);
    }

    [Fact]
    public async Task Invoice_creation_calculates_tax_correctly_with_single_item()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = "test-user-id" };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, "test-user-id").Value;
        dbContext.Set<Tax>().Add(tax);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(ProductId: 1, Quantity: 1, Price: 100.00m, Discount: 0m)
            },
            TaxId: tax.Id
        );

        var result = await useCase.Execute(request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.SubtotalAmount.ShouldBe(100.00m);
        result.Value.TaxAmount.ShouldBe(20.00m);
        result.Value.TotalAmount.ShouldBe(120.00m);
        result.Value.TaxId.ShouldBe(tax.Id);
        result.Value.TaxName.ShouldBe("VAT");
        result.Value.TaxRate.ShouldBe(20.0m);
    }

    [Fact]
    public async Task Invoice_creation_calculates_tax_correctly_with_multiple_items()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = "test-user-id" };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var tax = Tax.Create("VAT", "Value Added Tax", 10.0m, "test-user-id").Value;
        dbContext.Set<Tax>().Add(tax);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(ProductId: 1, Quantity: 2, Price: 500.00m, Discount: 0m),
                new(ProductId: 2, Quantity: 1, Price: 30.00m, Discount: 0m)
            },
            TaxId: tax.Id
        );

        var result = await useCase.Execute(request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.SubtotalAmount.ShouldBe(1030.00m);
        result.Value.TaxAmount.ShouldBe(103.00m);
        result.Value.TotalAmount.ShouldBe(1133.00m);
    }

    [Fact]
    public async Task Invoice_creation_calculates_tax_correctly_with_discounts()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = "test-user-id" };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, "test-user-id").Value;
        dbContext.Set<Tax>().Add(tax);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(ProductId: 1, Quantity: 1, Price: 100.00m, Discount: 10.0m)
            },
            TaxId: tax.Id
        );

        var result = await useCase.Execute(request, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.SubtotalAmount.ShouldBe(90.00m);
        result.Value.TaxAmount.ShouldBe(18.00m);
        result.Value.TotalAmount.ShouldBe(108.00m);
    }
    
    [Fact]
    public async Task Invoice_creation_fails_when_tax_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = "test-user-id" };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(ProductId: 1, Quantity: 1, Price: 100.00m, Discount: 0m)
            },
            TaxId: 999 // Non-existent tax ID
        );

        var result = await useCase.Execute(request, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Tax with id 999 was not found.");
    }

    [Fact]
    public async Task Invoice_creation_fails_when_tax_belongs_to_different_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = "test-user-id" };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var userTwoTax = Tax.Create("VAT", "Value Added Tax", 20.0m, "other-user-id").Value;
        dbContext.Set<Tax>().Add(userTwoTax);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items:
            [
                new(ProductId: 1, Quantity: 1, Price: 100.00m, Discount: 0m)
            ],
            TaxId: userTwoTax.Id
        );

        var result = await useCase.Execute(request, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }
    
    private static CreateInvoiceUseCase CreateUseCase(IDbContext dbContext, FakeProductDetailsHandler? productDetailsHandler = null)
    {
        productDetailsHandler ??= CreateFakeProductDetailsHandler();
        return new CreateInvoiceUseCase(dbContext, new FakeInventoryTracker(), new InvoiceValidator(dbContext, productDetailsHandler));
    }

    private static FakeProductDetailsHandler CreateFakeProductDetailsHandler()
    {
        var handler = new FakeProductDetailsHandler();
        // Add default products that tests use
        handler.AddProduct(new Inventory.Contracts.ProductDetailsResponse
        {
            Id = 1,
            Name = "Test Product 1",
            DefaultPrice = 100.0m,
            UnitOfMeasure = "Unit",
            StockQuantity = 100,
            TrackInventory = false
        });
        handler.AddProduct(new Inventory.Contracts.ProductDetailsResponse
        {
            Id = 2,
            Name = "Test Product 2",
            DefaultPrice = 200.0m,
            UnitOfMeasure = "Unit",
            StockQuantity = 100,
            TrackInventory = false
        });
        return handler;
    }
}