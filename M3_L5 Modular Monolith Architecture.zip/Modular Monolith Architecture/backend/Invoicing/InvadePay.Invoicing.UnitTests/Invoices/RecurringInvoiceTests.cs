﻿using InvadePay.Common.Extensions;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using Shouldly;
using DateOnlyTestExtensions = InvadePay.Invoicing.UnitTests.TestSetup.DateOnlyTestExtensions;

namespace InvadePay.Invoicing.UnitTests.Invoices;

public class RecurringInvoiceTests
{
    private static Customer CreateTestCustomer()
    {
        var customerResult = Customer.Create("Test Customer", "test@example.com", "test-user-id");
        return customerResult.Value;
    }

    [Fact]
    public void Recurring_invoice_is_created_when_all_parameters_are_valid()
    {
        var customer = CreateTestCustomer();
        customer.Id = 1;
        var startDate = DateOnlyCreator.Today().AddDays(1);
        var endDate = DateOnlyCreator.Today().AddDays(30);

        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            startDate,
            endDate,
            "17:00");

        result.IsSuccess.ShouldBeTrue();
        result.Value.AppUserId.ShouldBe("test-user-id");
        result.Value.CustomerId.ShouldBe(customer.Id);
        result.Value.Frequency.ShouldBe(RecurringFrequency.Monthly);
        result.Value.StartDate.ShouldBe(startDate);
        result.Value.EndDate.ShouldBe(endDate);
        result.Value.Time.ShouldBe("17:00");
        result.Value.IsActive.ShouldBeTrue();
        result.Value.NextRunDate.ShouldBe(startDate);
    }

    [Fact]
    public void Recurring_invoice_is_created_when_end_date_is_not_provided()
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(1);

        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Weekly,
            startDate,
            null,
            "09:00");

        result.IsSuccess.ShouldBeTrue();
        result.Value.EndDate.ShouldBeNull();
        result.Value.NextRunDate.ShouldBe(startDate);
    }

    [Fact]
    public void Recurring_invoice_is_created_with_tax_id_when_provided()
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(1);
        var taxId = 123L;

        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Quarterly,
            startDate,
            null,
            "12:30",
            taxId);

        result.IsSuccess.ShouldBeTrue();
        result.Value.TaxId.ShouldBe(taxId);
    }

    [Fact]
    public void Recurring_invoice_is_not_created_when_start_date_is_in_the_past()
    {
        var customer = CreateTestCustomer();
        var pastDate = DateOnlyCreator.Today().AddDays(-1);

        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            pastDate,
            null,
            "17:00");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Start date cannot be in the past.");
    }

    [Fact]
    public void Recurring_invoice_is_not_created_when_end_date_is_before_start_date()
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(10);
        var endDate = DateOnlyCreator.Today().AddDays(5);

        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            startDate,
            endDate,
            "17:00");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("End date must be after start date.");
    }

    [Fact]
    public void Recurring_invoice_is_not_created_when_end_date_equals_start_date()
    {
        var customer = CreateTestCustomer();
        var date = DateOnlyCreator.Today().AddDays(1);

        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            date,
            date,
            "17:00");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("End date must be after start date.");
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("\t")]
    [InlineData("\n")]
    public void Recurring_invoice_is_not_created_when_app_user_id_is_null_or_whitespace(string invalidAppUserId)
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(1);

        var result = RecurringInvoice.Create(
            invalidAppUserId,
            customer.Id,
            RecurringFrequency.Monthly,
            startDate,
            null,
            "17:00");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.Error);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("\t")]
    [InlineData("\n")]
    public void Recurring_invoice_is_not_created_when_time_is_null_or_whitespace(string invalidTime)
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(1);

        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            startDate,
            null,
            invalidTime);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.Error);
    }

    [Fact]
    public void Recurring_invoice_is_created_when_start_date_is_today()
    {
        var customer = CreateTestCustomer();
        var today = DateOnlyCreator.Today();

        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            today,
            null,
            "17:00");

        result.IsSuccess.ShouldBeTrue();
        result.Value.StartDate.ShouldBe(today);
    }

    [Fact]
    public void Next_run_date_is_set_to_start_date_for_first_run()
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(1);

        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            startDate,
            null,
            "17:00");

        result.IsSuccess.ShouldBeTrue();

        // First run should be on the start date
        result.Value.NextRunDate.ShouldBe(startDate);
    }

    [Fact]
    public void After_first_run_next_run_date_is_calculated_correctly()
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(1);

        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            startDate,
            null,
            "17:00");

        result.IsSuccess.ShouldBeTrue();
        var recurringInvoice = result.Value;

        // First run should be on the start date
        recurringInvoice.NextRunDate.ShouldBe(startDate);

        // After processing, next run should be calculated from the start date
        recurringInvoice.MarkAsProcessed();
        recurringInvoice.NextRunDate.ShouldBe(startDate.AddMonths(1));
    }

    [Fact]
    public void Update_schedule_changes_frequency_start_date_end_date_and_recalculates_next_run_date()
    {
        var customer = CreateTestCustomer();
        var originalStartDate = DateOnlyCreator.Today().AddDays(1);
        
        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            originalStartDate,
            null,
            "17:00");

        var recurringInvoice = result.Value;
        var newStartDate = DateOnlyCreator.Today().AddDays(5);
        var newEndDate = DateOnlyCreator.Today().AddDays(35);

        recurringInvoice.UpdateSchedule(RecurringFrequency.Weekly, newStartDate, newEndDate);

        recurringInvoice.Frequency.ShouldBe(RecurringFrequency.Weekly);
        recurringInvoice.StartDate.ShouldBe(newStartDate);
        recurringInvoice.EndDate.ShouldBe(newEndDate);
        recurringInvoice.NextRunDate.ShouldBe(newStartDate); // Should be set to new start date
    }

    [Fact]
    public void Mark_as_processed_updates_next_run_date_based_on_frequency()
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(1);
        
        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            startDate,
            null,
            "17:00");

        var recurringInvoice = result.Value;
        var originalNextRunDate = recurringInvoice.NextRunDate;

        recurringInvoice.MarkAsProcessed();

        DateOnlyTestExtensions.ShouldBe(recurringInvoice.NextRunDate, originalNextRunDate?.AddMonths(1));
        recurringInvoice.IsActive.ShouldBeTrue();
    }

    [Fact]
    public void Mark_as_processed_deactivates_recurring_invoice_when_next_run_date_exceeds_end_date()
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(1);
        var endDate = DateOnlyCreator.Today().AddDays(20);
        
        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            startDate,
            endDate,
            "17:00");

        var recurringInvoice = result.Value;
        
        recurringInvoice.MarkAsProcessed();

        recurringInvoice.IsActive.ShouldBeFalse();
        recurringInvoice.NextRunDate.ShouldBeNull();
    }

    [Fact]
    public void Mark_as_processed_handles_null_next_run_date_by_using_today()
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(1);
        
        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Weekly,
            startDate,
            null,
            "17:00");

        var recurringInvoice = result.Value;
        recurringInvoice.NextRunDate = null;

        recurringInvoice.MarkAsProcessed();

        recurringInvoice.NextRunDate.ShouldBe(DateOnlyCreator.Today().AddDays(7));
    }

    [Fact]
    public void Recurring_invoice_activation_sets_calculates_next_run_date()
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(1);
        
        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            startDate,
            null,
            "17:00");

        var recurringInvoice = result.Value;
        recurringInvoice.IsActive = false;
        recurringInvoice.NextRunDate = null;

        recurringInvoice.Activate();

        recurringInvoice.IsActive.ShouldBeTrue();
        recurringInvoice.NextRunDate.ShouldBe(DateOnlyCreator.Today().AddMonths(1));
    }

    [Fact]
    public void Recurring_invoice_activation_does_not_change_next_run_date_if_it_exists()
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(1);
        
        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            startDate,
            null,
            "17:00");

        var recurringInvoice = result.Value;
        var existingNextRunDate = recurringInvoice.NextRunDate;
        recurringInvoice.IsActive = false;

        recurringInvoice.Activate();

        recurringInvoice.IsActive.ShouldBeTrue();
        DateOnlyTestExtensions.ShouldBe(recurringInvoice.NextRunDate, existingNextRunDate);
    }

    [Fact]
    public void Deactivate_sets_is_active_to_false()
    {
        var customer = CreateTestCustomer();
        var startDate = DateOnlyCreator.Today().AddDays(1);
        
        var result = RecurringInvoice.Create(
            "test-user-id",
            customer.Id,
            RecurringFrequency.Monthly,
            startDate,
            null,
            "17:00");

        var recurringInvoice = result.Value;
        recurringInvoice.IsActive.ShouldBeTrue();

        recurringInvoice.Deactivate();

        recurringInvoice.IsActive.ShouldBeFalse();
    }
}
