using InvadePay.Common.Extensions;
using InvadePay.Invoicing.Core.Features.Invoices.GetList;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using Shouldly;

namespace InvadePay.Invoicing.UnitTests.Invoices;

public class InvoiceSearchSpecificationTests
{
    private static Invoice CreateTestInvoice(long invoiceNumber = 1, string customerName = "Test Customer", string customerEmail = "test@example.com", InvoiceStatus status = InvoiceStatus.Draft)
    {
        var customer = Customer.Create(customerName, customerEmail, "test-user-id").Value;
        customer.Id = 1;
        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            invoiceNumber,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems).Value;

        invoice.SetStatusTo(status);
        invoice.Customer = customer;
        return invoice;
    }

    [Fact]
    public void Search_matches_invoice_number()
    {
        var specification = new InvoiceSearchSpecification("123");
        var invoice = CreateTestInvoice(123);

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeTrue();
    }

    [Fact]
    public void Search_matches_customer_name()
    {
        var specification = new InvoiceSearchSpecification("john");
        var invoice = CreateTestInvoice(1, "John Doe", "john@example.com");

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeTrue();
    }

    [Fact]
    public void Search_matches_customer_email()
    {
        var specification = new InvoiceSearchSpecification("example");
        var invoice = CreateTestInvoice(1, "John Doe", "john@example.com");

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeTrue();
    }

    [Fact]
    public void Search_matches_invoice_status()
    {
        var specification = new InvoiceSearchSpecification("se");
        var invoice = CreateTestInvoice(1, "John Doe", "john@example.com", InvoiceStatus.Sent);

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeTrue();
    }

    [Fact]
    public void Search_is_case_insensitive()
    {
        var specification = new InvoiceSearchSpecification("MIKE");
        var invoice = CreateTestInvoice(1, "Mike Doe", "mike@example.com");

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeTrue();
    }

    [Fact]
    public void Search_returns_false_when_no_match()
    {
        var specification = new InvoiceSearchSpecification("nonexistent");
        var invoice = CreateTestInvoice(1, "John Doe", "john@example.com");

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeFalse();
    }
}
