﻿using InvadePay.Common.Extensions;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Invoices.GeneratePdf;
using InvadePay.Invoicing.Core.Features.Invoices.SendEmail;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using InvadePay.Invoicing.UnitTests.TestSetup;
using InvadePay.Invoicing.UnitTests.TestSetup.Fakes;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.Invoicing.UnitTests.Invoices;

public class SendInvoiceEmailUseCaseTests
{
    private static SendInvoiceEmailUseCase CreateUseCase(
        IDbContext dbContext,
        IInvoicePdfDataService? pdfDataService = null,
        IInvoicePdfGenerator? pdfGenerator = null,
        IInvoicingEmailSender? emailSender = null)
    {
        return new SendInvoiceEmailUseCase(
            dbContext,
            pdfDataService ?? new FakeInvoicePdfDataService(),
            pdfGenerator ?? new FakeInvoicePdfGenerator(),
            emailSender ?? new FakeInvoicingEmailSender());
    }

    [Fact]
    public async Task Send_invoice_email_fails_when_invoice_is_not_found()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var nonExistentInvoiceId = 999L;
        var userId = "test-user-id";

        var result = await useCase.Execute(nonExistentInvoiceId, userId);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Send_invoice_email_fails_when_invoice_belongs_to_different_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var customer = Customer.Create("Test Customer", "customer@test.com", "test-user-id").Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(invoice.Id, "other-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Send_invoice_email_fails_when_invoice_is_reversed()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var customer = Customer.Create("Test Customer", "customer@test.com", "test-user-id").Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems).Value;

        // Set invoice to Sent first, then to Reversed (valid transition)
        invoice.SetStatusTo(InvoiceStatus.Sent);
        invoice.SetStatusTo(InvoiceStatus.Reversed);

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(invoice.Id, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Cannot send a reversed invoice.");
    }

    [Fact]
    public async Task Send_invoice_email_fails_when_pdf_data_retrieval_fails()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var failingPdfDataService = new FakeInvoicePdfDataService { ShouldReturnNull = true };
        var useCase = CreateUseCase(dbContext, pdfDataService: failingPdfDataService);

        var customer = Customer.Create("Test Customer", "customer@test.com", "test-user-id").Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(invoice.Id, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Failed to retrieve invoice data for PDF generation.");
    }

    [Fact]
    public async Task Send_invoice_email_fails_when_email_sending_fails()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var failingEmailSender = new FakeInvoicingEmailSender { ShouldFail = true };
        var useCase = CreateUseCase(dbContext, emailSender: failingEmailSender);

        var customer = Customer.Create("Test Customer", "customer@test.com", "test-user-id").Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(invoice.Id, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Failed to send email: Email sending failed");
    }

    [Fact]
    public async Task Send_invoice_email_succeeds_and_changes_draft_invoice_status_to_sent()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var emailSender = new FakeInvoicingEmailSender();
        var useCase = CreateUseCase(dbContext, emailSender: emailSender);

        var customer = Customer.Create("Test Customer", "customer@test.com", "test-user-id").Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        invoice.Status.ShouldBe(InvoiceStatus.Draft);

        var result = await useCase.Execute(invoice.Id, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Success.ShouldBeTrue();
        result.Value.Message.ShouldBe($"Invoice {invoice.InvoiceNumber} has been sent successfully to {customer.Email}");

        emailSender.SentInvoiceEmails.Count.ShouldBe(1);
        var sentEmail = emailSender.SentInvoiceEmails[0];
        sentEmail.CustomerEmail.ShouldBe(customer.Email);
        sentEmail.CustomerName.ShouldBe(customer.Name);
        sentEmail.InvoiceNumber.ShouldBe(invoice.InvoiceNumber.ToString());
        sentEmail.PdfAttachment.ShouldNotBeNull();

        var updatedInvoice = await dbContext.Set<Invoice>()
            .FirstAsync(i => i.Id == invoice.Id);
        updatedInvoice.Status.ShouldBe(InvoiceStatus.Sent);
    }

    [Fact]
    public async Task Send_invoice_email_succeeds_and_does_not_change_sent_invoice_status()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var emailSender = new FakeInvoicingEmailSender();
        var useCase = CreateUseCase(dbContext, emailSender: emailSender);

        var customer = Customer.Create("Test Customer", "customer@test.com", "test-user-id").Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems).Value;

        invoice.SetStatusTo(InvoiceStatus.Sent);

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(invoice.Id, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Success.ShouldBeTrue();
        result.Value.Message.ShouldBe($"Invoice {invoice.InvoiceNumber} has been sent successfully to {customer.Email}");

        emailSender.SentInvoiceEmails.Count.ShouldBe(1);

        var updatedInvoice = await dbContext.Set<Invoice>()
            .FirstAsync(i => i.Id == invoice.Id);
        updatedInvoice.Status.ShouldBe(InvoiceStatus.Sent);
    }

    [Fact]
    public async Task Send_invoice_email_succeeds_and_does_not_change_paid_invoice_status()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var emailSender = new FakeInvoicingEmailSender();
        var useCase = CreateUseCase(dbContext, emailSender: emailSender);

        var customer = Customer.Create("Test Customer", "customer@test.com", "test-user-id").Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems).Value;

        invoice.SetStatusTo(InvoiceStatus.Paid);

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(invoice.Id, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Success.ShouldBeTrue();
        result.Value.Message.ShouldBe($"Invoice {invoice.InvoiceNumber} has been sent successfully to {customer.Email}");

        emailSender.SentInvoiceEmails.Count.ShouldBe(1);

        var updatedInvoice = await dbContext.Set<Invoice>()
            .FirstAsync(i => i.Id == invoice.Id);
        updatedInvoice.Status.ShouldBe(InvoiceStatus.Paid);
    }
}
