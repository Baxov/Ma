using FluentValidation;
using InvadePay.Common.Api;
using InvadePay.Common.DomainEvents;
using InvadePay.Common.Interceptors;
using InvadePay.Invoicing.Contracts;
using InvadePay.Invoicing.Core.Integrations;
using InvadePay.Invoicing.Core.Features.CompanySettings.Get;
using InvadePay.Invoicing.Core.Features.CompanySettings.Update;
using InvadePay.Invoicing.Core.Features.Customers.Create;
using InvadePay.Invoicing.Core.Features.Customers.Delete;
using InvadePay.Invoicing.Core.Features.Customers.GetById;
using InvadePay.Invoicing.Core.Features.Customers.GetList;
using InvadePay.Invoicing.Core.Features.Customers.Statement;
using InvadePay.Invoicing.Core.Features.Customers.Update;
using InvadePay.Invoicing.Core.Features.Invoices.Create;
using InvadePay.Invoicing.Core.Features.Invoices.GeneratePdf;
using InvadePay.Invoicing.Core.Features.Invoices.GetById;
using InvadePay.Invoicing.Core.Features.Invoices.GetList;
using InvadePay.Invoicing.Core.Features.Invoices.NextInvoiceNumber;
using InvadePay.Invoicing.Core.Features.Invoices.SendEmail;
using InvadePay.Invoicing.Core.Features.Invoices.Update;
using InvadePay.Invoicing.Core.Features.Invoices.UpdateStatus;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Create;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Delete;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.GetById;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.GetList;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Shared;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Update;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Features.Taxes.Create;
using InvadePay.Invoicing.Core.Features.Taxes.Delete;
using InvadePay.Invoicing.Core.Features.Taxes.GetById;
using InvadePay.Invoicing.Core.Features.Taxes.GetList;
using InvadePay.Invoicing.Core.Features.Taxes.Update;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using InvadePay.Invoicing.Infrastructure.BackgroundJobs;
using InvadePay.Invoicing.Infrastructure.Crm;
using InvadePay.Invoicing.Infrastructure.Database;
using InvadePay.Invoicing.Infrastructure.Emailing;
using InvadePay.Invoicing.Infrastructure.PdfGeneration;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace InvadePay.Invoicing.Api;

public static class InvoicingModuleEntryPoint
{
    public static IServiceCollection AddInvoicingModule(this IServiceCollection services, IConfiguration configuration)
    {
        ConfigureCustomOptions(services, configuration);
        ConfigureDependencyInjection(services);
        ConfigureDatabase(services);
        
        services.AddEndpoints(typeof(InvoicingModuleEntryPoint).Assembly);
        
        return services;
    }

    public static IApplicationBuilder UseInvoicingModule(this IApplicationBuilder app)
    {
        UseDatabase(app);
        return app;
    }
    
    private static void UseDatabase(IApplicationBuilder app)
    {
        if (app is not WebApplication webApplication)
        {
            throw new InvalidOperationException("UseDatabase can only be used with WebApplication");
        }

        using var scope = webApplication.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<InvoicingContext>();
        dbContext.Database.Migrate();
    }
    
    private static void ConfigureCustomOptions(IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<InvoicingDatabaseOptions>()
            .Bind(configuration.GetSection("InvoicingDatabase"))
            .ValidateDataAnnotations();
    }
    
    private static void ConfigureDatabase(IServiceCollection services)
    {
        services.AddDbContext<InvoicingContext>((serviceProvider, options) =>
        {
            var dbOptions = serviceProvider.GetRequiredService<IOptions<InvoicingDatabaseOptions>>().Value;

            options.UseSqlServer(dbOptions.ConnectionString,
                    optionsActions =>
                    {
                        optionsActions.CommandTimeout(dbOptions.CommandTimeout);
                        optionsActions.EnableRetryOnFailure(dbOptions.MaxRetryCount);
                    })
                .AddInterceptors(
                    serviceProvider.GetRequiredService<AuditInterceptor>(),
                    serviceProvider.GetRequiredService<DomainEventInterceptor>());
        });
    }
    
    private static void ConfigureDependencyInjection(IServiceCollection services)
    {
        services.AddScoped<IDbContext, InvoicingContext>();
        services.AddValidatorsFromAssemblyContaining<CreateCustomerValidator>();
        
        #if DEBUG
        services.AddTransient<IInvoicingEmailSender, LocalInvoicingEmailSender>();
        #else
        services.AddTransient<IInvoicingEmailSender, SendgridInvoicingEmailSender>();
        #endif

        RegisterCustomerDependencies(services);
        RegisterTaxDependencies(services);
        RegisterCompanySettingsDependencies(services);
        RegisterInvoiceDependencies(services);
        RegisterRecurringInvoiceDependencies(services);
    }

    private static void RegisterRecurringInvoiceDependencies(IServiceCollection services)
    {
        services.AddTransient<CreateRecurringInvoiceUseCase>();
        services.AddTransient<GetRecurringInvoiceListUseCase>();
        services.AddTransient<GetRecurringInvoiceByIdUseCase>();
        services.AddTransient<UpdateRecurringInvoiceUseCase>();
        services.AddTransient<DeleteRecurringInvoiceUseCase>();
        services.AddScoped<IRecurringInvoiceJobService, RecurringInvoiceJobService>();
    }
    
    private static void RegisterInvoiceDependencies(IServiceCollection services)
    {
        services.AddTransient<IInvoicePdfGenerator, QuestPdfGenerator>();
        services.AddTransient<IInvoicePdfDataService, InvoicePdfDataService>();
        services.AddTransient<CreateInvoiceUseCase>();
        services.AddTransient<GetInvoiceByIdUseCase>();
        services.AddTransient<GetInvoiceListUseCase>();
        services.AddTransient<NextInvoiceNumberUseCase>();
        services.AddTransient<UpdateInvoiceUseCase>();
        services.AddTransient<UpdateInvoiceStatusUseCase>();
        services.AddTransient<GenerateInvoicePdfUseCase>();
        services.AddTransient<SendInvoiceEmailUseCase>();
        services.AddTransient<IDomainEventHandler<InvoiceSentEvent>, DueDateReminderHandler>();
        services.AddTransient<InvoiceValidator>();
        services.AddTransient<IProductUsageChecker, ProductUsageChecker>();
    }
    
    private static void RegisterCustomerDependencies(IServiceCollection services)
    {
        services.AddTransient<CreateCustomerUseCase>();
        services.AddTransient<GetCustomerByIdUseCase>();
        services.AddTransient<GetCustomerListUseCase>();
        services.AddTransient<UpdateCustomerUseCase>();
        services.AddTransient<DeleteCustomerUseCase>();
        services.AddTransient<ICustomerCrmService, CustomerCrmService>();
        services.AddTransient<CustomerStatementUseCase>();
        services.AddTransient<IDomainEventHandler<CustomerCreatedEvent>, CustomerCrmSyncJob>();
    }

    private static void RegisterTaxDependencies(IServiceCollection services)
    {
        services.AddTransient<CreateTaxUseCase>();
        services.AddTransient<GetTaxByIdUseCase>();
        services.AddTransient<GetTaxListUseCase>();
        services.AddTransient<UpdateTaxUseCase>();
        services.AddTransient<DeleteTaxUseCase>();
    }
    
    private static void RegisterCompanySettingsDependencies(IServiceCollection services)
    {
        services.AddTransient<CompanySettingsUseCase>();
        services.AddTransient<UpdateCompanySettingsUseCase>();
    }
}