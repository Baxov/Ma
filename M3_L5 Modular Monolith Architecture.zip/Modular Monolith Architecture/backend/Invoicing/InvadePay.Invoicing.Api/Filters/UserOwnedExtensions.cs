﻿using InvadePay.Common.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace InvadePay.Invoicing.Api.Filters;

public static class UserOwnedExtensions
{
    public static RouteHandlerBuilder UserOwnedResource<T>(this RouteHandlerBuilder handlerBuilder)
        where T : class, IUserOwnedResource
    {
        handlerBuilder.AddEndpointFilter<UserOwnedEndpointFilter<T>>();
        return handlerBuilder;
    }
}