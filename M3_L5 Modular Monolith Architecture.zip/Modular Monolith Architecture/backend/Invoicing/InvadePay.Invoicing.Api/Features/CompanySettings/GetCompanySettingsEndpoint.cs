﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Invoicing.Core.Features.CompanySettings.Get;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.CompanySettings;

public class GetCompanySettingsEndpoint : IEndpoint
{
    private const string GetCompanySettingsEndpointName = "GetCompanySettings";
    
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/company-settings", GetCompanySettings)
            .WithSummary("Retrieves company settings for the current user.")
            .WithName(GetCompanySettingsEndpointName)
            .WithTags("Company Settings")
            .RequireAuthorization();
    }
    
    private static async Task<Results<Ok<CompanySettingsResponse>, NotFound<string>, UnauthorizedHttpResult>> GetCompanySettings(
        CompanySettingsUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(userId);
        return result.IsSuccess
            ? TypedResults.Ok(result.Value)
            : TypedResults.NotFound(result.ErrorMessage);
    }
}
