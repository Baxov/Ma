﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using InvadePay.Invoicing.Core.Features.CompanySettings.Update;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.CompanySettings;

public class UpdateCompanySettingsEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPut("/api/company-settings", UpdateCompanySettings)
            .WithSummary("Updates or creates company settings for the current user.")
            .Validator<UpdateCompanySettingsRequest>()
            .WithTags("Company Settings")
            .RequireAuthorization();
    }

    private static async Task<Results<Ok<UpdateCompanySettingsResponse>, BadRequest<string>, UnauthorizedHttpResult>> UpdateCompanySettings(
        UpdateCompanySettingsRequest request,
        UpdateCompanySettingsUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(request, userId);
        return result.IsSuccess
            ? TypedResults.Ok(result.Value)
            : TypedResults.BadRequest(result.ErrorMessage);
    }
}
