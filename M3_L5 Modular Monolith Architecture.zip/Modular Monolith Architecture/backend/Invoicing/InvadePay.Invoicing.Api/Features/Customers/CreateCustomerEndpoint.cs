﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using InvadePay.Invoicing.Core.Features.Customers.Create;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Customers;

public class CreateCustomerEndpoint: IEndpoint
{
    private const string GetCustomerEndpointName = "GetCustomer";
    
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPost("/api/customers", CreateCustomer)
            .WithSummary("Creates a new customer with specified details.")
            .Validator<CreateCustomerRequest>()
            .WithTags("Customers")
            .RequireAuthorization();
    }
    
    private static async Task<Results<CreatedAtRoute<CreateCustomerResponse>, BadRequest<string>, UnauthorizedHttpResult>> CreateCustomer(
        CreateCustomerRequest request,
        [FromServices] CreateCustomerUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(request, userId);
        return result.IsSuccess
            ? TypedResults.CreatedAtRoute(result.Value, GetCustomerEndpointName, new { id = result.Value.Id })
            : TypedResults.BadRequest(result.ErrorMessage);
    }
}