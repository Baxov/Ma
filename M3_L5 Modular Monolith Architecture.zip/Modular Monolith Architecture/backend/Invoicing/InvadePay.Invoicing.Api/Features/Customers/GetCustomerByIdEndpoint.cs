﻿using InvadePay.Common.Api;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.Customers.GetById;
using InvadePay.Invoicing.Core.Models.Customers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Customers;

public class GetCustomerByIdEndpoint : IEndpoint
{
    private const string GetCustomerEndpointName = "GetCustomer";
    
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/customers/{id:long}", GetCustomerById)
            .WithSummary("Retrieves details for a specific customer by their ID.")
            .WithName(GetCustomerEndpointName)
            .WithTags("Customers")
            .RequireAuthorization()
            .UserOwnedResource<Customer>();
    }
    
    private static async Task<Results<Ok<SingleCustomerResponse>, NotFound<string>>> GetCustomerById(
        long id,
        GetCustomerByIdUseCase useCase)
    {
        var result = await useCase.Execute(id);
        return result.IsSuccess
            ? TypedResults.Ok(result.Value)
            : TypedResults.NotFound(result.ErrorMessage);
    }
}
