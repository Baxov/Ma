﻿using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.Customers.Update;
using InvadePay.Invoicing.Core.Models.Customers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Customers;

public class UpdateCustomerEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPut("/api/customers/{id}", UpdateCustomer)
            .WithSummary("Updates an existing customer with specified details.")
            .Validator<UpdateCustomerRequest>()
            .WithTags("Customers")
            .RequireAuthorization()
            .UserOwnedResource<Customer>();
    }

    private static async Task<Results<Ok<UpdateCustomerResponse>, NotFound<string>, BadRequest<string>>> UpdateCustomer(
        long id,
        UpdateCustomerRequest request,
        UpdateCustomerUseCase useCase)
    {
        var result = await useCase.Execute(id, request);

        if (result.IsSuccess)
        {
            return TypedResults.Ok(result.Value);
        }

        if (result.Status == ResultStatus.NotFound)
        {
            return TypedResults.NotFound(result.ErrorMessage);
        }

        return TypedResults.BadRequest(result.ErrorMessage);
    }
}
