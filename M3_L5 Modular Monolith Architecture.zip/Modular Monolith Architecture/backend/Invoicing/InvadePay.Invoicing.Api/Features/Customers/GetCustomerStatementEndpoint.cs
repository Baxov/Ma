﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.Customers.Statement;
using InvadePay.Invoicing.Core.Models.Customers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Customers;

public class GetCustomerStatementEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/customers/{id:long}/statement", GetCustomerStatement)
            .WithSummary("Retrieves a customer statement showing outstanding and paid invoices for a given period.")
            .WithTags("Customer Statements")
            .RequireAuthorization()
            .UserOwnedResource<Customer>();
    }

    private static async Task<Results<Ok<CustomerStatementResponse>, NotFound<string>, BadRequest<string>, UnauthorizedHttpResult>> GetCustomerStatement(
        long id,
        DateTime startDate,
        DateTime endDate,
        CustomerStatementUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var request = new CustomerStatementRequest(id, startDate, endDate);
        var result = await useCase.Execute(request, userId);

        if (result.IsSuccess)
        {
            return TypedResults.Ok(result.Value);
        }

        if (result.Status == ResultStatus.NotFound)
        {
            return TypedResults.NotFound(result.ErrorMessage);
        }

        return TypedResults.BadRequest(result.ErrorMessage);
    }
}
