﻿using InvadePay.Common.Api;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.Customers.Delete;
using InvadePay.Invoicing.Core.Models.Customers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Customers;

public class DeleteCustomerEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapDelete("/api/customers/{id:long}", DeleteCustomer)
            .WithSummary("Deletes a specific customer by their ID.")
            .WithTags("Customers")
            .RequireAuthorization()
            .UserOwnedResource<Customer>();
    }

    private static async Task<Results<NoContent, NotFound<string>, BadRequest<string>>> DeleteCustomer(
        long id,
        DeleteCustomerUseCase useCase)
    {
        var result = await useCase.Execute(id);

        if (result.IsSuccess)
        {
            return TypedResults.NoContent();
        }

        if (result.Status == ResultStatus.NotFound)
        {
            return TypedResults.NotFound(result.ErrorMessage);
        }

        return TypedResults.BadRequest(result.ErrorMessage);
    }
}
