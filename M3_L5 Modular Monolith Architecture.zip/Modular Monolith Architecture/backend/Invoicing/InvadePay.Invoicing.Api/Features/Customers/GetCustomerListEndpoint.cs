﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Responses;
using InvadePay.Invoicing.Core.Features.Customers.GetList;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Customers;

public class GetCustomerListEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/customers", GetAllCustomers)
            .WithSummary("Retrieves a paginated list of all customers.")
            .WithTags("Customers")
            .RequireAuthorization();
    }
    
    private static async Task<Results<Ok<PagedResponse<CustomerResponse>>, UnauthorizedHttpResult>> GetAllCustomers(
        int? page,
        int? pageSize,
        GetCustomerListUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase
            .Execute(
                page.GetValueOrDefault(),
                pageSize.GetValueOrDefault(),
                userId);

        return TypedResults.Ok(result);
    }
}
