﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.Taxes.GetById;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Taxes;

public class GetTaxByIdEndpoint : IEndpoint
{
    private const string GetTaxEndpointName = "GetTax";
    
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/taxes/{id:long}", GetTaxById)
            .WithSummary("Retrieves details for a specific tax by its ID.")
            .WithName(GetTaxEndpointName)
            .WithTags("Taxes")
            .RequireAuthorization()
            .UserOwnedResource<Tax>();
    }
    
    private static async Task<Results<Ok<SingleTaxResponse>, NotFound<string>, UnauthorizedHttpResult>> GetTaxById(
        long id,
        GetTaxByIdUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(id, userId);
        return result.IsSuccess
            ? TypedResults.Ok(result.Value)
            : TypedResults.NotFound(result.ErrorMessage);
    }
}
