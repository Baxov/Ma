﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.Taxes.Update;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Taxes;

public class UpdateTaxEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPut("/api/taxes/{id:long}", UpdateTax)
            .WithSummary("Updates an existing tax with specified details.")
            .Validator<UpdateTaxRequest>()
            .WithTags("Taxes")
            .RequireAuthorization()
            .UserOwnedResource<Tax>();
    }
    
    private static async Task<Results<Ok<UpdateTaxResponse>, BadRequest<string>, NotFound<string>, UnauthorizedHttpResult>> UpdateTax(
        long id,
        UpdateTaxRequest request,
        UpdateTaxUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(id, request, userId);

        if (result.IsSuccess)
        {
            return TypedResults.Ok(result.Value);
        }
        
        return result.Status switch
        {
            ResultStatus.NotFound => TypedResults.NotFound(result.ErrorMessage),
            ResultStatus.Error => TypedResults.BadRequest(result.ErrorMessage),
            _ => throw new NotImplementedException()
        };
    }
}
