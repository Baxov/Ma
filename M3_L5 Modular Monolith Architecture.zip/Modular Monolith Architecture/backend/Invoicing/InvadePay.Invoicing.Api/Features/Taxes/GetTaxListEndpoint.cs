﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Responses;
using InvadePay.Invoicing.Core.Features.Taxes.GetList;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Taxes;

public class GetTaxListEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/taxes", GetAllTaxes)
            .WithSummary("Retrieves a paginated list of all available taxes.")
            .WithTags("Taxes")
            .RequireAuthorization();
    }
    
    private static async Task<Results<Ok<PagedResponse<TaxResponse>>, UnauthorizedHttpResult>> GetAllTaxes(
        int? page,
        int? pageSize,
        GetTaxListUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(page.GetValueOrDefault(), pageSize.GetValueOrDefault(), userId);
        return TypedResults.Ok(result);
    }
}
