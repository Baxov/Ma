﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using InvadePay.Invoicing.Core.Features.Taxes.Create;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Taxes;

public class CreateTaxEndpoint : IEndpoint
{
    private const string GetTaxEndpointName = "GetTax";
    
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPost("/api/taxes", CreateTax)
            .WithSummary("Creates a new tax with specified details.")
            .Validator<CreateTaxRequest>()
            .WithTags("Taxes")
            .RequireAuthorization();
    }
    
    private static async Task<Results<CreatedAtRoute<CreateTaxResponse>, BadRequest<string>, UnauthorizedHttpResult>> CreateTax(
        CreateTaxRequest request,
        CreateTaxUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(request, userId);
        return result.IsSuccess
            ? TypedResults.CreatedAtRoute(result.Value, GetTaxEndpointName, new { id = result.Value.Id })
            : TypedResults.BadRequest(result.ErrorMessage);
    }
}
