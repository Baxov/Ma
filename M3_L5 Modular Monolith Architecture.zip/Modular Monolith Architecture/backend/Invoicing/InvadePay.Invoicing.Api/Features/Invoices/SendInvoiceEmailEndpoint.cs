﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.Invoices.SendEmail;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Invoices;

public class SendInvoiceEmailEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPost("/api/invoices/{id:long}/send-email", SendInvoiceEmail)
            .WithSummary("Sends an invoice via email to the customer.")
            .WithTags("Invoices")
            .RequireAuthorization()
            .UserOwnedResource<Invoice>();
    }
    
    private static async Task<Results<Ok<SendInvoiceEmailResponse>, NotFound<string>, BadRequest<string>, UnauthorizedHttpResult>> SendInvoiceEmail(
        long id,
        SendInvoiceEmailUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();
        
        if (userId == null)
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(id, userId);

        if (result.IsSuccess)
        {
            return TypedResults.Ok(result.Value);
        }

        return result.Status switch
        {
            ResultStatus.NotFound => TypedResults.NotFound(result.ErrorMessage),
            _ => TypedResults.BadRequest(result.ErrorMessage)
        };
    }
}
