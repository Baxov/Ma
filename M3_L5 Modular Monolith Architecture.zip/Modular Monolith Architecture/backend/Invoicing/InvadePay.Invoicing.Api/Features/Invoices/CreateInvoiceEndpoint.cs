﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Invoicing.Core.Features.Invoices.Create;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Invoices;

public class CreateInvoiceEndpoint : IEndpoint
{
    private const string GetInvoiceEndpointName = "GetInvoice";
    
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPost("/api/invoices", CreateInvoice)
            .WithSummary("Creates a new invoice with specified details.")
            .WithTags("Invoices")
            .RequireAuthorization();
    }
    
    private static async Task<IResult> CreateInvoice(CreateInvoiceRequest request, CreateInvoiceUseCase useCase, IUserContext userContext)
    {
        var userId = userContext.GetUserId();
        
        if (userId == null)
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(request, userId);

        return result.IsSuccess
            ? TypedResults.CreatedAtRoute(result.Value, GetInvoiceEndpointName, new { id = result.Value.Id })
            : TypedResults.BadRequest(result.ErrorMessage);
    }
}
