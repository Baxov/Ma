﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.Invoices.UpdateStatus;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Invoices;

public class UpdateInvoiceStatusEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPut("/api/invoices/{id:long}/status", UpdateStatus)
            .WithSummary("Updates the status of a specific invoice.")
            .WithTags("Invoices")
            .RequireAuthorization()
            .UserOwnedResource<Invoice>();
    }
    
    private static async Task<Results<Ok, NotFound<string>, UnauthorizedHttpResult>> UpdateStatus(
        long id,
        UpdateInvoiceStatusRequest request,
        UpdateInvoiceStatusUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();
        
        if (userId == null)
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(id, request.Status, userId);

        return result.IsSuccess
            ? TypedResults.Ok()
            : TypedResults.NotFound(result.ErrorMessage);
    }
}
