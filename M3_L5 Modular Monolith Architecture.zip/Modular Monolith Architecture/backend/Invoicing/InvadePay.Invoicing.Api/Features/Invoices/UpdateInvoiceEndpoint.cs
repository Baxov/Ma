﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.Invoices.Update;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Invoices;

public class UpdateInvoiceEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPut("/api/invoices/{id:long}", UpdateInvoice)
            .WithSummary("Updates an existing invoice with specified details.")
            .Validator<UpdateInvoiceRequest>()
            .WithTags("Invoices")
            .RequireAuthorization()
            .UserOwnedResource<Invoice>();
    }

    private static async Task<Results<Ok<UpdateInvoiceResponse>, NotFound<string>, BadRequest<string>, UnauthorizedHttpResult>> UpdateInvoice(
        long id,
        UpdateInvoiceRequest request,
        UpdateInvoiceUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(id, request, userId);

        if (result.IsSuccess)
        {
            return TypedResults.Ok(result.Value);
        }

        if (result.Status == ResultStatus.NotFound)
        {
            return TypedResults.NotFound(result.ErrorMessage);
        }

        return TypedResults.BadRequest(result.ErrorMessage);
    }
}
