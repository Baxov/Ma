﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Invoicing.Core.Features.Invoices.NextInvoiceNumber;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Invoices;

public class GetNextInvoiceNumberEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/invoices/next-number", GetNextInvoiceNumber)
            .WithSummary("Retrieves the next available invoice number for the current user.")
            .WithTags("Invoices")
            .RequireAuthorization();
    }
    
    private static async Task<Results<Ok<NextInvoiceNumberResponse>, UnauthorizedHttpResult>> GetNextInvoiceNumber(
        NextInvoiceNumberUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();
        
        if (userId == null)
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(userId);
        return TypedResults.Ok(result.Value);
    }
}
