﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.Invoices.GetById;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Invoices;

public class GetInvoiceByIdEndpoint : IEndpoint
{
    private const string GetInvoiceEndpointName = "GetInvoice";
    
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/invoices/{id:int}", GetInvoiceById)
            .WithSummary("Retrieves details for a specific invoice by its ID.")
            .WithName(GetInvoiceEndpointName)
            .WithTags("Invoices")
            .RequireAuthorization()
            .UserOwnedResource<Invoice>();
    }
    
    private static async Task<Results<Ok<SingleInvoiceResponse>, NotFound<string>, UnauthorizedHttpResult>> GetInvoiceById(int id,
        GetInvoiceByIdUseCase useCase, IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (userId == null)
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(id, userId);
        return result.IsSuccess
            ? TypedResults.Ok(result.Value)
            : TypedResults.NotFound(result.ErrorMessage);
    }
}
