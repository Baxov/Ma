﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.Invoices.GeneratePdf;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Invoices;

public class GetInvoicePdfEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/invoices/{id:long}/pdf", GetInvoicePdf)
            .WithSummary("Downloads a PDF version of the specified invoice.")
            .WithTags("Invoices")
            .RequireAuthorization()
            .UserOwnedResource<Invoice>();
    }
    
    private static async Task<Results<FileContentHttpResult, NotFound<string>, UnauthorizedHttpResult>> GetInvoicePdf(
        long id,
        GenerateInvoicePdfUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();
        
        if (userId == null)
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(id, userId);

        if (result.IsError)
        {
            return TypedResults.NotFound(result.ErrorMessage);
        }

        return TypedResults.File(
            result.Value,
            contentType: "application/pdf",
            fileDownloadName: $"invoice-{id}.pdf");
    }
}
