﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Responses;
using InvadePay.Invoicing.Core.Features.Invoices.GetList;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.Invoices;

public class GetInvoiceListEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/invoices", GetAllInvoices)
            .WithSummary("Retrieves a paginated list of all available invoices.")
            .WithTags("Invoices")
            .RequireAuthorization();
    }
    
    private static async Task<Results<Ok<PagedResponse<InvoiceResponse>>, UnauthorizedHttpResult>> GetAllInvoices(
        int? page,
        int? pageSize,
        string? search,
        GetInvoiceListUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (userId == null)
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(page.GetValueOrDefault(), pageSize.GetValueOrDefault() ,search, userId);
        return TypedResults.Ok(result);
    }
}
