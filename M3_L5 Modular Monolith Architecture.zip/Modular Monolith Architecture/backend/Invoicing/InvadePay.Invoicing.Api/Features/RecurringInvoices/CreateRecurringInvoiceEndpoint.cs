﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Create;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.RecurringInvoices;

public class CreateRecurringInvoiceEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPost("/api/recurring-invoices", CreateRecurringInvoice)
            .WithSummary("Creates a new recurring invoice with specified schedule and items.")
            .Validator<CreateRecurringInvoiceRequest>()
            .WithTags("Recurring Invoices")
            .RequireAuthorization();
    }

    private static async Task<Results<Created<CreateRecurringInvoiceResponse>, BadRequest<string>, UnauthorizedHttpResult>> CreateRecurringInvoice(
        CreateRecurringInvoiceRequest request,
        CreateRecurringInvoiceUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(request, userId);
        return result.IsSuccess
            ? TypedResults.Created($"/api/recurring-invoices/{result.Value.Id}", result.Value)
            : TypedResults.BadRequest(result.ErrorMessage);
    }
}
