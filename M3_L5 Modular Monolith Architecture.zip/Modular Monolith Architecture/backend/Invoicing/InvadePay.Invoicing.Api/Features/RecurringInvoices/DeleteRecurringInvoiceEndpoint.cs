﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Delete;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.RecurringInvoices;

public class DeleteRecurringInvoiceEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapDelete("/api/recurring-invoices/{id:long}", DeleteRecurringInvoice)
            .WithSummary("Deletes a specific recurring invoice by its ID and removes any scheduled Hangfire jobs.")
            .WithTags("Recurring Invoices")
            .RequireAuthorization()
            .UserOwnedResource<RecurringInvoice>();
    }
    
    private static async Task<Results<
        NoContent,
        NotFound<string>,
        BadRequest<string>,
        UnauthorizedHttpResult>> DeleteRecurringInvoice(
        long id,
        DeleteRecurringInvoiceUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(id, userId);

        if (result.IsSuccess)
        {
            return TypedResults.NoContent();
        }
        
        return result.Status switch
        {
            ResultStatus.NotFound => TypedResults.NotFound(result.ErrorMessage),
            ResultStatus.Conflict => TypedResults.BadRequest(result.ErrorMessage),
            _ => throw new NotImplementedException()
        };
    }
}
