﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using InvadePay.Common.Models;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Update;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.RecurringInvoices;

public class UpdateRecurringInvoiceEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPut("/api/recurring-invoices/{id:long}", UpdateRecurringInvoice)
            .WithSummary("Updates the schedule and settings of an existing recurring invoice.")
            .Validator<UpdateRecurringInvoiceRequest>()
            .WithTags("Recurring Invoices")
            .RequireAuthorization()
            .UserOwnedResource<RecurringInvoice>();
    }

    private static async Task<Results<Ok<UpdateRecurringInvoiceResponse>, NotFound<string>, BadRequest<string>, UnauthorizedHttpResult>> UpdateRecurringInvoice(
        long id,
        UpdateRecurringInvoiceRequest request,
        UpdateRecurringInvoiceUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(id, request, userId);

        if (result.IsSuccess)
        {
            return TypedResults.Ok(result.Value);
        }

        if (result.Status == ResultStatus.NotFound)
        {
            return TypedResults.NotFound(result.ErrorMessage);
        }

        return TypedResults.BadRequest(result.ErrorMessage);
    }
}
