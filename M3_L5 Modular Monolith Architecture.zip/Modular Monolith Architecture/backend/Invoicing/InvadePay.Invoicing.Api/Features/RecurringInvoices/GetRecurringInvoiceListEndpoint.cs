﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.GetList;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.RecurringInvoices;

public class GetRecurringInvoiceListEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/recurring-invoices", GetRecurringInvoices)
            .WithSummary("Retrieves a paginated list of recurring invoices.")
            .WithTags("Recurring Invoices")
            .RequireAuthorization();
    }
    
    private static async Task<Results<Ok<PagedRecurringInvoiceListResponse>, UnauthorizedHttpResult>> GetRecurringInvoices(
        int? page,
        int? pageSize,
        GetRecurringInvoiceListUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(
            page.GetValueOrDefault(1), 
            pageSize.GetValueOrDefault(10), 
            userId);
            
        return result.IsSuccess
            ? TypedResults.Ok(result.Value)
            : TypedResults.Ok(new PagedRecurringInvoiceListResponse([], 0, 1, 10));
    }
}
