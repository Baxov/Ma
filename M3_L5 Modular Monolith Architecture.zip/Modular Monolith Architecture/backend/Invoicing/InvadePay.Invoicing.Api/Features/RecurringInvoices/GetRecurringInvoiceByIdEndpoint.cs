﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Invoicing.Api.Filters;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.GetById;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Invoicing.Api.Features.RecurringInvoices;

public class GetRecurringInvoiceByIdEndpoint : IEndpoint
{
    private const string GetRecurringInvoiceEndpointName = "GetRecurringInvoice";
    
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/recurring-invoices/{id:long}", GetRecurringInvoiceById)
            .WithSummary("Retrieves details for a specific recurring invoice by its ID.")
            .WithName(GetRecurringInvoiceEndpointName)
            .WithTags("Recurring Invoices")
            .RequireAuthorization()
            .UserOwnedResource<RecurringInvoice>();
    }
    
    private static async Task<Results<Ok<SingleRecurringInvoiceResponse>, NotFound<string>, UnauthorizedHttpResult>> GetRecurringInvoiceById(
        long id,
        GetRecurringInvoiceByIdUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(id, userId);
        return result.IsSuccess
            ? TypedResults.Ok(result.Value)
            : TypedResults.NotFound(result.ErrorMessage);
    }
}
