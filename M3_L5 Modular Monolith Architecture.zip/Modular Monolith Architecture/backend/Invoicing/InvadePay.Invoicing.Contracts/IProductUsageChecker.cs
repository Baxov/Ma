﻿namespace InvadePay.Invoicing.Contracts;

/// <summary>
/// Contract for checking if a product is used in invoices.
/// This allows the Inventory module to check product usage without direct dependency on Invoicing module.
/// </summary>
public interface IProductUsageChecker
{
    /// <summary>
    /// Checks if a product is used in any invoices.
    /// </summary>
    /// <param name="productId">The ID of the product to check</param>
    /// <returns>True if the product is used in any invoices, false otherwise</returns>
    Task<bool> IsProductUsedInInvoices(long productId);
}

