﻿using InvadePay.Invoicing.Contracts;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Integrations;

public class ProductUsageChecker(IDbContext dbContext) : IProductUsageChecker
{
    public async Task<bool> IsProductUsedInInvoices(long productId)
    {
        var isUsedInInvoices = await dbContext.Set<InvoiceItem>()
            .AnyAsync(x => x.ProductId == productId);

        if (isUsedInInvoices)
        {
            return true;
        }

        var isUsedInRecurringInvoices = await dbContext.Set<RecurringInvoiceItem>()
            .AnyAsync(x => x.ProductId == productId);

        return isUsedInRecurringInvoices;
    }
}

