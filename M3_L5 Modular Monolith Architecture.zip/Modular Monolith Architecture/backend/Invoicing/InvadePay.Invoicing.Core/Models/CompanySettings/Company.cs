﻿using InvadePay.Common.Extensions;
using InvadePay.Common.Models;

namespace InvadePay.Invoicing.Core.Models.CompanySettings;

public class Company : BaseEntity
{
    public static class MaxLengths
    {
        public const int CompanyName = 200;
        public const int Address = 500;
        public const int Email = 100;
    }

    public string CompanyName { get; set; } = null!;
    public string? Address { get; set; }
    public string? Email { get; set; }
    
    public string AppUserId { get; set; } = null!;

    public static Result<Company> Create(string companyName, string? address, string? email, string appUserId)
    {
        if (string.IsNullOrWhiteSpace(companyName) || companyName.Length > MaxLengths.CompanyName)
        {
            return Result.Error("Company name is required and must not exceed maximum length.");
        }

        if (!string.IsNullOrEmpty(address) && address.Length > MaxLengths.Address)
        {
            return Result.Error("Address must not exceed maximum length.");
        }

        if (!string.IsNullOrEmpty(email) && (email.Length > MaxLengths.Email || !email.IsValidEmail()))
        {
            return Result.Error("Email must be valid and not exceed maximum length.");
        }

        if (string.IsNullOrWhiteSpace(appUserId))
        {
            return Result.Error("AppUserId is required.");
        }

        var companySettings = new Company
        {
            CompanyName = companyName,
            Address = address,
            Email = email,
            AppUserId = appUserId
        };

        return companySettings;
    }

    public Result Update(string companyName, string? address, string? email)
    {
        if (string.IsNullOrWhiteSpace(companyName) || companyName.Length > MaxLengths.CompanyName)
        {
            return Result.Error("Company name is required and must not exceed maximum length.");
        }

        if (!string.IsNullOrEmpty(address) && address.Length > MaxLengths.Address)
        {
            return Result.Error("Address must not exceed maximum length.");
        }

        if (!string.IsNullOrEmpty(email) && (email.Length > MaxLengths.Email || !email.IsValidEmail()))
        {
            return Result.Error("Email must be valid and not exceed maximum length.");
        }

        CompanyName = companyName;
        Address = address;
        Email = email;

        return Result.Success();
    }
}
