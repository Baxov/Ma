﻿using InvadePay.Common.DomainEvents;

namespace InvadePay.Invoicing.Core.Models.Customers;

public class CustomerCreatedEvent : BaseDomainEvent;