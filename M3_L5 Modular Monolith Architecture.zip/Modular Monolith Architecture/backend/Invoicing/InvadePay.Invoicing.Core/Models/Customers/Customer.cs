﻿using InvadePay.Common.Extensions;
using InvadePay.Common.Models;

namespace InvadePay.Invoicing.Core.Models.Customers;

public class Customer: BaseEntity, IUserOwnedResource
{
    public static class MaxLengths
    {
        public const int Name = 100;
        public const int Address = 500;
        public const int Email = 100;
        public const int VatNumber = 30;
    }

    public string Name { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string? Address { get; set; }
    public string? VatNumber { get; set; }

    public string AppUserId { get; set; } = null!;
    
    public static Result<Customer> Create(string name, string email, string appUserId)
    {
        if (string.IsNullOrWhiteSpace(name) || name.Length > MaxLengths.Name)
        {
            return Result.Error("Invalid customer name.");
        }
        if (string.IsNullOrWhiteSpace(email) || email.Length > MaxLengths.Email || !email.IsValidEmail())
        {
            return Result.Error("Invalid customer email.");
        }
        if (string.IsNullOrWhiteSpace(appUserId))
        {
            return Result.Error("AppUserId is required.");
        }
        var customer = new Customer
        {
            Name = name,
            Email = email,
            AppUserId = appUserId
        };
        customer.RaiseDomainEvent(new CustomerCreatedEvent());

        return customer;
    }
}