﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Models.Customers;

namespace InvadePay.Invoicing.Core.Models.Invoices;

public class Invoice: BaseEntity, IUserOwnedResource
{
    public static class MaxLengths
    {
        public const int Time = 10;
        public const int Status = 20;
    }
    
    public long InvoiceNumber { get; set; }
    
    public string AppUserId { get; set; } = null!;
    
    public long CustomerId { get; set; }
    public Customer Customer { get; set; } = null!;
    public DateOnly Date { get; set; }
    public DateOnly DueDate { get; set; }
    public string Time { get; set; } = "17:00";

    public long? TaxId { get; set; }
    public Tax? Tax { get; set; }

    public InvoiceStatus Status { get; private set; }

    public ICollection<InvoiceItem> Items { get; set; } = [];

    private Invoice() { }

    public static Result<Invoice> Create(
        long invoiceNumber,
        long customerId,
        DateOnly date,
        DateOnly dueDate,
        string time,
        string appUserId,
        ICollection<InvoiceItem> items,
        long? taxId = null)
    {
        if (string.IsNullOrWhiteSpace(appUserId))
        {
            return Result.Error("AppUserId is required.");
        }

        if (string.IsNullOrWhiteSpace(time))
        {
            return Result.Error("Time is required.");
        }

        if (!items.Any())
        {
            return Result.Error("At least one invoice item is required.");
        }

        if (invoiceNumber <= 0)
        {
            return Result.Error("Invoice number must be greater than zero.");
        }

        var invoice = new Invoice
        {
            InvoiceNumber = invoiceNumber,
            CustomerId = customerId,
            Date = date,
            DueDate = dueDate,
            Time = time,
            AppUserId = appUserId,
            TaxId = taxId,
            Items = items,
            Status = InvoiceStatus.Draft
        };

        return invoice;
    }
    
    private static readonly Dictionary<InvoiceStatus, HashSet<InvoiceStatus>> ValidTransitions = new()
    {
        [InvoiceStatus.Draft] = [InvoiceStatus.Sent, InvoiceStatus.Paid],
        [InvoiceStatus.Sent] = [InvoiceStatus.Paid, InvoiceStatus.Reversed],
        [InvoiceStatus.Paid] = [InvoiceStatus.Reversed],
        [InvoiceStatus.Reversed] = [] // Reversed is a terminal state
    };
    
    public Result SetStatusTo(InvoiceStatus newStatus)
    {
        // Allow staying in the same status (no-op)
        if (Status == newStatus)
        {
            return Result.Success();
        }
        
        if (IsInvalidStatusTransition(Status, newStatus))
        {
            return Result.Error($"Cannot transition from {Status} to {newStatus}.");
        }
        
        Status = newStatus;
        
        if (newStatus == InvoiceStatus.Sent)
        {
            RaiseDomainEvent(new InvoiceSentEvent());
        }

        return Result.Success();
    }
    
    private static bool IsInvalidStatusTransition(InvoiceStatus currentStatus, InvoiceStatus newStatus)
    {
        return !ValidTransitions.TryGetValue(currentStatus, out var allowedTransitions) ||
               !allowedTransitions.Contains(newStatus);
    }
}

public enum InvoiceStatus
{
    Draft,
    Sent,
    Paid,
    Reversed
}