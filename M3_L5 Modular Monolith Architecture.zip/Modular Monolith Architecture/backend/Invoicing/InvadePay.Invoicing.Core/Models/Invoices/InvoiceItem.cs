﻿using InvadePay.Common.Models;

namespace InvadePay.Invoicing.Core.Models.Invoices;

public class InvoiceItem : BaseEntity
{
    public long InvoiceId { get; set; }
    public Invoice Invoice { get; set; } = null!;

    public long ProductId { get; set; }

    public decimal Quantity { get; set; }
    public decimal Price { get; set; }
    public decimal? Discount { get; set; }
}