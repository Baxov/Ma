﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Models.Customers;

namespace InvadePay.Invoicing.Core.Models.Invoices;

public class RecurringInvoice : BaseEntity, IUserOwnedResource
{
    public static class MaxLengths
    {
        public const int Time = 10;
        public const int HangfireJobId = 100;
    }

    public string AppUserId { get; set; } = null!;

    public long CustomerId { get; set; }
    public Customer Customer { get; set; } = null!;

    public string Time { get; set; } = "17:00";

    public long? TaxId { get; set; }
    public Tax? Tax { get; set; }

    public RecurringFrequency Frequency { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly? EndDate { get; set; }
    public DateOnly? NextRunDate { get; set; }

    public bool IsActive { get; set; } = true;
    public string? HangfireJobId { get; set; }
    
    public ICollection<RecurringInvoiceItem> Items { get; set; } = [];

    public static Result<RecurringInvoice> Create(
        string appUserId,
        long customerId,
        RecurringFrequency frequency,
        DateOnly startDate,
        DateOnly? endDate,
        string time,
        long? taxId = null)
    {
        if (string.IsNullOrWhiteSpace(appUserId))
        {
            return Result.Error("AppUserId is required.");
        }
        
        if (startDate < DateOnly.FromDateTime(DateTime.Today))
        {
            return Result.Error("Start date cannot be in the past.");
        }

        if (endDate.HasValue && endDate.Value <= startDate)
        {
            return Result.Error("End date must be after start date.");
        }

        if (string.IsNullOrWhiteSpace(time))
        {
            return Result.Error("Time is required.");
        }

        var recurringInvoice = new RecurringInvoice
        {
            AppUserId = appUserId,
            CustomerId = customerId,
            Frequency = frequency,
            StartDate = startDate,
            EndDate = endDate,
            Time = time,
            TaxId = taxId,
            NextRunDate = startDate // First run should be on start date
        };

        return recurringInvoice;
    }

    public void UpdateSchedule(RecurringFrequency frequency, DateOnly startDate, DateOnly? endDate)
    {
        Frequency = frequency;
        StartDate = startDate;
        EndDate = endDate;
        NextRunDate = startDate > DateOnly.FromDateTime(DateTime.Today)
            ? startDate
            : CalculateNextRunDate(frequency, startDate);
    }

    public void MarkAsProcessed()
    {
        NextRunDate = CalculateNextRunDate(Frequency, NextRunDate ?? DateOnly.FromDateTime(DateTime.Today));

        // If we've passed the end date, deactivate the recurring invoice
        if (EndDate.HasValue && NextRunDate > EndDate.Value)
        {
            IsActive = false;
            NextRunDate = null;
        }
    }

    public void Activate()
    {
        IsActive = true;
        NextRunDate ??= CalculateNextRunDate(Frequency, DateOnly.FromDateTime(DateTime.Today));
    }

    public void Deactivate()
    {
        IsActive = false;
    }

    private static DateOnly CalculateNextRunDate(RecurringFrequency frequency, DateOnly fromDate)
    {
        return frequency switch
        {
            RecurringFrequency.Weekly => fromDate.AddDays(7),
            RecurringFrequency.Monthly => fromDate.AddMonths(1),
            RecurringFrequency.Quarterly => fromDate.AddMonths(3),
            RecurringFrequency.Yearly => fromDate.AddYears(1),
            _ => throw new ArgumentOutOfRangeException(nameof(frequency), frequency, null)
        };
    }
}

public enum RecurringFrequency
{
    Weekly,
    Monthly,
    Quarterly,
    Yearly
}
