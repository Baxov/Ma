﻿using InvadePay.Common.Models;

namespace InvadePay.Invoicing.Core.Models.Invoices;

public class RecurringInvoiceItem : BaseEntity
{
    public long RecurringInvoiceId { get; set; }
    public RecurringInvoice RecurringInvoice { get; set; } = null!;

    public long ProductId { get; set; }

    public decimal Quantity { get; set; }
    public decimal Price { get; set; }
    public decimal? Discount { get; set; }
}
