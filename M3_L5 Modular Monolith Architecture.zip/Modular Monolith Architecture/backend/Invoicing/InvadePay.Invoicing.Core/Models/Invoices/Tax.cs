﻿using InvadePay.Common.Models;

namespace InvadePay.Invoicing.Core.Models.Invoices;

public class Tax : BaseEntity, IUserOwnedResource
{
    public static class MaxLengths
    {
        public const int Name = 100;
        public const int Description = 500;
    }

    public string Name { get; set; } = null!;
    public string? Description { get; set; }
    public decimal Rate { get; set; }
    
    public string AppUserId { get; set; } = null!;

    public static Result<Tax> Create(string name, string? description, decimal rate, string appUserId)
    {
        if (string.IsNullOrWhiteSpace(name) || name.Length > MaxLengths.Name)
        {
            return Result.Error("Tax name is required and must not exceed maximum length.");
        }

        if (!string.IsNullOrEmpty(description) && description.Length > MaxLengths.Description)
        {
            return Result.Error("Tax description must not exceed maximum length.");
        }

        if (rate < 0 || rate > 100)
        {
            return Result.Error("Tax rate must be between 0 and 100 percent.");
        }

        if (string.IsNullOrWhiteSpace(appUserId))
        {
            return Result.Error("AppUserId is required.");
        }

        var tax = new Tax
        {
            Name = name,
            Description = description,
            Rate = rate,
            AppUserId = appUserId
        };

        return tax;
    }

    public Result Update(string name, string? description, decimal rate)
    {
        if (string.IsNullOrWhiteSpace(name) || name.Length > MaxLengths.Name)
        {
            return Result.Error("Tax name is required and must not exceed maximum length.");
        }

        if (!string.IsNullOrEmpty(description) && description.Length > MaxLengths.Description)
        {
            return Result.Error("Tax description must not exceed maximum length.");
        }

        if (rate < 0 || rate > 100)
        {
            return Result.Error("Tax rate must be between 0 and 100 percent.");
        }

        Name = name;
        Description = description;
        Rate = rate;

        return Result.Success();
    }
}
