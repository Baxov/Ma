﻿using InvadePay.Common.DomainEvents;

namespace InvadePay.Invoicing.Core.Models.Invoices;

public class InvoiceSentEvent : BaseDomainEvent;
