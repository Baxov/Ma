﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.CompanySettings;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.CompanySettings.Get;

public class CompanySettingsUseCase(IDbContext dbContext)
{
    public async Task<Result<CompanySettingsResponse>> Execute(string appUserId)
    {
        var companySettings = await dbContext.Set<Company>()
            .Where(x => x.AppUserId == appUserId)
            .Select(x => new CompanySettingsResponse(x.Id, x.CompanyName, x.Address, x.Email))
            .FirstOrDefaultAsync();

        if (companySettings == null)
        {
            return Result.NotFound("Company settings not found.");
        }

        return companySettings;
    }
}
