﻿namespace InvadePay.Invoicing.Core.Features.CompanySettings.Get;

public record CompanySettingsResponse(
    long Id,
    string CompanyName,
    string? Address,
    string? Email);
