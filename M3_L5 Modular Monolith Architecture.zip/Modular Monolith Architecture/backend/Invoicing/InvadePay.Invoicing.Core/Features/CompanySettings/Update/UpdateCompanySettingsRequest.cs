﻿namespace InvadePay.Invoicing.Core.Features.CompanySettings.Update;

public record UpdateCompanySettingsRequest(
    string CompanyName,
    string? Address,
    string? Email);