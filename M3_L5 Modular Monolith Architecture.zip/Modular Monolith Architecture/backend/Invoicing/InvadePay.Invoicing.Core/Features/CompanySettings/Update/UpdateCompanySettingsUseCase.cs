﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.CompanySettings;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.CompanySettings.Update;

public class UpdateCompanySettingsUseCase(IDbContext dbContext)
{
    public async Task<Result<UpdateCompanySettingsResponse>> Execute(UpdateCompanySettingsRequest request, string appUserId)
    {
        var companySettings = await dbContext.Set<Company>()
            .FirstOrDefaultAsync(x => x.AppUserId == appUserId);

        if (companySettings == null)
        {
            return await CreateNewCompanySettings(request, appUserId);
        }
        return await UpdateCompanySettings(request, companySettings);
    }

    private async Task<Result<UpdateCompanySettingsResponse>> UpdateCompanySettings(UpdateCompanySettingsRequest request, Company companySettings)
    {
        var updateResult = companySettings.Update(request.CompanyName, request.Address, request.Email);
        if (updateResult.IsError)
        {
            return Result<UpdateCompanySettingsResponse>.From(updateResult);
        }
        await dbContext.SaveChangesAsync();
        return new UpdateCompanySettingsResponse(companySettings.Id, companySettings.CompanyName, companySettings.Address, companySettings.Email);
    }

    private async Task<Result<UpdateCompanySettingsResponse>> CreateNewCompanySettings(UpdateCompanySettingsRequest request, string appUserId)
    {
        var createResult = Company.Create(request.CompanyName, request.Address, request.Email, appUserId);
        if (createResult.IsError)
        {
            return Result<UpdateCompanySettingsResponse>.From(createResult);
        }

        var companySettings = createResult.Value;
        dbContext.Set<Company>().Add(companySettings);
        await dbContext.SaveChangesAsync();
        return new UpdateCompanySettingsResponse(companySettings.Id, companySettings.CompanyName, companySettings.Address, companySettings.Email);
    }
}
