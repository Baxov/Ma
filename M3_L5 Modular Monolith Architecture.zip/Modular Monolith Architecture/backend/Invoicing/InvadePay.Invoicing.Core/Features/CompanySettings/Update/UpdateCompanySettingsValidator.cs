﻿using FluentValidation;
using InvadePay.Common.Extensions;
using InvadePay.Invoicing.Core.Models.CompanySettings;

namespace InvadePay.Invoicing.Core.Features.CompanySettings.Update;

public class UpdateCompanySettingsValidator : AbstractValidator<UpdateCompanySettingsRequest>
{
    public UpdateCompanySettingsValidator()
    {
        RuleFor(x => x.CompanyName)
            .NotEmpty()
            .WithMessage("Company name is required.")
            .MaximumLength(Company.MaxLengths.CompanyName)
            .WithMessage($"Company name must not exceed {Company.MaxLengths.CompanyName} characters.");

        RuleFor(x => x.Address)
            .MaximumLength(Company.MaxLengths.Address)
            .WithMessage($"Address must not exceed {Company.MaxLengths.Address} characters.")
            .When(x => !string.IsNullOrEmpty(x.Address));

        RuleFor(x => x.Email)
            .MaximumLength(Company.MaxLengths.Email)
            .WithMessage($"Email must not exceed {Company.MaxLengths.Email} characters.")
            .Must(email => email.IsValidEmail())
            .WithMessage("Email must be a valid email address.")
            .When(x => !string.IsNullOrEmpty(x.Email));
    }
}
