﻿namespace InvadePay.Invoicing.Core.Features.CompanySettings.Update;

public record UpdateCompanySettingsResponse(
    long Id,
    string CompanyName,
    string? Address,
    string? Email);
