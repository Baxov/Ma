﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;

namespace InvadePay.Invoicing.Core.Features.Taxes.Create;

public class CreateTaxUseCase(IDbContext dbContext)
{
    public async Task<Result<CreateTaxResponse>> Execute(CreateTaxRequest request, string appUserId)
    {
        var taxResult = Tax.Create(request.Name, request.Description, request.Rate, appUserId);
        if (taxResult.IsError)
        {
            return Result.Error(taxResult.ErrorMessage);
        }

        var tax = taxResult.Value;
        dbContext.Set<Tax>().Add(tax);
        await dbContext.SaveChangesAsync();

        return new CreateTaxResponse(tax.Id, tax.Name, tax.Description, tax.Rate);
    }
}
