﻿namespace InvadePay.Invoicing.Core.Features.Taxes.Create;

public record CreateTaxRequest(
    string Name,
    string? Description,
    decimal Rate);