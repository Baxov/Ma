﻿namespace InvadePay.Invoicing.Core.Features.Taxes.Create;

public record CreateTaxResponse(
    long Id,
    string Name,
    string? Description,
    decimal Rate);
