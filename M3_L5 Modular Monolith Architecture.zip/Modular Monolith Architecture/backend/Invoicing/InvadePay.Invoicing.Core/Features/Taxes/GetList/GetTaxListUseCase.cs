﻿using InvadePay.Common.Responses;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Taxes.GetList;

public class GetTaxListUseCase(IDbContext dbContext)
{
    public async Task<PagedResponse<TaxResponse>> Execute(int page, int pageSize, string appUserId)
    {
        if (page == 0)
        {
            page = 1;
        }

        if (pageSize == 0)
        {
            pageSize = 10;
        }

        var query = dbContext.Set<Tax>()
            .Where(x => x.AppUserId == appUserId)
            .OrderBy(x => x.Name);

        var totalCount = await query.CountAsync();

        var items = await query
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(x => new TaxResponse(x.Id, x.Name, x.Description, x.Rate))
            .ToListAsync();

        return new PagedResponse<TaxResponse>(items, totalCount);
    }
}
