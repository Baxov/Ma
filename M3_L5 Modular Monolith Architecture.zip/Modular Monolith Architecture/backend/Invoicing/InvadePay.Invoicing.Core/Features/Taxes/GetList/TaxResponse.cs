﻿namespace InvadePay.Invoicing.Core.Features.Taxes.GetList;

public record TaxResponse(
    long Id,
    string Name,
    string? Description,
    decimal Rate);
