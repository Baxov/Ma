﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Taxes.GetById;

public class GetTaxByIdUseCase(IDbContext dbContext)
{
    public async Task<Result<SingleTaxResponse>> Execute(long id, string appUserId)
    {
        var tax = await dbContext.Set<Tax>()
            .Where(x => x.Id == id && x.AppUserId == appUserId)
            .Select(x => new SingleTaxResponse(x.Id, x.Name, x.Description, x.Rate))
            .FirstOrDefaultAsync();

        if (tax == null)
        {
            return Result.NotFound($"Tax with id {id} was not found.");
        }

        return tax;
    }
}
