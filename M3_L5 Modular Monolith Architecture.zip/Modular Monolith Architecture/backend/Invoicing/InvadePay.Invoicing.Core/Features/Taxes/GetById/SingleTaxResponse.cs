﻿namespace InvadePay.Invoicing.Core.Features.Taxes.GetById;

public record SingleTaxResponse(
    long Id,
    string Name,
    string? Description,
    decimal Rate);
