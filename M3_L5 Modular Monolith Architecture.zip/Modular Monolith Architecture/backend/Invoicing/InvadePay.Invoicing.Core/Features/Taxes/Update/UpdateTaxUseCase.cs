﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Taxes.Update;

public class UpdateTaxUseCase(IDbContext dbContext)
{
    public async Task<Result<UpdateTaxResponse>> Execute(long id, UpdateTaxRequest request, string appUserId)
    {
        var tax = await dbContext.Set<Tax>()
            .FirstOrDefaultAsync(x => x.Id == id && x.AppUserId == appUserId);

        if (tax == null)
        {
            return Result.NotFound($"Tax with id {id} was not found.");
        }

        var updateResult = tax.Update(request.Name, request.Description, request.Rate);
        if (updateResult.IsError)
        {
            return Result.Error(updateResult.ErrorMessage);
        }

        await dbContext.SaveChangesAsync();

        return new UpdateTaxResponse(tax.Id, tax.Name, tax.Description, tax.Rate);
    }
}
