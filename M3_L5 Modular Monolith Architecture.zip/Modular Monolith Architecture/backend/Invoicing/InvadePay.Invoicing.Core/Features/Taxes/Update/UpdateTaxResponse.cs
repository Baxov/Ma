﻿namespace InvadePay.Invoicing.Core.Features.Taxes.Update;

public record UpdateTaxResponse(
    long Id,
    string Name,
    string? Description,
    decimal Rate);
