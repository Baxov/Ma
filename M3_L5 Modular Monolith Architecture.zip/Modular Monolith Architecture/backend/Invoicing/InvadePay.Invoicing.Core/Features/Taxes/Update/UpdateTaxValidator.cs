﻿using FluentValidation;
using InvadePay.Invoicing.Core.Models.Invoices;

namespace InvadePay.Invoicing.Core.Features.Taxes.Update;

public class UpdateTaxValidator : AbstractValidator<UpdateTaxRequest>
{
    public UpdateTaxValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty()
            .MaximumLength(Tax.MaxLengths.Name);

        RuleFor(x => x.Description)
            .MaximumLength(Tax.MaxLengths.Description)
            .When(x => !string.IsNullOrEmpty(x.Description));

        RuleFor(x => x.Rate)
            .GreaterThanOrEqualTo(0)
            .LessThanOrEqualTo(100)
            .WithMessage("Tax rate must be between 0 and 100 percent.");
    }
}
