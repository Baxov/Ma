﻿namespace InvadePay.Invoicing.Core.Features.Taxes.Update;

public record UpdateTaxRequest(
    string Name,
    string? Description,
    decimal Rate);