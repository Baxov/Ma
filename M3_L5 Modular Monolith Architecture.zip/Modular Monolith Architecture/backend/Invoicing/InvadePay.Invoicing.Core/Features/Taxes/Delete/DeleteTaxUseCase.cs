﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Taxes.Delete;

public class DeleteTaxUseCase(IDbContext dbContext)
{
    public async Task<Result> Execute(long id, string appUserId)
    {
        var tax = await dbContext.Set<Tax>()
            .FirstOrDefaultAsync(x => x.Id == id && x.AppUserId == appUserId);

        if (tax == null)
        {
            return Result.NotFound($"Tax with id {id} was not found.");
        }
        
         var invoicesUsingTax = await dbContext.Set<Invoice>()
             .Where(x => x.TaxId == id)
             .AnyAsync();
        
         if (invoicesUsingTax)
         {
             return Result.Conflict("Tax cannot be deleted because it is used in invoices.");
         }
        
        dbContext.Set<Tax>().Remove(tax);
        await dbContext.SaveChangesAsync();

        return Result.Success();
    }
}
