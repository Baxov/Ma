using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Customers.Create;

public class CreateCustomerUseCase(
    IDbContext dbContext
    /*, ICustomerCrmService customerCrmService*/)
{
    public async Task<Result<CreateCustomerResponse>> Execute(CreateCustomerRequest request, string appUserId)
    {
        var existingCustomer = await dbContext.Set<Customer>()
            .FirstOrDefaultAsync(x => x.Email == request.Email && x.AppUserId == appUserId);

        if (existingCustomer != null)
        {
            return Result.Conflict("A customer with this email already exists.");
        }

        var customerResult = Customer.Create(request.Name, request.Email, appUserId);
        if (customerResult.IsError)
        {
            return Result.UnprocessableEntity(customerResult.ErrorMessage);
        }
        var customer = customerResult.Value;

        dbContext.Set<Customer>().Add(customer);
        await dbContext.SaveChangesAsync();

        return new CreateCustomerResponse(customer.Id, customer.Name, customer.Email);
    }
}

public interface ICustomerCrmService
{
    Task SyncCustomer(Customer customer);
}

public class CustomerCrmService : ICustomerCrmService
{
    public Task SyncCustomer(Customer customer)
    {
        return Task.CompletedTask;
    }
}
