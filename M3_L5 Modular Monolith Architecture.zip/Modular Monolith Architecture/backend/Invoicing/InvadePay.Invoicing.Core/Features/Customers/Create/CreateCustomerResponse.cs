namespace InvadePay.Invoicing.Core.Features.Customers.Create;

public record CreateCustomerResponse(
    long Id,
    string Name,
    string Email);