﻿namespace InvadePay.Invoicing.Core.Features.Customers.Create;

public record CreateCustomerRequest(
    string Name,
    string Email);