using FluentValidation;
using InvadePay.Invoicing.Core.Models.Customers;

namespace InvadePay.Invoicing.Core.Features.Customers.Create;

public class CreateCustomerValidator : AbstractValidator<CreateCustomerRequest>
{
    public CreateCustomerValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty()
            .MaximumLength(Customer.MaxLengths.Name);

        RuleFor(x => x.Email)
            .NotEmpty()
            .EmailAddress()
            .MaximumLength(Customer.MaxLengths.Email);
    }
}