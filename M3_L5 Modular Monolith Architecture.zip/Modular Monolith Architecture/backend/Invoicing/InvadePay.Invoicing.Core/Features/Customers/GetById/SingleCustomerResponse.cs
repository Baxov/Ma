﻿namespace InvadePay.Invoicing.Core.Features.Customers.GetById;

public record SingleCustomerResponse(
    long Id,
    string Name,
    string Email);