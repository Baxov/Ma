﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Customers.GetById;

public class GetCustomerByIdUseCase(IDbContext dbContext)
{
    public async Task<Result<SingleCustomerResponse>> Execute(long id)
    {
        var customer = await dbContext.Set<Customer>()
            .Where(x => x.Id == id)
            .Select(x => new SingleCustomerResponse(x.Id, x.Name, x.Email))
            .FirstOrDefaultAsync();

        if (customer == null)
        {
            return Result.NotFound($"Customer with id {id} was not found.");
        }

        return customer;
    }
}
