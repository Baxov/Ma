namespace InvadePay.Invoicing.Core.Features.Customers.GetList;

public record CustomerResponse(
    long Id,
    string Name,
    string Email);