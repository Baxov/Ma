﻿using InvadePay.Common.Responses;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Customers.GetList;

public class GetCustomerListUseCase(IDbContext dbContext)
{
    public async Task<PagedResponse<CustomerResponse>> Execute(int page, int pageSize, string appUserId)
    {
        if (page == 0)
        {
            page = 1;
        }

        if (pageSize == 0)
        {
            pageSize = 10;
        }

        var query = dbContext.Set<Customer>()
            .Where(x => x.AppUserId == appUserId)
            .OrderBy(x => x.Name);

        var totalCount = await query.CountAsync();

        var items = await query
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(x => new CustomerResponse(x.Id, x.Name, x.Email))
            .ToListAsync();
        
        return new PagedResponse<CustomerResponse>(items, totalCount);
    }
}
