﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Invoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Customers.Statement;

public class CustomerStatementUseCase(IDbContext dbContext)
{
    public async Task<Result<CustomerStatementResponse>> Execute(CustomerStatementRequest request, string userId)
    {
        var customer = await dbContext.Set<Customer>()
            .Where(x => x.Id == request.CustomerId && x.AppUserId == userId)
            .FirstOrDefaultAsync();

        if (customer == null)
        {
            return Result.NotFound($"Customer with id {request.CustomerId} was not found.");
        }
        
        if (request.StartDate > request.EndDate)
        {
            return Result.UnprocessableEntity("Start date cannot be after end date.");
        }
        
        var invoiceProjections = await dbContext.Set<Invoice>()
            .Where(x => x.CustomerId == request.CustomerId &&
                       x.AppUserId == userId &&
                       x.Date >= DateOnly.FromDateTime(request.StartDate) &&
                       x.Date <= DateOnly.FromDateTime(request.EndDate.AddHours(23).AddMinutes(59).AddSeconds(59)))
            .Select(x => new
            {
                x.Id,
                x.InvoiceNumber,
                x.Date,
                x.Status,
                TaxName = x.Tax != null ? x.Tax.Name : null,
                TaxRate = x.Tax != null ? x.Tax.Rate : (decimal?)null,
                Items = x.Items.Select(i => new
                {
                    i.Quantity,
                    i.Price,
                    i.Discount
                }).ToList()
            })
            .OrderByDescending(x => x.Date)
            .ToListAsync();

        var outstandingInvoices = new List<StatementInvoiceItem>();
        var paidInvoices = new List<StatementInvoiceItem>();

        decimal totalOutstanding = 0;
        decimal totalPaid = 0;

        foreach (var invoice in invoiceProjections)
        {
            var subtotalAmount = invoice.Items.Sum(i =>
                i.Quantity * i.Price - ((i.Discount ?? 0) > 0 ? (i.Quantity * i.Price * (i.Discount ?? 0)) / 100 : 0));
            var taxAmount = invoice.TaxRate != null ? (subtotalAmount * invoice.TaxRate.Value) / 100 : 0;
            var totalAmount = subtotalAmount + taxAmount;

            var statementItem = new StatementInvoiceItem(
                invoice.Id,
                InvoiceNumberFormatter.Format(invoice.InvoiceNumber),
                invoice.Date.ToDateTime(TimeOnly.MinValue),
                invoice.Status.ToString(),
                subtotalAmount,
                taxAmount,
                totalAmount,
                invoice.TaxName,
                invoice.TaxRate
            );

            if (invoice.Status == InvoiceStatus.Paid)
            {
                paidInvoices.Add(statementItem);
                totalPaid += totalAmount;
            }
            else if (invoice.Status == InvoiceStatus.Sent)
            {
                outstandingInvoices.Add(statementItem);
                totalOutstanding += totalAmount;
            }
        }
        
        var accountBalance = totalPaid - totalOutstanding;

        return new CustomerStatementResponse(
            customer.Id,
            customer.Name,
            customer.Email,
            request.StartDate,
            request.EndDate,
            totalOutstanding,
            totalPaid,
            accountBalance,
            outstandingInvoices,
            paidInvoices
        );
    }
}
