﻿namespace InvadePay.Invoicing.Core.Features.Customers.Statement;

public record CustomerStatementResponse(
    long CustomerId,
    string CustomerName,
    string CustomerEmail,
    DateTime StatementStartDate,
    DateTime StatementEndDate,
    decimal TotalOutstanding,
    decimal TotalPaid,
    decimal AccountBalance,
    List<StatementInvoiceItem> OutstandingInvoices,
    List<StatementInvoiceItem> PaidInvoices
);

public record StatementInvoiceItem(
    long InvoiceId,
    string InvoiceNumber,
    DateTime InvoiceDate,
    string Status,
    decimal SubtotalAmount,
    decimal TaxAmount,
    decimal TotalAmount,
    string? TaxName,
    decimal? TaxRate
);
