﻿namespace InvadePay.Invoicing.Core.Features.Customers.Statement;

public record CustomerStatementRequest(
    long CustomerId,
    DateTime StartDate,
    DateTime EndDate
);
