using FluentValidation;
using InvadePay.Invoicing.Core.Models.Customers;

namespace InvadePay.Invoicing.Core.Features.Customers.Update;

public class UpdateCustomerValidator : AbstractValidator<UpdateCustomerRequest>
{
    public UpdateCustomerValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty()
            .MaximumLength(Customer.MaxLengths.Name);

        RuleFor(x => x.Email)
            .NotEmpty()
            .EmailAddress()
            .MaximumLength(Customer.MaxLengths.Email);
    }
}