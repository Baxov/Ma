using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Customers.Update;

public class UpdateCustomerUseCase(IDbContext dbContext)
{
    public async Task<Result<UpdateCustomerResponse>> Execute(long id, UpdateCustomerRequest request)
    {
        var customer = await dbContext.Set<Customer>()
            .FirstOrDefaultAsync(x => x.Id == id);

        if (customer == null)
        {
            return Result.NotFound($"Customer with id {id} was not found.");
        }

        var existingCustomer = await dbContext.Set<Customer>()
            .FirstOrDefaultAsync(x => x.Email == request.Email && x.Id != id && x.AppUserId == customer.AppUserId);

        if (existingCustomer != null)
        {
            return Result.Conflict("A customer with this email already exists.");
        }

        customer.Name = request.Name;
        customer.Email = request.Email;

        await dbContext.SaveChangesAsync();

        return new UpdateCustomerResponse(customer.Id, customer.Name, customer.Email);
    }
}