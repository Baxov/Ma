namespace InvadePay.Invoicing.Core.Features.Customers.Update;

public record UpdateCustomerResponse(
    long Id,
    string Name,
    string Email);