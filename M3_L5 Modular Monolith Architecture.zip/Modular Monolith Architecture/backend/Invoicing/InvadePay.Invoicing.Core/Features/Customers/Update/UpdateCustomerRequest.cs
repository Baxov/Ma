﻿namespace InvadePay.Invoicing.Core.Features.Customers.Update;

public record UpdateCustomerRequest(
    string Name,
    string Email);