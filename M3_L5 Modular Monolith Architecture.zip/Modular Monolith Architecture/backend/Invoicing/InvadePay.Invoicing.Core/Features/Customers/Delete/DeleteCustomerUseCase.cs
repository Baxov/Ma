using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Customers.Delete;

public class DeleteCustomerUseCase(IDbContext dbContext)
{
    public async Task<Result> Execute(long id)
    {
        var customer = await dbContext.Set<Customer>()
            .FirstOrDefaultAsync(x => x.Id == id);

        if (customer == null)
        {
            return Result.NotFound($"Customer with id {id} was not found.");
        }

        var hasInvoices = await dbContext.Set<Invoice>()
            .AnyAsync(x => x.CustomerId == id);

        if (hasInvoices)
        {
            return Result.Conflict("Customer cannot be deleted because they have invoices.");
        }

        dbContext.Set<Customer>().Remove(customer);
        await dbContext.SaveChangesAsync();

        return Result.Success();
    }
}