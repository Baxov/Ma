﻿namespace InvadePay.Invoicing.Core.Features.Invoices.Create;

public record CreateInvoiceResponse(
    long Id,
    string InvoiceId,
    long CustomerId,
    string CustomerName,
    string CustomerEmail,
    DateOnly Date,
    DateOnly DueDate,
    decimal SubtotalAmount,
    decimal TaxAmount,
    decimal TotalAmount,
    long? TaxId = null,
    string? TaxName = null,
    decimal? TaxRate = null);