﻿using InvadePay.Common.Models;
using InvadePay.Inventory.Contracts;
using InvadePay.Invoicing.Core.Features.Invoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Invoices.Create;

public class CreateInvoiceUseCase(
    IDbContext dbContext,
    IInventoryTracker inventoryTracker,
    InvoiceValidator invoiceValidator)
{
    public async Task<Result<CreateInvoiceResponse>> Execute(CreateInvoiceRequest request, string userId)
    {
        if (!request.Items.Any())
        {
            return Result.UnprocessableEntity("At least one invoice item is required.");
        }

        var invoiceFieldValidationResult = await invoiceValidator.ValidateInvoiceFields(
            [.. request.Items.Select(x => x.ProductId).Distinct()],
            request.TaxId,
            request.CustomerId,
            userId);
        if (invoiceFieldValidationResult.IsError)
        {
            return Result<CreateInvoiceResponse>.From(invoiceFieldValidationResult);
        }

        var productQuantities = request.Items
            .GroupBy(item => item.ProductId)
            .ToDictionary(g => g.Key, g => g.Sum(item => item.Quantity));

        var inventoryValidationResult = await inventoryTracker.ValidateStockAvailability(productQuantities, userId);
        if (inventoryValidationResult.IsError)
        {
            return Result.UnprocessableEntity(inventoryValidationResult.ErrorMessage);
        }

        var userHasInvoices = await dbContext.Set<Invoice>()
            .AnyAsync(x => x.AppUserId == userId);

        var maxInvoiceNumber = 1L;

        if (userHasInvoices)
        {
            maxInvoiceNumber = await dbContext.Set<Invoice>()
                .Where(x => x.AppUserId == userId)
                .MaxAsync(x => x.InvoiceNumber) + 1;
        }

        var invoiceItems = request.Items.Select(item => new InvoiceItem
        {
            ProductId = item.ProductId,
            Quantity = item.Quantity,
            Price = item.Price,
            Discount = item.Discount
        }).ToList();

        var invoiceResult = Invoice.Create(
            maxInvoiceNumber,
            request.CustomerId,
            request.Date,
            request.DueDate,
            request.Time,
            userId,
            invoiceItems,
            request.TaxId);

        if (invoiceResult.IsError)
        {
            return Result.UnprocessableEntity(invoiceResult.ErrorMessage);
        }

        var invoice = invoiceResult.Value;
        dbContext.Set<Invoice>().Add(invoice);

        var inventoryDeductionResult = await inventoryTracker.DeductStock(productQuantities, userId);
        if (inventoryDeductionResult.IsError)
        {
            return Result.UnprocessableEntity(inventoryDeductionResult.ErrorMessage);
        }

        await dbContext.SaveChangesAsync();

        var subtotalAmount = invoice.Items.Sum(i => {
            var itemSubtotal = i.Quantity * i.Price;
            var discountAmount = (i.Discount ?? 0) > 0 ? (itemSubtotal * (i.Discount ?? 0)) / 100 : 0;
            return itemSubtotal - discountAmount;
        });

        var tax = await dbContext.Set<Tax>()
            .FirstOrDefaultAsync(x => x.Id == request.TaxId && x.AppUserId == userId);

        var customer = await dbContext.Set<Customer>()
            .FirstAsync(x => x.Id == request.CustomerId && x.AppUserId == userId);

        var taxAmount = tax != null ? (subtotalAmount * tax.Rate) / 100 : 0;
        var totalAmount = subtotalAmount + taxAmount;

        return new CreateInvoiceResponse(
            invoice.Id,
            InvoiceNumberFormatter.Format(invoice.InvoiceNumber),
            invoice.CustomerId,
            customer.Name,
            customer.Email,
            invoice.Date,
            invoice.DueDate,
            subtotalAmount,
            taxAmount,
            totalAmount,
            tax?.Id,
            tax?.Name,
            tax?.Rate
        );
    }
}
