﻿namespace InvadePay.Invoicing.Core.Features.Invoices.Create;

public record CreateInvoiceRequest(
    long CustomerId,
    DateOnly Date,
    DateOnly DueDate,
    string Time,
    ICollection<CreateInvoiceLineRequest> Items,
    long? TaxId = null);

public record CreateInvoiceLineRequest(
    long ProductId,
    decimal Quantity,
    decimal Price,
    decimal? Discount = null);