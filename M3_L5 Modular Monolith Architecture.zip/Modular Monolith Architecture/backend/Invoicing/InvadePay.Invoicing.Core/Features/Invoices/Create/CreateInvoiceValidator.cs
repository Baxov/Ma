﻿using FluentValidation;

namespace InvadePay.Invoicing.Core.Features.Invoices.Create;

public class CreateInvoiceValidator: AbstractValidator<CreateInvoiceRequest>
{
    public CreateInvoiceValidator()
    {
        RuleFor(x => x.CustomerId)
            .NotEmpty()
            .GreaterThan(0)
            .WithMessage("Customer is required.");
        RuleFor(x => x.Date)
            .NotEmpty();
        RuleFor(x => x.DueDate)
            .NotEmpty();
        RuleFor(x => x.Time)
            .NotEmpty();
        RuleFor(x => x.Items)
            .NotEmpty()
            .WithMessage("At least one invoice item is required.");
        RuleForEach(x => x.Items).SetValidator(new CreateInvoiceLineValidator());
    }
}

public class CreateInvoiceLineValidator : AbstractValidator<CreateInvoiceLineRequest>
{
    public CreateInvoiceLineValidator()
    {
        RuleFor(x => x.ProductId)
            .NotEmpty()
            .GreaterThan(0);
        RuleFor(x => x.Quantity)
            .NotEmpty()
            .GreaterThan(0);
        RuleFor(x => x.Price)
            .NotEmpty()
            .GreaterThan(0);
        RuleFor(x => x.Discount)
            .GreaterThanOrEqualTo(0)
            .When(x => x.Discount.HasValue);
    }
}