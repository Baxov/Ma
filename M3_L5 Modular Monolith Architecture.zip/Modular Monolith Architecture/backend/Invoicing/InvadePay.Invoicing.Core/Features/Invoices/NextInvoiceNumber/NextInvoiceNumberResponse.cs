namespace InvadePay.Invoicing.Core.Features.Invoices.NextInvoiceNumber;

public record NextInvoiceNumberResponse(string InvoiceNumber);