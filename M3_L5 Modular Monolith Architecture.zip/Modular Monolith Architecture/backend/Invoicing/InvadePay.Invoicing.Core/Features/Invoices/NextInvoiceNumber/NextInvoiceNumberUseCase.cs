﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Invoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Invoices.NextInvoiceNumber;

public class NextInvoiceNumberUseCase(IDbContext dbContext)
{
    public async Task<Result<NextInvoiceNumberResponse>> Execute(string userId)
    {
        var userHasInvoices = await dbContext.Set<Invoice>()
            .AnyAsync(x => x.AppUserId == userId);

        var nextInvoiceNumber = 1L;
        
        if (userHasInvoices)
        {
            nextInvoiceNumber = await dbContext.Set<Invoice>()
                .Where(x => x.AppUserId == userId)
                .MaxAsync(x => x.InvoiceNumber) + 1;
        }

        var formattedNumber = InvoiceNumberFormatter.Format(nextInvoiceNumber);
        return new NextInvoiceNumberResponse(formattedNumber);
    }
}