﻿namespace InvadePay.Invoicing.Core.Features.Invoices.SendEmail;

public record SendInvoiceEmailResponse(
    bool Success,
    string Message);
