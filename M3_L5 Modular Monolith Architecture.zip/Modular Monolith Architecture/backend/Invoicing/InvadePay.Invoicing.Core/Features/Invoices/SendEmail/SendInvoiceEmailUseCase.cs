﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Invoices.GeneratePdf;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Invoices.SendEmail;

public class SendInvoiceEmailUseCase(
    IDbContext dbContext,
    IInvoicePdfDataService pdfDataService,
    IInvoicePdfGenerator pdfGenerator,
    IInvoicingEmailSender emailSender)
{
    public async Task<Result<SendInvoiceEmailResponse>> Execute(long invoiceId, string userId)
    {
        var invoice = await dbContext.Set<Invoice>()
            .Include(i => i.Customer)
            .FirstOrDefaultAsync(i => i.Id == invoiceId && i.AppUserId == userId);

        if (invoice == null)
        {
            return Result.NotFound($"Invoice with id {invoiceId} was not found.");
        }
        
        if (invoice.Status == InvoiceStatus.Reversed)
        {
            return Result.Error("Cannot send a reversed invoice.");
        }
        
        var invoicePdfData = await pdfDataService.GetInvoicePdfData(invoiceId, userId);
        if (invoicePdfData == null)
        {
            return Result.Error($"Failed to retrieve invoice data for PDF generation.");
        }

        var pdfBytes = await pdfGenerator.GeneratePdf(invoicePdfData);
        
        var emailResult = await emailSender.SendInvoiceEmail(
            invoice.Customer.Email,
            invoice.Customer.Name,
            invoice.InvoiceNumber.ToString(),
            pdfBytes);

        if (emailResult.IsError)
        {
            return Result.Error($"Failed to send email: {emailResult.ErrorMessage}");
        }
        
        if (invoice.Status == InvoiceStatus.Draft)
        {
            invoice.SetStatusTo(InvoiceStatus.Sent);
            await dbContext.SaveChangesAsync();
        }
        
        return new SendInvoiceEmailResponse( true, $"Invoice {invoice.InvoiceNumber} has been sent successfully to {invoice.Customer.Email}");
    }
}
