﻿using FluentValidation;

namespace InvadePay.Invoicing.Core.Features.Invoices.Update;

public class UpdateInvoiceValidator : AbstractValidator<UpdateInvoiceRequest>
{
    public UpdateInvoiceValidator()
    {
        RuleFor(x => x.CustomerId)
            .NotEmpty()
            .GreaterThan(0)
            .WithMessage("Customer is required.");
        
        RuleFor(x => x.Date)
            .NotEmpty();

        RuleFor(x => x.DueDate)
            .NotEmpty();

        RuleFor(x => x.Time)
            .NotEmpty()
            .Matches(@"^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$")
            .WithMessage("Time must be in HH:mm format");
        
        RuleFor(x => x.Items)
            .NotEmpty()
            .WithMessage("At least one invoice item is required.");
        
        RuleForEach(x => x.Items).SetValidator(new UpdateInvoiceLineValidator());
    }
}

public class UpdateInvoiceLineValidator : AbstractValidator<UpdateInvoiceLineRequest>
{
    public UpdateInvoiceLineValidator()
    {
        RuleFor(x => x.ProductId)
            .NotEmpty()
            .GreaterThan(0);
        
        RuleFor(x => x.Quantity)
            .NotEmpty()
            .GreaterThan(0);
        
        RuleFor(x => x.Price)
            .NotEmpty()
            .GreaterThan(0);
        
        RuleFor(x => x.Discount)
            .GreaterThanOrEqualTo(0)
            .When(x => x.Discount.HasValue);
    }
}
