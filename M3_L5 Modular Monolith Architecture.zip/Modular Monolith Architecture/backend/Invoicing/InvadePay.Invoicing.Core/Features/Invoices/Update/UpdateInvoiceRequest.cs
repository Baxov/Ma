﻿namespace InvadePay.Invoicing.Core.Features.Invoices.Update;

public record UpdateInvoiceRequest(
    long CustomerId,
    DateOnly Date,
    DateOnly DueDate,
    string Time,
    ICollection<UpdateInvoiceLineRequest> Items,
    long? TaxId = null);

public record UpdateInvoiceLineRequest(
    long? Id, // Null for new items, existing ID for updates
    long ProductId,
    decimal Quantity,
    decimal Price,
    decimal? Discount = null);