﻿using InvadePay.Common.Models;
using InvadePay.Inventory.Contracts;
using InvadePay.Invoicing.Core.Features.Invoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Invoices.Update;

public class UpdateInvoiceUseCase(
    IDbContext dbContext,
    IInventoryTracker inventoryTracker,
    InvoiceValidator invoiceValidator)
{
    public async Task<Result<UpdateInvoiceResponse>> Execute(long id, UpdateInvoiceRequest request, string userId)
    {
        var invoice = await dbContext.Set<Invoice>()
            .Include(x => x.Items)
            .Include(x => x.Customer)
            .Include(x => x.Tax)
            .FirstOrDefaultAsync(x => x.Id == id && x.AppUserId == userId);

        if (invoice == null)
        {
            return Result.NotFound($"Invoice with id {id} was not found.");
        }
        
        if (invoice.Status != InvoiceStatus.Draft)
        {
            return Result.UnprocessableEntity($"Cannot update invoice with status {invoice.Status}. Only draft invoices can be updated.");
        }

        if (!request.Items.Any())
        {
            return Result.UnprocessableEntity("At least one invoice item is required.");
        }

        var invoiceFieldValidationResult = await invoiceValidator.ValidateInvoiceFields(
            [.. request.Items.Select(x => x.ProductId).Distinct()],
            request.TaxId,
            request.CustomerId,
            userId);
        if (invoiceFieldValidationResult.IsError)
        {
            return Result<UpdateInvoiceResponse>.From(invoiceFieldValidationResult);
        }

        // Calculate inventory changes
        var oldProductQuantities = invoice.Items
            .GroupBy(item => item.ProductId)
            .ToDictionary(g => g.Key, g => g.Sum(item => item.Quantity));

        var newProductQuantities = request.Items
            .GroupBy(item => item.ProductId)
            .ToDictionary(g => g.Key, g => g.Sum(item => item.Quantity));

        // Restore old stock first
        var restoreResult = await inventoryTracker.RestoreStock(oldProductQuantities, userId);
        if (restoreResult.IsError)
        {
            return Result.UnprocessableEntity(restoreResult.ErrorMessage);
        }

        // Validate new stock availability
        var inventoryValidationResult = await inventoryTracker.ValidateStockAvailability(newProductQuantities, userId);
        if (inventoryValidationResult.IsError)
        {
            // If validation fails, we need to re-deduct the old stock to maintain consistency
            await inventoryTracker.DeductStock(oldProductQuantities, userId);
            return Result.UnprocessableEntity(inventoryValidationResult.ErrorMessage);
        }
        
        invoice.CustomerId = request.CustomerId;
        invoice.Date = request.Date;
        invoice.DueDate = request.DueDate;
        invoice.Time = request.Time;
        invoice.TaxId = request.TaxId;
        
        dbContext.Set<InvoiceItem>().RemoveRange(invoice.Items);
        
        var newInvoiceItems = request.Items.Select(item => new InvoiceItem
        {
            ProductId = item.ProductId,
            Quantity = item.Quantity,
            Price = item.Price,
            Discount = item.Discount,
            Invoice = invoice
        }).ToList();

        invoice.Items = newInvoiceItems;
        
        var inventoryDeductionResult = await inventoryTracker.DeductStock(newProductQuantities, userId);
        if (inventoryDeductionResult.IsError)
        {
            return Result.UnprocessableEntity(inventoryDeductionResult.ErrorMessage);
        }

        await dbContext.SaveChangesAsync();
        
        var subtotalAmount = invoice.Items.Sum(i => {
            var itemSubtotal = i.Quantity * i.Price;
            var discountAmount = (i.Discount ?? 0) > 0 ? (itemSubtotal * (i.Discount ?? 0)) / 100 : 0;
            return itemSubtotal - discountAmount;
        });

        var customer = await dbContext.Set<Customer>()
            .FirstAsync(x => x.Id == request.CustomerId && x.AppUserId == userId);
        
        var tax = await dbContext.Set<Tax>()
            .FirstOrDefaultAsync(x => x.Id == request.TaxId && x.AppUserId == userId);
        
        var taxAmount = tax?.Rate != null ? (subtotalAmount * tax.Rate) / 100 : 0;
        var totalAmount = subtotalAmount + taxAmount;

        return new UpdateInvoiceResponse(
            invoice.Id,
            InvoiceNumberFormatter.Format(invoice.InvoiceNumber),
            customer.Name,
            customer.Email,
            invoice.Date,
            invoice.DueDate,
            invoice.Status.ToString(),
            subtotalAmount,
            taxAmount,
            totalAmount,
            tax?.Id,
            tax?.Name,
            tax?.Rate);
    }
}
