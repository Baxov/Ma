﻿namespace InvadePay.Invoicing.Core.Features.Invoices.GeneratePdf;

public interface IInvoicePdfDataService
{
    Task<InvoicePdfData?> GetInvoicePdfData(long invoiceId, string userId);
}
