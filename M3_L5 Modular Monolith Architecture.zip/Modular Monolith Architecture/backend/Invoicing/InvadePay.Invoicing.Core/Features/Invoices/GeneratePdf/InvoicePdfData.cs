﻿using InvadePay.Invoicing.Core.Features.Invoices.GetById;

namespace InvadePay.Invoicing.Core.Features.Invoices.GeneratePdf;

public record InvoicePdfData(
    long Id,
    string InvoiceNumber,
    string CustomerName,
    string CustomerEmail,
    DateTime Date,
    string Status,
    decimal SubtotalAmount,
    decimal TaxAmount,
    decimal TotalAmount,
    ICollection<InvoiceItemResponse> Items,
    long? TaxId = null,
    string? TaxName = null,
    decimal? TaxRate = null,
    string? CompanyName = null,
    string? CompanyAddress = null,
    string? CompanyEmail = null);
