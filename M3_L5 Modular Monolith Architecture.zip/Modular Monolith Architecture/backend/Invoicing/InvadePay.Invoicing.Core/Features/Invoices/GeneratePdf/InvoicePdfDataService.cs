﻿using InvadePay.Inventory.Contracts;
using InvadePay.Invoicing.Core.Features.Invoices.GetById;
using InvadePay.Invoicing.Core.Features.Invoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.CompanySettings;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Invoices.GeneratePdf;

public class InvoicePdfDataService(IDbContext dbContext, IProductDetailsHandler productDetailsHandler) : IInvoicePdfDataService
{
    public async Task<InvoicePdfData?> GetInvoicePdfData(long invoiceId, string userId)
    {
        var productIds = await dbContext.Set<InvoiceItem>()
            .Where(x => x.InvoiceId == invoiceId)
            .Select(x => x.ProductId)
            .ToListAsync();
        
        var productDetailsResult = await productDetailsHandler.GetMultipleProducts(productIds, userId);
        if (productDetailsResult.IsError)
        {
            return null;
        }
        var productDetails = productDetailsResult.Value;

        var invoiceData = await dbContext
            .Set<Invoice>()
            .Where(x => x.Id == invoiceId && x.AppUserId == userId)
            .Select(x => new
            {
                x.Id,
                x.InvoiceNumber,
                CustomerName = x.Customer.Name,
                CustomerEmail = x.Customer.Email,
                x.Date,
                Status = x.Status.ToString(),
                Items = x.Items.Select(i => new
                {
                    i.Id,
                    i.ProductId,
                    i.Quantity,
                    i.Price,
                    i.Discount,
                    LineTotal = i.Quantity * i.Price - ((i.Discount ?? 0) > 0 ? (i.Quantity * i.Price * (i.Discount ?? 0)) / 100 : 0)
                }).ToList(),
                TaxId = x.TaxId,
                TaxName = x.Tax != null ? x.Tax.Name : null,
                TaxRate = x.Tax != null ? x.Tax.Rate : (decimal?)null,
                x.AppUserId
            })
            .FirstOrDefaultAsync();

        if (invoiceData == null)
        {
            return null;
        }
        
        var items = invoiceData.Items.Select(i => new InvoiceItemResponse(
            i.Id,
            i.ProductId,
            productDetails.First(p => p.Id == i.ProductId).Name,
            i.Quantity,
            i.Price,
            i.Discount,
            i.LineTotal
        )).ToList();

        var companySettings = await dbContext
            .Set<Company>()
            .Where(x => x.AppUserId == invoiceData.AppUserId)
            .Select(x => new
            {
                x.CompanyName,
                x.Address,
                x.Email
            })
            .FirstOrDefaultAsync();

        var subtotalAmount = items.Sum(i => i.LineTotal);
        var taxAmount = invoiceData.TaxRate.HasValue ? (subtotalAmount * invoiceData.TaxRate.Value) / 100 : 0;
        var totalAmount = subtotalAmount + taxAmount;

        var invoicePdfData = new InvoicePdfData(
            invoiceData.Id,
            InvoiceNumberFormatter.Format(invoiceData.InvoiceNumber),
            invoiceData.CustomerName,
            invoiceData.CustomerEmail,
            invoiceData.Date.ToDateTime(TimeOnly.MinValue),
            invoiceData.Status,
            subtotalAmount,
            taxAmount,
            totalAmount,
            items,
            invoiceData.TaxId,
            invoiceData.TaxName,
            invoiceData.TaxRate,
            companySettings?.CompanyName,
            companySettings?.Address,
            companySettings?.Email
        );

        return invoicePdfData;
    }
}
