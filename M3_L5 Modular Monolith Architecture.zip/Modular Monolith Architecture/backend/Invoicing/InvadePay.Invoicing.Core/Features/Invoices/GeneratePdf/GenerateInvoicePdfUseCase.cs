﻿using InvadePay.Common.Models;

namespace InvadePay.Invoicing.Core.Features.Invoices.GeneratePdf;

public class GenerateInvoicePdfUseCase(
    IInvoicePdfDataService pdfDataService,
    IInvoicePdfGenerator pdfGenerator)
{
    public async Task<Result<byte[]>> Execute(long id, string userId)
    {
        var invoicePdfData = await pdfDataService.GetInvoicePdfData(id, userId);

        if (invoicePdfData == null)
        {
            return Result.NotFound($"Invoice with id {id} was not found.");
        }

        var pdfBytes = await pdfGenerator.GeneratePdf(invoicePdfData);

        return pdfBytes;
    }
}
