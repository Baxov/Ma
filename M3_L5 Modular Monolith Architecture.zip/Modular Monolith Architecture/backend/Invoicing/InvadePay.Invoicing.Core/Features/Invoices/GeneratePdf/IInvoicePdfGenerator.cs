﻿namespace InvadePay.Invoicing.Core.Features.Invoices.GeneratePdf;

public interface IInvoicePdfGenerator
{
    Task<byte[]> GeneratePdf(InvoicePdfData invoice);
}
