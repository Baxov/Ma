using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Invoices.UpdateStatus;

public class UpdateInvoiceStatusUseCase(IDbContext dbContext)
{
    public async Task<Result> Execute(long invoiceId, string statusString, string userId)
    {
        if (!Enum.TryParse<InvoiceStatus>(statusString, true, out var newStatus))
        {
            return Result.Error($"Invalid invoice status: {statusString}");
        }
        
        var invoice = await dbContext.Set<Invoice>()
            .FirstOrDefaultAsync(x => x.Id == invoiceId && x.AppUserId == userId);
        if (invoice == null)
        {
            return Result.NotFound("Invoice not found");
        }

        var result = invoice.SetStatusTo(newStatus);
        if (result.IsError)
        {
            return result;
        }
        
        await dbContext.SaveChangesAsync();
        return Result.Success();
    }
}