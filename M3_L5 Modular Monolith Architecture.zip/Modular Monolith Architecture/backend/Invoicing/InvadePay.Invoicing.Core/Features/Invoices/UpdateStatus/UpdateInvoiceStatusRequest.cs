namespace InvadePay.Invoicing.Core.Features.Invoices.UpdateStatus;

public record UpdateInvoiceStatusRequest(string Status);
