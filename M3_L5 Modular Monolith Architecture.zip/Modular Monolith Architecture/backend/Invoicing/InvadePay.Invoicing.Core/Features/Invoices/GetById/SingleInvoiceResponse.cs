﻿namespace InvadePay.Invoicing.Core.Features.Invoices.GetById;

public record InvoiceItemResponse(
    long Id,
    long ProductId,
    string ProductName,
    decimal Quantity,
    decimal Price,
    decimal? Discount,
    decimal LineTotal);

public record SingleInvoiceResponse(
    long Id,
    string InvoiceNumber,
    string CustomerName,
    string CustomerEmail,
    long CustomerId,
    DateOnly Date,
    DateOnly DueDate,
    string Time,
    string Status,
    decimal SubtotalAmount,
    decimal TaxAmount,
    decimal TotalAmount,
    ICollection<InvoiceItemResponse> Items,
    long? TaxId = null,
    string? TaxName = null,
    decimal? TaxRate = null);