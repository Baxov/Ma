﻿using InvadePay.Common.Models;
using InvadePay.Inventory.Contracts;
using InvadePay.Invoicing.Core.Features.Invoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Invoices.GetById;

public class GetInvoiceByIdUseCase(IDbContext dbContext,  IProductDetailsHandler productDetailsHandler)
{
    public async Task<Result<SingleInvoiceResponse>> Execute(long id, string userId)
    {
        var productIds = await dbContext.Set<InvoiceItem>()
            .Where(x => x.InvoiceId == id)
            .Select(x => x.ProductId)
            .ToListAsync();
        var productDetailsResult = await productDetailsHandler.GetMultipleProducts(productIds, userId);
        if (productDetailsResult.IsError)
        {
            return Result<SingleInvoiceResponse>.From(productDetailsResult);
        }
        var productDetails = productDetailsResult.Value;
        
        var invoice = await dbContext
            .Set<Invoice>()
            .Where(x => x.Id == id && x.AppUserId == userId)
            .Select(x => new
            {
                x.Id,
                x.InvoiceNumber,
                CustomerName = x.Customer.Name,
                CustomerEmail = x.Customer.Email,
                x.CustomerId,
                x.Date,
                x.DueDate,
                x.Time,
                Status = x.Status.ToString(),
                Items = x.Items.Select(i => new
                {
                    i.Id,
                    i.ProductId,
                    i.Quantity,
                    i.Price,
                    i.Discount,
                    LineTotal = i.Quantity * i.Price - ((i.Discount ?? 0) > 0 ? (i.Quantity * i.Price * (i.Discount ?? 0)) / 100 : 0)
                }).ToList(),
                TaxId = x.TaxId,
                TaxName = x.Tax != null ? x.Tax.Name : null,
                TaxRate = x.Tax != null ? x.Tax.Rate : (decimal?)null
            })
            .FirstOrDefaultAsync();

        if (invoice == null)
        {
            return Result.NotFound($"Invoice with id {id} was not found.");
        }
        
        var items = invoice.Items.Select(i => new InvoiceItemResponse(
            i.Id,
            i.ProductId,
            productDetails.First(p => p.Id == i.ProductId).Name,
            i.Quantity,
            i.Price,
            i.Discount,
            i.LineTotal
        )).ToList();

        var subtotalAmount = items.Sum(i => i.LineTotal);
        
        var taxAmount = invoice.TaxRate.HasValue ? (subtotalAmount * invoice.TaxRate.Value) / 100 : 0;
        var totalAmount = subtotalAmount + taxAmount;

        return new SingleInvoiceResponse(
            invoice.Id,
            InvoiceNumberFormatter.Format(invoice.InvoiceNumber),
            invoice.CustomerName,
            invoice.CustomerEmail,
            invoice.CustomerId,
            invoice.Date,
            invoice.DueDate,
            invoice.Time,
            invoice.Status,
            subtotalAmount,
            taxAmount,
            totalAmount,
            items,
            invoice.TaxId,
            invoice.TaxName,
            invoice.TaxRate
        );
    }
}
