namespace InvadePay.Invoicing.Core.Features.Invoices.Shared;

public static class InvoiceNumberFormatter
{
    public static string Format(long invoiceNumber)
    {
        return $"{invoiceNumber}-1-1";
    }
}