﻿using InvadePay.Common.Responses;
using InvadePay.Invoicing.Core.Features.Invoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Invoices.GetList;

public class GetInvoiceListUseCase(IDbContext dbContext)
{
    public async Task<PagedResponse<InvoiceResponse>> Execute(int page, int pageSize, string? search, string userId)
    {
        if (page == 0)
        {
            page = 1;
        }
        if (pageSize == 0)
        {
            pageSize = 10;
        }

        var query = dbContext
            .Set<Invoice>()
            .Where(x => x.AppUserId == userId);

        if (!string.IsNullOrWhiteSpace(search))
        {
            var specification = new InvoiceSearchSpecification(search);
            query = query.Where(specification.Criteria);
        }

        var totalCount = await query.CountAsync();

        var items = await query
            .OrderByDescending(x => x.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(x => new
            {
                x.Id,
                x.InvoiceNumber,
                CustomerName = x.Customer.Name,
                CustomerEmail = x.Customer.Email,
                x.Date,
                x.DueDate,
                Status = x.Status.ToString(),
                ItemsSubtotal = x.Items.Sum(i => i.Quantity * i.Price - ((i.Discount ?? 0) > 0 ? (i.Quantity * i.Price * (i.Discount ?? 0)) / 100 : 0)),
                TaxId = x.TaxId,
                TaxName = x.Tax != null ? x.Tax.Name : null,
                TaxRate = x.Tax != null ? x.Tax.Rate : (decimal?)null
            })
            .ToListAsync();
        
        var invoiceResponses = items.Select(x =>
        {
            var subtotalAmount = x.ItemsSubtotal;
            var taxAmount = x.TaxRate.HasValue ? (subtotalAmount * x.TaxRate.Value) / 100 : 0;
            var totalAmount = subtotalAmount + taxAmount;

            return new InvoiceResponse(
                x.Id,
                InvoiceNumberFormatter.Format(x.InvoiceNumber),
                x.CustomerName,
                x.CustomerEmail,
                x.Date,
                x.DueDate,
                x.Status,
                subtotalAmount,
                taxAmount,
                totalAmount,
                x.TaxId,
                x.TaxName,
                x.TaxRate
            );
        }).ToList();

        return new PagedResponse<InvoiceResponse>(invoiceResponses, totalCount);
    }
}
