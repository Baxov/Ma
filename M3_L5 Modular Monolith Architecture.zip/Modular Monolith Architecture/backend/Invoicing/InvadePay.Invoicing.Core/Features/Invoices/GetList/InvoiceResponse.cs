﻿namespace InvadePay.Invoicing.Core.Features.Invoices.GetList;

public record InvoiceResponse(
    long Id,
    string InvoiceNumber,
    string CustomerName,
    string CustomerEmail,
    DateOnly Date,
    DateOnly DueDate,
    string Status,
    decimal SubtotalAmount,
    decimal TaxAmount,
    decimal TotalAmount,
    long? TaxId = null,
    string? TaxName = null,
    decimal? TaxRate = null);