﻿using InvadePay.Common.Database;
using InvadePay.Invoicing.Core.Models.Invoices;

namespace InvadePay.Invoicing.Core.Features.Invoices.GetList;

public class InvoiceSearchSpecification: SpecificationPattern<Invoice>
{
    public InvoiceSearchSpecification(string search)
    {
        var searchLower = search.ToLower();
        Criteria = invoice => 
            invoice.InvoiceNumber.ToString().Contains(searchLower) ||
            invoice.Customer.Name.Contains(searchLower) ||
            invoice.Customer.Email.Contains(searchLower) ||
            invoice.Status.ToString().ToLower().Contains(searchLower);
    }
}