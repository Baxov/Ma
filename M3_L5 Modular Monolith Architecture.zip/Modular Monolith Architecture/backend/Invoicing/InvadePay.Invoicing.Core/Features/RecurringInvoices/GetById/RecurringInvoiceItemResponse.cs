﻿namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.GetById;

public record RecurringInvoiceItemResponse(
    long Id,
    long ProductId,
    string ProductName,
    decimal Quantity,
    decimal Price,
    decimal? Discount,
    decimal Total);

public record SingleRecurringInvoiceResponse(
    long Id,
    string CustomerName,
    string CustomerEmail,
    string Time,
    string Frequency,
    DateOnly StartDate,
    DateOnly? EndDate,
    DateOnly? NextRunDate,
    bool IsActive,
    ICollection<RecurringInvoiceItemResponse> Items,
    long? TaxId = null,
    string? TaxName = null,
    decimal? TaxRate = null);
