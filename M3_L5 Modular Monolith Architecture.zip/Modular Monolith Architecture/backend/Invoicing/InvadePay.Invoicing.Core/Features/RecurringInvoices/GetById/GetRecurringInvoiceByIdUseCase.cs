﻿using InvadePay.Common.Models;
using InvadePay.Inventory.Contracts;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.GetById;

public class GetRecurringInvoiceByIdUseCase(IDbContext dbContext, IProductDetailsHandler productDetailsHandler)
{
    public async Task<Result<SingleRecurringInvoiceResponse>> Execute(long id, string userId)
    {
        var productIds = await dbContext.Set<RecurringInvoiceItem>()
            .Where(x => x.RecurringInvoiceId == id)
            .Select(x => x.ProductId)
            .ToListAsync();

        var productDetailsResult = await productDetailsHandler.GetMultipleProducts(productIds, userId);
        if (productDetailsResult.IsError)
        {
            return Result<SingleRecurringInvoiceResponse>.From(productDetailsResult);
        }
        var productDetails = productDetailsResult.Value;

        var recurringInvoice = await dbContext
            .Set<RecurringInvoice>()
            .Where(x => x.Id == id && x.AppUserId == userId)
            .Select(x => new
            {
                x.Id,
                CustomerName = x.Customer.Name,
                CustomerEmail = x.Customer.Email,
                x.Time,
                Frequency = x.Frequency.ToString(),
                x.StartDate,
                x.EndDate,
                x.NextRunDate,
                x.IsActive,
                Items = x.Items.Select(i => new
                {
                    i.Id,
                    i.ProductId,
                    i.Quantity,
                    i.Price,
                    i.Discount,
                    LineTotal = i.Quantity * i.Price - ((i.Discount ?? 0) > 0 ? (i.Quantity * i.Price * (i.Discount ?? 0)) / 100 : 0)
                }).ToList(),
                TaxId = x.TaxId,
                TaxName = x.Tax != null ? x.Tax.Name : null,
                TaxRate = x.Tax != null ? x.Tax.Rate : (decimal?)null
            })
            .FirstOrDefaultAsync();

        if (recurringInvoice == null)
        {
            return Result.NotFound($"Recurring invoice with id {id} was not found.");
        }

        var items = recurringInvoice.Items.Select(i => new RecurringInvoiceItemResponse(
            i.Id,
            i.ProductId,
            productDetails.First(p => p.Id == i.ProductId).Name,
            i.Quantity,
            i.Price,
            i.Discount,
            i.LineTotal
        )).ToList();

        return new SingleRecurringInvoiceResponse(
            recurringInvoice.Id,
            recurringInvoice.CustomerName,
            recurringInvoice.CustomerEmail,
            recurringInvoice.Time,
            recurringInvoice.Frequency,
            recurringInvoice.StartDate,
            recurringInvoice.EndDate,
            recurringInvoice.NextRunDate,
            recurringInvoice.IsActive,
            items,
            recurringInvoice.TaxId,
            recurringInvoice.TaxName,
            recurringInvoice.TaxRate
        );
    }
}
