﻿
namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.Shared;

public interface IRecurringInvoiceJobService
{
    Task ScheduleRecurringInvoice(long recurringInvoiceId);
    void UnscheduleRecurringInvoice(string hangfireJobId);
}