﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.Delete;

public class DeleteRecurringInvoiceUseCase(IDbContext dbContext, IRecurringInvoiceJobService recurringInvoiceJobService)
{
    public async Task<Result> Execute(long id, string appUserId)
    {
        var recurringInvoice = await dbContext.Set<RecurringInvoice>()
            .FirstOrDefaultAsync(x => x.Id == id && x.AppUserId == appUserId);

        if (recurringInvoice == null)
        {
            return Result.NotFound($"Recurring invoice with id {id} was not found.");
        }

        if (!string.IsNullOrEmpty(recurringInvoice.HangfireJobId))
        {
            recurringInvoiceJobService.UnscheduleRecurringInvoice(recurringInvoice.HangfireJobId);
        }
        
        dbContext.Set<RecurringInvoice>().Remove(recurringInvoice);
        await dbContext.SaveChangesAsync();

        return Result.Success();
    }
}
