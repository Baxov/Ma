﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.Update;

public class UpdateRecurringInvoiceUseCase(IDbContext dbContext, IRecurringInvoiceJobService scheduler)
{
    public async Task<Result<UpdateRecurringInvoiceResponse>> Execute(long id, UpdateRecurringInvoiceRequest request, string userId)
    {
        var recurringInvoice = await dbContext.Set<RecurringInvoice>()
            .FirstOrDefaultAsync(x => x.Id == id && x.AppUserId == userId);

        if (recurringInvoice == null)
        {
            return Result.NotFound($"Recurring invoice with id {id} was not found.");
        }
        
        if (!Enum.TryParse<RecurringFrequency>(request.Frequency, true, out var frequency))
        {
            return Result.UnprocessableEntity($"Invalid frequency: {request.Frequency}");
        }

        if (request.StartDate != recurringInvoice.StartDate && request.StartDate < DateOnly.FromDateTime(DateTime.Today))
        {
            return Result.UnprocessableEntity("Start date cannot be in the past.");
        }

        if (request.EndDate.HasValue && request.EndDate.Value <= request.StartDate)
        {
            return Result.UnprocessableEntity("End date must be after start date.");
        }

        // Store the current job ID for rescheduling
        var currentJobId = recurringInvoice.HangfireJobId;

        // Update the recurring invoice
        recurringInvoice.UpdateSchedule(frequency, request.StartDate, request.EndDate);

        if (request.IsActive)
        {
            recurringInvoice.Activate();
        }
        else
        {
            recurringInvoice.Deactivate();
        }

        await dbContext.SaveChangesAsync();

        // Reschedule the job with new settings
        if (!string.IsNullOrEmpty(currentJobId))
        {
            scheduler.UnscheduleRecurringInvoice(currentJobId);
        }

        if (request.IsActive)
        {
            await scheduler.ScheduleRecurringInvoice(recurringInvoice.Id);
        }

        return new UpdateRecurringInvoiceResponse(
            recurringInvoice.Id,
            frequency.ToString(),
            recurringInvoice.StartDate,
            recurringInvoice.EndDate,
            recurringInvoice.NextRunDate,
            recurringInvoice.IsActive
        );
    }
}
