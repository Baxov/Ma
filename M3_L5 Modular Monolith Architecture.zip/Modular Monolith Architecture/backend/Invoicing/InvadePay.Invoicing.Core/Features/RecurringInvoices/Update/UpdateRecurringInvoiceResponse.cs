﻿namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.Update;

public record UpdateRecurringInvoiceResponse(
    long Id,
    string Frequency,
    DateOnly StartDate,
    DateOnly? EndDate,
    DateOnly? NextRunDate,
    bool IsActive);
