﻿using FluentValidation;
using InvadePay.Invoicing.Core.Models.Invoices;

namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.Update;

public class UpdateRecurringInvoiceValidator : AbstractValidator<UpdateRecurringInvoiceRequest>
{
    public UpdateRecurringInvoiceValidator()
    {
        RuleFor(x => x.Frequency)
            .NotEmpty()
            .Must(BeValidFrequency)
            .WithMessage("Frequency must be one of: Weekly, Monthly, Quarterly, Yearly");
        
        RuleFor(x => x.StartDate)
            .NotEmpty()
            .WithMessage("Start date is required.");
        
        RuleFor(x => x.EndDate)
            .GreaterThan(x => x.StartDate)
            .When(x => x.EndDate.HasValue)
            .WithMessage("End date must be after start date.");
    }

    private static bool BeValidFrequency(string frequency)
    {
        return Enum.TryParse<RecurringFrequency>(frequency, true, out _);
    }
}
