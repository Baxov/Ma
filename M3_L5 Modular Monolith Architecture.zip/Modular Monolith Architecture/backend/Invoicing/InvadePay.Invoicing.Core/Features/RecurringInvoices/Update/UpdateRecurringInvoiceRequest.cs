﻿namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.Update;

public record UpdateRecurringInvoiceRequest(
    string Frequency,
    DateOnly StartDate,
    DateOnly? EndDate,
    bool IsActive);