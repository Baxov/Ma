﻿namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.GetList;

public record RecurringInvoiceListResponse(
    long Id,
    string CustomerName,
    string CustomerEmail,
    string Frequency,
    DateOnly StartDate,
    DateOnly? EndDate,
    DateOnly? NextRunDate,
    bool IsActive,
    string? TaxName = null);

public record PagedRecurringInvoiceListResponse(
    ICollection<RecurringInvoiceListResponse> Items,
    int TotalCount,
    int Page,
    int PageSize);
