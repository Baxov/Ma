﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.GetList;

public class GetRecurringInvoiceListUseCase(IDbContext dbContext)
{
    public async Task<Result<PagedRecurringInvoiceListResponse>> Execute(int page, int pageSize, string userId)
    {
        if (page < 1)
        {
            page = 1;
        }
        if (pageSize is < 1 or > 100)
        {
            pageSize = 10;
        }

        var query = dbContext.Set<RecurringInvoice>()
            .Where(x => x.AppUserId == userId);

        var totalCount = await query.CountAsync();

        var recurringInvoices = await query
            .OrderByDescending(x => x.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(x => new RecurringInvoiceListResponse(
                x.Id,
                x.Customer.Name,
                x.Customer.Email,
                x.Frequency.ToString(),
                x.StartDate,
                x.EndDate,
                x.NextRunDate,
                x.IsActive,
                x.Tax != null ? x.Tax.Name : null
            ))
            .ToListAsync();

        return new PagedRecurringInvoiceListResponse(
            recurringInvoices,
            totalCount,
            page,
            pageSize
        );
    }
}
