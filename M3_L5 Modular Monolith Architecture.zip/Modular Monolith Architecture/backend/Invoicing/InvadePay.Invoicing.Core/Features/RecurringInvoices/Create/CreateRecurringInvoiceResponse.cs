﻿namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.Create;

public record CreateRecurringInvoiceResponse(
    long Id,
    string CustomerName,
    string CustomerEmail,
    string Frequency,
    DateOnly StartDate,
    DateOnly? EndDate,
    DateOnly? NextRunDate,
    bool IsActive);
