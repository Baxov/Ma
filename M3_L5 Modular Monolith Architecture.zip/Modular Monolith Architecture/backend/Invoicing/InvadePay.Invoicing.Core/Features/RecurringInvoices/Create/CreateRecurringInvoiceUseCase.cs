﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.Create;

public class CreateRecurringInvoiceUseCase(
    IDbContext dbContext, 
    IRecurringInvoiceJobService recurringInvoiceJobService,
    InvoiceValidator invoiceValidator)
{
    public async Task<Result<CreateRecurringInvoiceResponse>> Execute(CreateRecurringInvoiceRequest request, string userId)
    {

        var invoiceFieldValidationResult = await invoiceValidator.ValidateInvoiceFields(
            [.. request.Items.Select(x => x.ProductId).Distinct()],
            request.TaxId,
            request.CustomerId,
            userId);
        if (invoiceFieldValidationResult.IsError)
        {
            return Result<CreateRecurringInvoiceResponse>.From(invoiceFieldValidationResult);
        }

        // Note: For recurring invoices, we don't deduct inventory here since this is just a template.
        // Inventory will be deducted when the actual invoices are generated from this recurring invoice.
        
        if (!Enum.TryParse<RecurringFrequency>(request.Frequency, true, out var frequency))
        {
            return Result.UnprocessableEntity($"Invalid frequency: {request.Frequency}");
        }
        
        var recurringInvoiceResult = RecurringInvoice.Create(
            userId,
            request.CustomerId,
            frequency,
            request.StartDate,
            request.EndDate,
            request.Time,
            request.TaxId);

        if (recurringInvoiceResult.IsError)
        {
            return Result.UnprocessableEntity(recurringInvoiceResult.ErrorMessage);
        }

        var recurringInvoice = recurringInvoiceResult.Value;
        
        var recurringInvoiceItems = request.Items.Select(item => 
            new RecurringInvoiceItem
            {
                ProductId = item.ProductId,
                Quantity = item.Quantity,
                Price = item.Price,
                Discount = item.Discount
            }).ToList();

        recurringInvoice.Items = recurringInvoiceItems;

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();
        
        await recurringInvoiceJobService.ScheduleRecurringInvoice(recurringInvoice.Id);

        var customer = await dbContext.Set<Customer>()
            .FirstAsync(x => x.Id == request.CustomerId);
        
        return new CreateRecurringInvoiceResponse(
            recurringInvoice.Id,
            customer.Name,
            customer.Email,
            frequency.ToString(),
            recurringInvoice.StartDate,
            recurringInvoice.EndDate,
            recurringInvoice.NextRunDate,
            recurringInvoice.IsActive
        );
    }
}