﻿namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.Create;

public record CreateRecurringInvoiceRequest(
    long CustomerId,
    string Time,
    string Frequency,
    DateOnly StartDate,
    DateOnly? EndDate,
    ICollection<CreateRecurringInvoiceLineRequest> Items,
    long? TaxId = null);

public record CreateRecurringInvoiceLineRequest(
    long ProductId,
    decimal Quantity,
    decimal Price,
    decimal? Discount = null);