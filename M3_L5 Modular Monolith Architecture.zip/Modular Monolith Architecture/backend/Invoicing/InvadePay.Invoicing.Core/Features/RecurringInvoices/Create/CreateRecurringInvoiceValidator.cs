﻿using FluentValidation;
using InvadePay.Invoicing.Core.Models.Invoices;

namespace InvadePay.Invoicing.Core.Features.RecurringInvoices.Create;

public class CreateRecurringInvoiceValidator : AbstractValidator<CreateRecurringInvoiceRequest>
{
    public CreateRecurringInvoiceValidator()
    {
        RuleFor(x => x.CustomerId)
            .NotEmpty()
            .GreaterThan(0)
            .WithMessage("Customer is required.");

        RuleFor(x => x.Time)
            .NotEmpty()
            .Matches(@"^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$")
            .WithMessage("Time must be in HH:mm format");

        RuleFor(x => x.Frequency)
            .NotEmpty()
            .Must(BeValidFrequency)
            .WithMessage("Frequency must be one of: Weekly, Monthly, Quarterly, Yearly");

        RuleFor(x => x.StartDate)
            .NotEmpty()
            .GreaterThanOrEqualTo(DateOnly.FromDateTime(DateTime.Today))
            .WithMessage("Start date cannot be in the past");

        RuleFor(x => x.EndDate)
            .GreaterThan(x => x.StartDate)
            .When(x => x.EndDate.HasValue)
            .WithMessage("End date must be after start date");

        RuleFor(x => x.Items)
            .NotEmpty()
            .WithMessage("At least one invoice item is required.");

        RuleForEach(x => x.Items).SetValidator(new CreateRecurringInvoiceLineValidator());
    }

    private static bool BeValidFrequency(string frequency)
    {
        return Enum.TryParse<RecurringFrequency>(frequency, true, out _);
    }
}

public class CreateRecurringInvoiceLineValidator : AbstractValidator<CreateRecurringInvoiceLineRequest>
{
    public CreateRecurringInvoiceLineValidator()
    {
        RuleFor(x => x.ProductId)
            .NotEmpty()
            .GreaterThan(0);
        
        RuleFor(x => x.Quantity)
            .NotEmpty()
            .GreaterThan(0);
        
        RuleFor(x => x.Price)
            .NotEmpty()
            .GreaterThan(0);
        
        RuleFor(x => x.Discount)
            .GreaterThanOrEqualTo(0)
            .When(x => x.Discount.HasValue);
    }
}
