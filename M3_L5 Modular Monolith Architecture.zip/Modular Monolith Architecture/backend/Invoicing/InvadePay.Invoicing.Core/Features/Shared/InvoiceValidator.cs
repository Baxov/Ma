﻿using InvadePay.Common.Models;
using InvadePay.Inventory.Contracts;
using InvadePay.Invoicing.Core.Models.Customers;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Shared;

public class InvoiceValidator(IDbContext dbContext, IProductDetailsHandler productDetailsHandler)
{
    public async Task<Result> ValidateInvoiceFields(
        List<long> productIds,
        long? taxId,
        long customerId,
        string userId)
    {
        var productDetailsResult = await productDetailsHandler.GetMultipleProducts(productIds, userId);
        if (productDetailsResult.IsError)
        {
            return productDetailsResult;
        }

        var products = productDetailsResult.Value;
        if (products.Count != productIds.Count)
        {
            var missingProductIds = productIds.Except(products.Select(p => p.Id));
            return Result.NotFound($"Products with ids {string.Join(", ", missingProductIds)} were not found.");
        }
        
        if (taxId.HasValue)
        {
            var tax = await dbContext.Set<Tax>()
                .FirstOrDefaultAsync(x => x.Id == taxId.Value && x.AppUserId == userId);

            if (tax == null)
            {
                return Result.NotFound($"Tax with id {taxId.Value} was not found.");
            }
        }
        
        var customer = await dbContext.Set<Customer>()
            .FirstOrDefaultAsync(x => x.Id == customerId && x.AppUserId == userId);

        if (customer == null)
        {
            return Result.NotFound($"Customer with id {customerId} was not found.");
        }
        
        return Result.Success();
    }
}