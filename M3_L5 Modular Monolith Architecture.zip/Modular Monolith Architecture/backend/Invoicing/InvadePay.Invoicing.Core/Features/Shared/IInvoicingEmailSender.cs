﻿using InvadePay.Common.Models;

namespace InvadePay.Invoicing.Core.Features.Shared;

public interface IInvoicingEmailSender
{
    public Task<Result> SendInvoiceEmail(string customerEmail, string customerName, string invoiceNumber, byte[] pdfAttachment);
    public Task<Result> SendInvoiceDueDateReminderEmail(string customerEmail, string customerName, string invoiceNumber, DateTime dueDate);
}