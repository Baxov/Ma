﻿using InvadePay.Common.Models;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Core.Features.Shared;

public interface IDbContext
{
    DbSet<TEntity> Set<TEntity>() where TEntity : class, IEntity;
    Task<int> SaveChangesAsync();
}