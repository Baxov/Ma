﻿using InvadePay.Common.Models;
using InvadePay.Common.Options;
using InvadePay.Invoicing.Core.Features.Shared;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace InvadePay.Invoicing.Infrastructure.Emailing;

public class SendgridInvoicingEmailSender(
    IOptions<EmailOptions> emailOptions,
    ILogger<SendgridInvoicingEmailSender> logger): IInvoicingEmailSender
{
    private readonly EmailOptions _emailOptions = emailOptions.Value;

    private SendGridClient CreateClient()
    {
        if (string.IsNullOrEmpty(_emailOptions.SendGridApiKey))
        {
            throw new InvalidOperationException("SendGrid API key is required but not configured.");
        }

        return new SendGridClient(_emailOptions.SendGridApiKey);
    }

    public async Task<Result> SendInvoiceEmail(string customerEmail, string customerName, string invoiceNumber, byte[] pdfAttachment)
    {
        try
        {
            var client = CreateClient();
            var from = new EmailAddress(_emailOptions.FromEmail, _emailOptions.FromName);
            var to = new EmailAddress(customerEmail, customerName);
            var subject = $"Invoice {invoiceNumber} from {_emailOptions.FromName}";
            var htmlContent = $@"
                <html>
                <body>
                    <h2>Invoice {invoiceNumber}</h2>
                    <p>Dear {customerName},</p>
                    <p>Please find attached your invoice {invoiceNumber}.</p>
                    <p>Thank you for your business!</p>
                    <br>
                    <p>Best regards,<br/><br/>{_emailOptions.FromName}</p>
                </body>
                </html>";

            var msg = MailHelper.CreateSingleEmail(from, to, subject, null, htmlContent);

            // Add PDF attachment
            var base64Content = Convert.ToBase64String(pdfAttachment);
            msg.AddAttachment($"invoice-{invoiceNumber}.pdf", base64Content, "application/pdf");

            var response = await client.SendEmailAsync(msg);

            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Body.ReadAsStringAsync();
                logger.LogError("Failed to send invoice email to {Email} for invoice {InvoiceNumber}. Status: {Status}, Body: {Body}",
                    customerEmail, invoiceNumber, response.StatusCode, body);
                return Result.Error("Failed to send invoice email.");
            }

            logger.LogInformation("Invoice email sent successfully to {Email} for invoice {InvoiceNumber}", customerEmail, invoiceNumber);
            return Result.Success();
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to send invoice email to {Email} for invoice {InvoiceNumber}", customerEmail, invoiceNumber);
            return Result.Error("Failed to send invoice email.");
        }
    }

    public async Task<Result> SendInvoiceDueDateReminderEmail(string customerEmail, string customerName, string invoiceNumber, DateTime dueDate)
    {
        try
        {
            var client = CreateClient();
            var from = new EmailAddress(_emailOptions.FromEmail, _emailOptions.FromName);
            var to = new EmailAddress(customerEmail, customerName);
            var subject = $"Payment Reminder: Invoice {invoiceNumber} Due {dueDate:MMM dd, yyyy}";
            var htmlContent = $@"
                <html>
                <body>
                    <h2>Payment Reminder</h2>
                    <p>Dear {customerName},</p>
                    <p>This is a friendly reminder that your invoice <strong>{invoiceNumber}</strong> is due today ({dueDate:MMM dd, yyyy}).</p>
                    <p>If you have already made the payment, please disregard this message. If not, please process your payment at your earliest convenience.</p>
                    <p>If you have any questions about this invoice or need assistance, please don't hesitate to contact us.</p>
                    <br>
                    <p>Thank you for your business!</p>
                    <br>
                    <p>Best regards,<br/><br/>{_emailOptions.FromName}</p>
                </body>
                </html>";

            var msg = MailHelper.CreateSingleEmail(from, to, subject, null, htmlContent);
            var response = await client.SendEmailAsync(msg);

            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Body.ReadAsStringAsync();
                logger.LogError("Failed to send due date reminder email to {Email} for invoice {InvoiceNumber}. Status: {Status}, Body: {Body}",
                    customerEmail, invoiceNumber, response.StatusCode, body);
                return Result.Error("Failed to send due date reminder email.");
            }

            logger.LogInformation("Due date reminder email sent successfully to {Email} for invoice {InvoiceNumber}", customerEmail, invoiceNumber);
            return Result.Success();
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to send due date reminder email to {Email} for invoice {InvoiceNumber}", customerEmail, invoiceNumber);
            return Result.Error("Failed to send due date reminder email.");
        }
    }
}