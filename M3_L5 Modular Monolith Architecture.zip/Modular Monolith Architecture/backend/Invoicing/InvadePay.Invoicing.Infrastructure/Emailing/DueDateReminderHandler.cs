﻿using System.Globalization;
using InvadePay.Common.BackgroundJobs;
using InvadePay.Common.DomainEvents;
using InvadePay.Invoicing.Core.Features.Invoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace InvadePay.Invoicing.Infrastructure.Emailing;

public class DueDateReminderHandler(
    IDbContext dbContext,
    IInvoicingEmailSender emailSender,
    IBackgroundJobScheduler backgroundJobScheduler,
    ILogger<DueDateReminderHandler> logger) : IDomainEventHandler<InvoiceSentEvent>
{
    public async Task Handle(InvoiceSentEvent domainEvent)
    {
        logger.LogInformation("Processing InvoiceSentEvent for invoice ID {InvoiceId}", domainEvent.ParentId);

        // Get the invoice with customer information
        var invoice = await dbContext.Set<Invoice>()
            .Include(i => i.Customer)
            .FirstOrDefaultAsync(i => i.Id == domainEvent.ParentId);

        if (invoice == null)
        {
            logger.LogWarning("Invoice with ID {InvoiceId} not found", domainEvent.ParentId);
            return;
        }

        // Check if due date is after invoice date (meaning it's not due immediately)
        if (invoice.DueDate <= invoice.Date)
        {
            logger.LogInformation("Invoice {InvoiceId} due date ({DueDate}) is not after invoice date ({InvoiceDate}), skipping reminder scheduling",
                invoice.Id, invoice.DueDate, invoice.Date);
            return;
        }

        // Schedule the reminder email to be sent on the due date
        var reminderDateTime = invoice.DueDate.ToDateTime(TimeOnly.Parse(invoice.Time, CultureInfo.InvariantCulture));

        // Only schedule if the due date is in the future
        if (reminderDateTime <= DateTime.Now)
        {
            logger.LogInformation("Invoice {InvoiceId} due date ({DueDate}) is in the past, skipping reminder scheduling",
                invoice.Id, reminderDateTime);
            return;
        }

        var jobId = backgroundJobScheduler.Schedule(
            () => SendDueDateReminderEmailAsync(invoice.Id),
            reminderDateTime);

        logger.LogInformation("Scheduled due date reminder for invoice {InvoiceId} (number: {InvoiceNumber}) to be sent on {ReminderDateTime}. Job ID: {JobId}",
            invoice.Id, InvoiceNumberFormatter.Format(invoice.InvoiceNumber), reminderDateTime, jobId);
    }

    public async Task SendDueDateReminderEmailAsync(long invoiceId)
    {
        logger.LogInformation("Sending due date reminder email for invoice ID {InvoiceId}", invoiceId);

        try
        {
            var invoice = await dbContext.Set<Invoice>()
                .Include(i => i.Customer)
                .FirstOrDefaultAsync(i => i.Id == invoiceId);

            if (invoice == null)
            {
                logger.LogWarning("Invoice with ID {InvoiceId} not found when sending reminder", invoiceId);
                return;
            }

            if (invoice.Status == InvoiceStatus.Paid || invoice.Status == InvoiceStatus.Reversed)
            {
                return;
            }

            var formattedInvoiceNumber = $"{invoice.InvoiceNumber}-1-1";

            var result = await emailSender.SendInvoiceDueDateReminderEmail(
                invoice.Customer.Email,
                invoice.Customer.Name,
                formattedInvoiceNumber,
                invoice.DueDate.ToDateTime(TimeOnly.MinValue));

            if (result.IsSuccess)
            {
                logger.LogInformation("Due date reminder email sent successfully for invoice {InvoiceId} to {CustomerEmail}",
                    invoiceId, invoice.Customer.Email);
            }
            else
            {
                logger.LogError("Failed to send due date reminder email for invoice {InvoiceId}: {Error}",
                    invoiceId, result.ErrorMessage);
            }
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Exception occurred while sending due date reminder email for invoice {InvoiceId}", invoiceId);
        }
    }
}
