﻿using InvadePay.Common.Models;
using InvadePay.Common.Options;
using InvadePay.Invoicing.Core.Features.Shared;
using MailKit.Net.Smtp;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MimeKit;

namespace InvadePay.Invoicing.Infrastructure.Emailing;

public class LocalInvoicingEmailSender(
    IOptions<EmailOptions> emailOptions,
    ILogger<LocalInvoicingEmailSender> logger) : IInvoicingEmailSender
{
    private readonly EmailOptions _emailOptions = emailOptions.Value;

    public async Task<Result> SendInvoiceEmail(string customerEmail, string customerName, string invoiceNumber, byte[] pdfAttachment)
    {
        try
        {
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(_emailOptions.FromName, _emailOptions.FromEmail));
            message.To.Add(new MailboxAddress(customerName, customerEmail));
            message.Subject = $"Invoice {invoiceNumber} from {_emailOptions.FromName}";

            var bodyBuilder = new BodyBuilder
            {
                HtmlBody = $@"
                    <html>
                    <body>
                        <h2>Invoice {invoiceNumber}</h2>
                        <p>Dear {customerName},</p>
                        <p>Please find attached your invoice {invoiceNumber}.</p>
                        <p>Thank you for your business!</p>
                        <br>
                        <p>Best regards,<br/><br/>{_emailOptions.FromName}</p>
                    </body>
                    </html>"
            };

            bodyBuilder.Attachments.Add($"invoice-{invoiceNumber}.pdf", pdfAttachment, new ContentType("application", "pdf"));
            message.Body = bodyBuilder.ToMessageBody();

            using var client = new SmtpClient();
            await client.ConnectAsync(_emailOptions.SmtpHost, _emailOptions.SmtpPort, false);
            await client.SendAsync(message);
            await client.DisconnectAsync(true);

            logger.LogInformation("Invoice email sent successfully to {Email} for invoice {InvoiceNumber}", customerEmail, invoiceNumber);
            return Result.Success();
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to send invoice email to {Email} for invoice {InvoiceNumber}", customerEmail, invoiceNumber);
            return Result.Error("Failed to send invoice email.");
        }
    }

    public async Task<Result> SendInvoiceDueDateReminderEmail(string customerEmail, string customerName, string invoiceNumber, DateTime dueDate)
    {
        try
        {
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(_emailOptions.FromName, _emailOptions.FromEmail));
            message.To.Add(new MailboxAddress(customerName, customerEmail));
            message.Subject = $"Payment Reminder: Invoice {invoiceNumber} Due {dueDate:MMM dd, yyyy}";

            var bodyBuilder = new BodyBuilder
            {
                HtmlBody = $@"
                    <html>
                    <body>
                        <h2>Payment Reminder</h2>
                        <p>Dear {customerName},</p>
                        <p>This is a friendly reminder that your invoice <strong>{invoiceNumber}</strong> is due today ({dueDate:MMM dd, yyyy}).</p>
                        <p>If you have already made the payment, please disregard this message. If not, please process your payment at your earliest convenience.</p>
                        <p>If you have any questions about this invoice or need assistance, please don't hesitate to contact us.</p>
                        <br>
                        <p>Thank you for your business!</p>
                        <br>
                        <p>Best regards,<br/><br/>{_emailOptions.FromName}</p>
                    </body>
                    </html>"
            };

            message.Body = bodyBuilder.ToMessageBody();

            using var client = new SmtpClient();
            await client.ConnectAsync(_emailOptions.SmtpHost, _emailOptions.SmtpPort, false);
            await client.SendAsync(message);
            await client.DisconnectAsync(true);

            logger.LogInformation("Due date reminder email sent successfully to {Email} for invoice {InvoiceNumber}", customerEmail, invoiceNumber);
            return Result.Success();
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to send due date reminder email to {Email} for invoice {InvoiceNumber}", customerEmail, invoiceNumber);
            return Result.Error("Failed to send due date reminder email.");
        }
    }
}

