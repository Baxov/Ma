﻿using InvadePay.Invoicing.Core.Features.Invoices.GeneratePdf;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace InvadePay.Invoicing.Infrastructure.PdfGeneration;

public static class BrandColors
{
    public static readonly Color Primary = Color.FromHex("#476c9b");
}

public class QuestPdfGenerator : IInvoicePdfGenerator
{
    static QuestPdfGenerator()
    {
        QuestPDF.Settings.License = LicenseType.Community;
    }

    public Task<byte[]> GeneratePdf(InvoicePdfData invoice)
    {
        var document = Document.Create(container => container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(2, Unit.Centimetre);
                page.PageColor(Colors.White);
                page.DefaultTextStyle(x => x.FontSize(11));

                page.Header()
                    .Row(row =>
                    {
                        row.RelativeItem().Column(column => column.Item().Text("INVOICE")
                                .SemiBold().FontSize(28).FontColor(BrandColors.Primary));

                        if (!string.IsNullOrEmpty(invoice.CompanyName))
                        {
                            row.RelativeItem().AlignRight().Column(column =>
                            {
                                column.Item().Text(invoice.CompanyName)
                                    .SemiBold().FontSize(14);

                                if (!string.IsNullOrEmpty(invoice.CompanyAddress))
                                {
                                    column.Item().Text(invoice.CompanyAddress)
                                        .FontSize(10);
                                }

                                if (!string.IsNullOrEmpty(invoice.CompanyEmail))
                                {
                                    column.Item().Text(invoice.CompanyEmail)
                                        .FontSize(10);
                                }
                            });
                        }
                    });

                page.Content()
                    .PaddingVertical(1, Unit.Centimetre)
                    .Column(x =>
                    {
                        x.Spacing(20);

                        // Invoice header info
                        x.Item().Row(row => row.RelativeItem().Column(column =>
                            {
                                column.Item().Text($"Invoice Number: {invoice.InvoiceNumber}").SemiBold();
                                column.Item().Text($"Date: {invoice.Date:dd.MM.yyyy}").SemiBold();
                                column.Item().Text($"Status: {invoice.Status}").SemiBold();
                            }));

                        // Customer information
                        x.Item().BorderBottom(1).PaddingBottom(5).Column(column =>
                        {
                            column.Item().Text("Bill To:").SemiBold().FontSize(14);
                            column.Item().Text(invoice.CustomerName);
                            column.Item().Text(invoice.CustomerEmail);
                        });

                        // Invoice items table
                        x.Item().Table(table =>
                        {
                            table.ColumnsDefinition(columns =>
                            {
                                columns.RelativeColumn(3); // Product Name
                                columns.RelativeColumn(1); // Quantity
                                columns.RelativeColumn(1); // Price
                                columns.RelativeColumn(1); // Discount
                                columns.RelativeColumn(1); // Total
                            });

                            // Table header
                            table.Header(header =>
                            {
                                header.Cell().Element(CellStyle).Text("Product").SemiBold();
                                header.Cell().Element(CellStyle).Text("Qty").SemiBold();
                                header.Cell().Element(CellStyle).Text("Price").SemiBold();
                                header.Cell().Element(CellStyle).Text("Discount").SemiBold();
                                header.Cell().Element(CellStyle).Text("Total").SemiBold();

                                static IContainer CellStyle(IContainer container)
                                {
                                    return container
                                        .BorderBottom(1)
                                        .BorderColor(Colors.Black)
                                        .DefaultTextStyle(x => x.SemiBold())
                                        .PaddingTop(5)
                                        .PaddingBottom(5);
                                }
                            });

                            // Table rows
                            foreach (var item in invoice.Items)
                            {
                                table.Cell().Element(CellStyle).Text(item.ProductName);
                                table.Cell().Element(CellStyle).Text(item.Quantity.ToString("F2"));
                                table.Cell().Element(CellStyle).Text($"€{item.Price:F2}");
                                table.Cell().Element(CellStyle).Text(item.Discount.HasValue ? $"{item.Discount:F1}%" : "-");
                                table.Cell().Element(CellStyle).Text($"€{item.LineTotal:F2}");

                                static IContainer CellStyle(IContainer container)
                                {
                                    return container
                                        .BorderBottom(1)
                                        .BorderColor(Colors.Grey.Lighten2)
                                        .PaddingVertical(5);
                                }
                            }
                        });

                        // Total section
                        x.Item().AlignRight().Column(column =>
                        {
                            // Subtotal
                            column.Item()
                                .AlignRight()
                                .PaddingBottom(5)
                                .Text($"Subtotal: €{invoice.SubtotalAmount:F2}")
                                .FontSize(12);

                            // Tax (if exists)
                            if (invoice.TaxAmount > 0 && !string.IsNullOrEmpty(invoice.TaxName))
                            {
                                column.Item()
                                    .AlignRight()
                                    .PaddingBottom(5)
                                    .Text($"{invoice.TaxName} ({invoice.TaxRate:F1}%): €{invoice.TaxAmount:F2}")
                                    .FontSize(12);

                            }

                            // Total
                            column.Item().BorderTop(2).BorderColor(Colors.Black).PaddingTop(5)
                                .AlignRight().Text($"Total Amount: €{invoice.TotalAmount:F2}")
                                .SemiBold().FontSize(16);
                        });
                    });

                page.Footer()
                    .AlignCenter()
                    .Text(x =>
                    {
                        x.Span("Generated on ");
                        x.Span($"{DateTime.Now:dd.MM.yyyy HH:mm}").SemiBold();
                    });
            }));

        return Task.FromResult(document.GeneratePdf());
    }
}
