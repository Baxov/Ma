﻿using InvadePay.Common.DomainEvents;
using InvadePay.Invoicing.Core.Models.Customers;

namespace InvadePay.Invoicing.Infrastructure.Crm;

public class CustomerCrmSyncJob: IDomainEventHandler<CustomerCreatedEvent>
{
    public Task Handle(CustomerCreatedEvent domainEvent)
    {
        return Task.CompletedTask;
    }
}
