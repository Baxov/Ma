﻿using System.Globalization;
using Hangfire;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace InvadePay.Invoicing.Infrastructure.BackgroundJobs;

public class RecurringInvoiceJobService : IRecurringInvoiceJobService
{
    private readonly IDbContext _dbContext;
    private readonly ILogger<RecurringInvoiceJobService> _logger;

    public RecurringInvoiceJobService(IDbContext dbContext, ILogger<RecurringInvoiceJobService> logger)
    {
        _dbContext = dbContext;
        _logger = logger;
    }

    public async Task ScheduleRecurringInvoice(long recurringInvoiceId)
    {
        var recurringInvoice = await _dbContext.Set<RecurringInvoice>()
            .FirstOrDefaultAsync(ri => ri.Id == recurringInvoiceId);

        if (recurringInvoice == null)
        {
            _logger.LogWarning("Recurring invoice {RecurringInvoiceId} not found for scheduling", recurringInvoiceId);
            return;
        }

        if (!recurringInvoice.IsActive || !recurringInvoice.NextRunDate.HasValue)
        {
            _logger.LogInformation("Recurring invoice {RecurringInvoiceId} is not active or has no next run date", recurringInvoiceId);
            return;
        }

        // Schedule the job to run at the specified time on the next run date
        var scheduledTime = recurringInvoice.NextRunDate.Value.ToDateTime(TimeOnly.Parse(recurringInvoice.Time, CultureInfo.InvariantCulture));

        var jobId = BackgroundJob.Schedule(
            () => ProcessSingleRecurringInvoiceAsync(recurringInvoiceId),
            scheduledTime);

        // Update the recurring invoice with the Hangfire job ID
        recurringInvoice.HangfireJobId = jobId;
        await _dbContext.SaveChangesAsync();

        _logger.LogInformation("Scheduled recurring invoice {RecurringInvoiceId} with job ID {JobId} for {ScheduledTime}",
            recurringInvoiceId, jobId, scheduledTime);
    }

    public void UnscheduleRecurringInvoice(string hangfireJobId)
    {
        if (string.IsNullOrEmpty(hangfireJobId))
        {
            return;
        }

        BackgroundJob.Delete(hangfireJobId);
        _logger.LogInformation("Unscheduled Hangfire job {JobId}", hangfireJobId);
    }

    public async Task ProcessSingleRecurringInvoiceAsync(long recurringInvoiceId)
    {
        _logger.LogInformation("Processing recurring invoice {RecurringInvoiceId}", recurringInvoiceId);

        // Load the recurring invoice with all necessary data
        var recurringInvoice = await _dbContext.Set<RecurringInvoice>()
            .Include(ri => ri.Customer)
            .Include(ri => ri.Tax)
            .Include(ri => ri.Items)
            .FirstOrDefaultAsync(ri => ri.Id == recurringInvoiceId);

        if (recurringInvoice == null)
        {
            _logger.LogWarning("Recurring invoice {RecurringInvoiceId} not found", recurringInvoiceId);
            return;
        }

        if (!recurringInvoice.IsActive)
        {
            _logger.LogInformation("Recurring invoice {RecurringInvoiceId} is not active, skipping", recurringInvoiceId);
            return;
        }

        var userHasInvoices = await _dbContext.Set<Invoice>()
            .AnyAsync(x => x.AppUserId == recurringInvoice.AppUserId);

        var nextInvoiceNumber = 1L;
        if (userHasInvoices)
        {
            nextInvoiceNumber = await _dbContext.Set<Invoice>()
                .Where(x => x.AppUserId == recurringInvoice.AppUserId)
                .MaxAsync(x => x.InvoiceNumber) + 1;
        }

        // Create invoice items from recurring invoice items
        var invoiceItems = recurringInvoice.Items.Select(item => new InvoiceItem
        {
            ProductId = item.ProductId,
            Quantity = item.Quantity,
            Price = item.Price,
            Discount = item.Discount
        }).ToList();

        var invoiceResult = Invoice.Create(
            nextInvoiceNumber,
            recurringInvoice.CustomerId,
            DateOnly.FromDateTime(DateTime.Today),
            DateOnly.FromDateTime(DateTime.Today),
            recurringInvoice.Time,
            recurringInvoice.AppUserId,
            invoiceItems,
            recurringInvoice.TaxId);

        if (invoiceResult.IsError)
        {
            _logger.LogError("Failed to create invoice from recurring invoice {RecurringInvoiceId}: {Error}",
                recurringInvoiceId, invoiceResult.ErrorMessage);
            return;
        }

        var invoice = invoiceResult.Value;
        _dbContext.Set<Invoice>().Add(invoice);

        // Update the recurring invoice's next run date
        recurringInvoice.MarkAsProcessed();

        // If the recurring invoice is still active, schedule the next run
        if (recurringInvoice is { IsActive: true, NextRunDate: not null })
        {
            var nextScheduledTime = recurringInvoice.NextRunDate.Value.ToDateTime(TimeOnly.Parse(recurringInvoice.Time, CultureInfo.InvariantCulture));
            var nextJobId = BackgroundJob.Schedule(
                () => ProcessSingleRecurringInvoiceAsync(recurringInvoiceId),
                nextScheduledTime);

            recurringInvoice.HangfireJobId = nextJobId;
        }
        else
        {
            recurringInvoice.HangfireJobId = null;
        }

        await _dbContext.SaveChangesAsync();

        _logger.LogInformation("Successfully created invoice {InvoiceId} from recurring invoice {RecurringInvoiceId}",
            invoice.Id, recurringInvoice.Id);
    }
}
