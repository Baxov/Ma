using System.ComponentModel.DataAnnotations;

namespace InvadePay.Invoicing.Infrastructure.Database;

public class InvoicingDatabaseOptions
{
    [Required]
    public string ConnectionString { get; set; } = string.Empty;
    
    [Range(30, 300)]
    public int CommandTimeout { get; set; }
    
    [Range(0, 10)]
    public int MaxRetryCount { get; set; }
}