﻿using InvadePay.Invoicing.Core.Models.CompanySettings;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InvadePay.Invoicing.Infrastructure.Database.EntityConfigurations;

public class CompanyConfiguration : IEntityTypeConfiguration<Company>
{
    public void Configure(EntityTypeBuilder<Company> builder)
    {
        builder.ToTable("Companies");
        builder.HasKey(x => x.Id);
        
        builder.Property(x => x.CompanyName)
            .IsRequired()
            .HasMaxLength(Company.MaxLengths.CompanyName);
            
        builder.Property(x => x.Address)
            .HasMaxLength(Company.MaxLengths.Address);
            
        builder.Property(x => x.Email)
            .HasMaxLength(Company.MaxLengths.Email);
            
        builder.Property(x => x.AppUserId)
            .IsRequired();
        
        // Ensure only one company settings record per user
        builder.HasIndex(x => x.AppUserId)
            .IsUnique();
    }
}
