﻿using InvadePay.Invoicing.Core.Models.Customers;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InvadePay.Invoicing.Infrastructure.Database.EntityConfigurations;

public class CustomerConfiguration : IEntityTypeConfiguration<Customer>
{
    public void Configure(EntityTypeBuilder<Customer> builder)
    {
        builder.ToTable("Customers");
        builder.HasKey(x => x.Id);
        
        builder.Property(x => x.Name)
            .IsRequired()
            .HasMaxLength(Customer.MaxLengths.Name);
            
        builder.Property(x => x.Email)
            .IsRequired()
            .HasMaxLength(Customer.MaxLengths.Email);
            
        builder.Property(x => x.Address)
            .HasMaxLength(Customer.MaxLengths.Address);
            
        builder.Property(x => x.VatNumber)
            .HasMaxLength(Customer.MaxLengths.VatNumber);
            
        builder.Property(x => x.AppUserId)
            .IsRequired();
    }
}
