﻿using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InvadePay.Invoicing.Infrastructure.Database.EntityConfigurations;

public class RecurringInvoiceItemConfiguration : IEntityTypeConfiguration<RecurringInvoiceItem>
{
    public void Configure(EntityTypeBuilder<RecurringInvoiceItem> builder)
    {
        builder.ToTable("RecurringInvoiceItems");
        builder.HasKey(x => x.Id);
        
        builder.Property(x => x.RecurringInvoiceId).IsRequired();
        builder.Property(x => x.ProductId).IsRequired();
        builder.Property(x => x.Quantity)
            .HasPrecision(18, 2)
            .IsRequired();
        builder.Property(x => x.Price)
            .HasPrecision(18, 2)
            .IsRequired();
        builder.Property(x => x.Discount)
            .HasPrecision(18, 2);

        builder.HasOne(x => x.RecurringInvoice)
            .WithMany(x => x.Items)
            .HasForeignKey(x => x.RecurringInvoiceId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Property(x => x.ProductId)
            .IsRequired();

        // Index for efficient querying
        builder.HasIndex(x => x.RecurringInvoiceId)
            .HasDatabaseName("IX_RecurringInvoiceItems_RecurringInvoiceId");
    }
}
