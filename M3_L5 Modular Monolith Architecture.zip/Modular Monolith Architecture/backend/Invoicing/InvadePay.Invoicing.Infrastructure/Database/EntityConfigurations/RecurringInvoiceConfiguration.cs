﻿using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InvadePay.Invoicing.Infrastructure.Database.EntityConfigurations;

public class RecurringInvoiceConfiguration : IEntityTypeConfiguration<RecurringInvoice>
{
    public void Configure(EntityTypeBuilder<RecurringInvoice> builder)
    {
        builder.ToTable("RecurringInvoices");
        builder.HasKey(x => x.Id);
        
        builder.Property(x => x.AppUserId).IsRequired();
        builder.Property(x => x.CustomerId).IsRequired();
        builder.Property(x => x.Time).IsRequired()
            .HasMaxLength(RecurringInvoice.MaxLengths.Time);
        builder.Property(x => x.Frequency)
            .HasConversion<string>()
            .IsRequired();
        builder.Property(x => x.StartDate).IsRequired();
        builder.Property(x => x.EndDate);
        builder.Property(x => x.NextRunDate);
        builder.Property(x => x.IsActive)
            .HasDefaultValue(true);
        builder.Property(x => x.HangfireJobId)
            .HasMaxLength(RecurringInvoice.MaxLengths.HangfireJobId);

        builder.Property(x => x.AppUserId)
            .IsRequired();

        builder.HasOne(x => x.Customer)
            .WithMany()
            .HasForeignKey(x => x.CustomerId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(x => x.Tax)
            .WithMany()
            .HasForeignKey(x => x.TaxId)
            .OnDelete(DeleteBehavior.NoAction);

        builder.HasMany(x => x.Items)
            .WithOne(x => x.RecurringInvoice)
            .HasForeignKey(x => x.RecurringInvoiceId)
            .OnDelete(DeleteBehavior.Cascade);

        // Index for efficient querying of active recurring invoices
        builder.HasIndex(x => new { x.IsActive, x.NextRunDate })
            .HasDatabaseName("IX_RecurringInvoices_Active_NextRun");

        // Index for user-specific queries
        builder.HasIndex(x => x.AppUserId)
            .HasDatabaseName("IX_RecurringInvoices_AppUserId");
    }
}
