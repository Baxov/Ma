﻿using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InvadePay.Invoicing.Infrastructure.Database.EntityConfigurations;

public class InvoiceItemConfiguration : IEntityTypeConfiguration<InvoiceItem>
{
    public void Configure(EntityTypeBuilder<InvoiceItem> builder)
    {
        builder.ToTable("InvoiceItems");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Quantity)
            .HasPrecision(18, 2);
        builder.Property(x => x.Price)
            .HasPrecision(18, 2);
        builder.Property(x => x.Discount)
            .HasPrecision(18, 2);
        
        builder.Property(x => x.ProductId)
            .IsRequired();
    }
}