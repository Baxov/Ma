﻿using InvadePay.Invoicing.Core.Models.Invoices;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InvadePay.Invoicing.Infrastructure.Database.EntityConfigurations;

public class TaxConfiguration : IEntityTypeConfiguration<Tax>
{
    public void Configure(EntityTypeBuilder<Tax> builder)
    {
        builder.ToTable("Taxes");
        builder.HasKey(x => x.Id);
        
        builder.Property(x => x.Name)
            .IsRequired()
            .HasMaxLength(Tax.MaxLengths.Name);
            
        builder.Property(x => x.Description)
            .HasMaxLength(Tax.MaxLengths.Description);
            
        builder.Property(x => x.Rate)
            .IsRequired()
            .HasPrecision(5, 2);
        
        builder.Property(x => x.AppUserId)
            .IsRequired();
    }
}
