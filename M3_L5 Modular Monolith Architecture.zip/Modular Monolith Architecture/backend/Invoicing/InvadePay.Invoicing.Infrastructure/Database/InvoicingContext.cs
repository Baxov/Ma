using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Invoicing.Infrastructure.Database;

public class InvoicingContext : DbContext, IDbContext
{
    public InvoicingContext(DbContextOptions<InvoicingContext> options) : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("Invoicing");
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(InvoicingContext).Assembly);
        base.OnModelCreating(modelBuilder);
    }

    public async Task<int> SaveChangesAsync()
    {
        return await base.SaveChangesAsync();
    }

    public new DbSet<TEntity> Set<TEntity>() where TEntity : class, IEntity
    {
        return base.Set<TEntity>();
    }
}