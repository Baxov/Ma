﻿namespace InvadePay.Common;

public interface IUserContext
{
    string? GetUserId();
}