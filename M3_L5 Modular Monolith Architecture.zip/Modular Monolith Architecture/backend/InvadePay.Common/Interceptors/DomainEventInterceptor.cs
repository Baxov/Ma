﻿using InvadePay.Common.DomainEvents;
using InvadePay.Common.Models;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace InvadePay.Common.Interceptors;

public class DomainEventInterceptor : SaveChangesInterceptor
{
    private readonly DomainEventDispatcher _domainEventDispatcher;

    public DomainEventInterceptor(DomainEventDispatcher domainEventDispatcher)
    {
        _domainEventDispatcher = domainEventDispatcher;
    }

    public override async ValueTask<int> SavedChangesAsync(
        SaveChangesCompletedEventData eventData, 
        int result, 
        CancellationToken cancellationToken = default)
    {
        if (eventData.Context is null)
        {
            return result;
        }

        var entitiesWithEvents = eventData.Context.ChangeTracker.Entries<BaseEntity>()
            .Select(e => e.Entity)
            .Where(e => e.DomainEvents.Count > 0)
            .ToList();

        foreach (var entity in entitiesWithEvents)
        {
            foreach (var domainEvent in entity.DomainEvents)
            {
                // Set generic ParentId from entity
                domainEvent.ParentId = entity.Id;
            }

            await _domainEventDispatcher.DispatchEvents(entity);
        }

        return result;
    }
}