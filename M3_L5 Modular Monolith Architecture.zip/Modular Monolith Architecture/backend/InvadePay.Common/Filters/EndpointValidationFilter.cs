﻿using FluentValidation;
using Microsoft.AspNetCore.Http;

namespace InvadePay.Common.Filters;

internal class EndpointValidatorFilter<T>(IValidator<T> validator) : IEndpointFilter
{
    private IValidator<T> Validator => validator;

    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var inputData = context.Arguments.OfType<T>()
            .FirstOrDefault(a => a?.GetType() == typeof(T));

        if (inputData is not null)
        {
            var validationResult = await Validator.ValidateAsync(inputData);
            if (!validationResult.IsValid)
            {
                return Results.BadRequest(validationResult.Errors.Select(e => e.ErrorMessage).ToList());
            }
        }

        return await next.Invoke(context);
    }
}
