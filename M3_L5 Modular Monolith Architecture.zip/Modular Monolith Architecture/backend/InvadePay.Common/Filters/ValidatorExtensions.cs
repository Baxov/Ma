﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace InvadePay.Common.Filters;

public static class ValidatorExtensions
{
    public static RouteHandlerBuilder Validator<T>(this RouteHandlerBuilder handlerBuilder)
        where T : class
    {
        handlerBuilder.AddEndpointFilter<EndpointValidatorFilter<T>>();
        return handlerBuilder;
    }
}