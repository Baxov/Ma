﻿using System.Linq.Expressions;
using InvadePay.Common.Models;

namespace InvadePay.Common.Database;

public abstract class SpecificationPattern<TEntity> where TEntity: IEntity
{
    public Expression<Func<TEntity, bool>> Criteria { get; protected init; } = null!;

    public bool IsSatisfiedBy(TEntity entity)
    {
        return Criteria.Compile().Invoke(entity);
    }
}