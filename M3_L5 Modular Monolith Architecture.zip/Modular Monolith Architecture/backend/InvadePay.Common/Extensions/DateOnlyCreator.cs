﻿namespace InvadePay.Common.Extensions;

public static class DateOnlyCreator
{
    /// <summary>
    /// Gets the current date as a DateOnly instance.
    /// </summary>
    /// <returns>A DateOnly representing today's date.</returns>
    public static DateOnly Today() => DateOnly.FromDateTime(DateTime.Today);
}
