﻿using System.ComponentModel.DataAnnotations;

namespace InvadePay.Common.Extensions;

public static class StringExtensions
{
    public static bool IsValidEmail(this string email)
    {
        try
        {
            var attribute = new EmailAddressAttribute();
            return attribute.IsValid(email);
        }
        catch
        {
            return false;
        }
    }
}