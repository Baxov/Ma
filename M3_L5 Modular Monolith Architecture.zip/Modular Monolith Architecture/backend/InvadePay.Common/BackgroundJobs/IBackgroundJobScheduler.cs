﻿using System.Linq.Expressions;

namespace InvadePay.Common.BackgroundJobs;

public interface IBackgroundJobScheduler
{
    string Schedule(Expression<Func<Task>> methodCall, TimeSpan delay);
    string Schedule(Expression<Func<Task>> methodCall, DateTimeOffset enqueueAt);
    string Enqueue(Expression<Func<Task>> methodCall);
}