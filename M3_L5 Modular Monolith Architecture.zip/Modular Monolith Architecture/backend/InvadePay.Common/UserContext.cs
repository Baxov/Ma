﻿using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace InvadePay.Common;

public class UserContext(IHttpContextAccessor httpContextAccessor) : IUserContext
{
    public string? GetUserId()
    {
        var claimsPrincipal = httpContextAccessor
                .HttpContext?
                .User ??
            throw new InvalidOperationException("User context is unavailable");

        return claimsPrincipal.FindFirst(ClaimTypes.NameIdentifier)?.Value;
    }
}
