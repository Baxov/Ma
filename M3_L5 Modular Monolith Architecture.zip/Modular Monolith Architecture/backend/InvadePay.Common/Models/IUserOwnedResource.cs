﻿namespace InvadePay.Common.Models;

public interface IUserOwnedResource: IEntity
{
    public string AppUserId { get; set; }
}