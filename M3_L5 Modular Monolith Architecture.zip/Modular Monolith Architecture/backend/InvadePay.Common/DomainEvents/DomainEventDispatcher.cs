using InvadePay.Common.Models;
using Microsoft.Extensions.DependencyInjection;

namespace InvadePay.Common.DomainEvents;

public class DomainEventDispatcher(IServiceProvider serviceProvider)
{
    public async Task DispatchEvents(BaseEntity entity)
    {
        foreach (var domainEvent in entity.DomainEvents.Where(x => !x.Handled).ToList())
        {
            domainEvent.Handled = true;
            var handlerType = typeof(IDomainEventHandler<>).MakeGenericType(domainEvent.GetType());
            var handlers = serviceProvider.GetServices(handlerType).ToList();

            if(handlers.Count == 0)
            {
                continue;
            }
            
            foreach (var handler in handlers)
            {
                if (handler is null)
                {
                    continue;
                }
                await InvokeHandleAsync(handler, domainEvent);
            }
        }

        entity.ClearDomainEvents();
    }

    private async Task InvokeHandleAsync(object handler, IDomainEvent domainEvent)
    {
        try
        {
            var handlerType = handler.GetType();
            var handleMethod = handlerType.GetMethod("Handle");

            var handlerTask = handleMethod?.Invoke(handler, new[] { domainEvent });
            if (handlerTask is Task task)
            {
                await task;
            }
        }
        catch//(Exception ex)
        {
            using var scope = serviceProvider.CreateScope();
            // Log error
        }
    }
}