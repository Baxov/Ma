﻿namespace InvadePay.Common.DomainEvents;

public interface IDomainEvent
{
    public long ParentId { get; set; }
    public bool Handled { get; set; }
}

public class BaseDomainEvent : IDomainEvent
{
    public long ParentId { get; set; }
    public bool Handled { get; set; }
}