﻿namespace InvadePay.Common.Responses;

public class PagedResponse<T>(IEnumerable<T> items, int totalCount)
{
    public IEnumerable<T> Items { get; set; } = items;
    public int TotalCount { get; set; } = totalCount;
}