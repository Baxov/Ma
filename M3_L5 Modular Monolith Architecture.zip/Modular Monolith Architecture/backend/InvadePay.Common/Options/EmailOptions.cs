﻿using System.ComponentModel.DataAnnotations;

namespace InvadePay.Common.Options;

public class EmailOptions
{
    [Required]
    public string SmtpHost { get; set; } = string.Empty;

    [Range(1, 65535)]
    public int SmtpPort { get; set; }

    [Required]
    [EmailAddress]
    public string FromEmail { get; set; } = string.Empty;

    [Required]
    public string FromName { get; set; } = string.Empty;

    [Required]
    [Url]
    public string FrontendUrl { get; set; } = string.Empty;

    // SendGrid specific options
    public string? SendGridApiKey { get; set; }
}