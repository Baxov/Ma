﻿using Microsoft.AspNetCore.Routing;

namespace InvadePay.Common.Api;

public interface IEndpoint
{
    void MapEndpoint(IEndpointRouteBuilder app);
}