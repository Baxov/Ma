﻿using ArchUnitNET.xUnit;
using static ArchUnitNET.Fluent.ArchRuleDefinition;

namespace InvadePay.ArchitectureTests.Invoicing;

public class InvoicingModuleIsolationTests : BaseArchitectureTest
{
    [Fact]
    public void InvoicingCoreModule_should_not_depend_on_UsersModule()
    {
        var rule = Types().That().Are(InvoicingCoreModule)
            .Should().NotDependOnAny(UsersModule)
            .Because("Invoicing.Core module should not depend on Users module")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }

    [Fact]
    public void InvoicingCoreModule_should_not_depend_on_InventoryModule_internals()
    {
        var rule = Types().That().Are(InvoicingCoreModule)
            .Should().NotDependOnAny(InventoryModuleInternals)
            .Because("Invoicing.Core module should not depend on Inventory module internals, only on Contracts")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }

    [Fact]
    public void InvoicingApiModule_should_not_depend_on_UsersModule()
    {
        var rule = Types().That().Are(InvoicingApiModule)
            .Should().NotDependOnAny(UsersModule)
            .Because("Invoicing.Api module should not depend on Users module")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }

    [Fact]
    public void InvoicingApiModule_should_not_depend_on_InventoryModule_internals()
    {
        var rule = Types().That().Are(InvoicingApiModule)
            .Should().NotDependOnAny(InventoryModuleInternals)
            .Because("Invoicing.Api module should not depend on Inventory module internals, only on Contracts")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }

    [Fact]
    public void InvoicingInfrastructureModule_should_not_depend_on_UsersModule()
    {
        var rule = Types().That().Are(InvoicingInfrastructureModule)
            .Should().NotDependOnAny(UsersModule)
            .Because("Invoicing.Infrastructure module should not depend on Users module")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }

    [Fact]
    public void InvoicingInfrastructureModule_should_not_depend_on_InventoryModule_internals()
    {
        var rule = Types().That().Are(InvoicingInfrastructureModule)
            .Should().NotDependOnAny(InventoryModuleInternals)
            .Because("Invoicing.Infrastructure module should not depend on Inventory module internals, only on Contracts")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }
}

