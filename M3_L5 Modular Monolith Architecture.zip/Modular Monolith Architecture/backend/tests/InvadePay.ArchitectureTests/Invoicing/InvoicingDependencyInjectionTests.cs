﻿using System.Reflection;
using InvadePay.Common.DomainEvents;
using InvadePay.Common.Interceptors;
using InvadePay.Common.Models;
using InvadePay.Inventory.Contracts;
using InvadePay.Invoicing.Api;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Shouldly;

namespace InvadePay.ArchitectureTests.Invoicing;

public class InvoicingDependencyInjectionTests : BaseArchitectureTest
{
    private static readonly Assembly InvoicingCoreAssembly = typeof(InvadePay.Invoicing.Core.Features.Shared.IDbContext).Assembly;

    [Fact]
    public void All_UseCases_should_be_registered_in_DI_container()
    {
        var services = new ServiceCollection();
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["InvoicingDatabase:ConnectionString"] = "Server=test;Database=test;",
                ["InvoicingDatabase:CommandTimeout"] = "30",
                ["InvoicingDatabase:MaxRetryCount"] = "3"
            })
            .Build();
        
        services.AddLogging();
        services.AddScoped<AuditInterceptor>();
        services.AddScoped<DomainEventDispatcher>();
        services.AddScoped<DomainEventInterceptor>();
        
        services.AddScoped<IProductDetailsHandler, StubProductDetailsHandler>();
        services.AddScoped<IInventoryTracker, StubInventoryTracker>();

        services.AddInvoicingModule(configuration);
        var serviceProvider = services.BuildServiceProvider();
        
        var useCaseTypes = InvoicingCoreAssembly.GetTypes()
            .Where(t => t.IsClass && !t.IsAbstract && t.Name.EndsWith("UseCase"))
            .ToList();

        var unregisteredUseCases = new List<string>();

        foreach (var useCaseType in useCaseTypes)
        {
            var service = serviceProvider.GetService(useCaseType);
            if (service == null)
            {
                unregisteredUseCases.Add(useCaseType.FullName!);
            }
        }

        unregisteredUseCases.ShouldBeEmpty($"The following use cases are not registered " +
                                           $"in the DI container:\n{string.Join("\n", unregisteredUseCases)}");
    }
}

/// <summary>
/// Stub implementation of IProductDetailsHandler for DI testing
/// </summary>
internal class StubProductDetailsHandler : IProductDetailsHandler
{
    public Task<Result<List<ProductDetailsResponse>>> GetMultipleProducts(IEnumerable<long> productIds, string userId)
    {
        return Task.FromResult(Result<List<ProductDetailsResponse>>.Success(new List<ProductDetailsResponse>()));
    }
}

/// <summary>
/// Stub implementation of IInventoryTracker for DI testing
/// </summary>
internal class StubInventoryTracker : IInventoryTracker
{
    public Task<Result> ValidateStockAvailability(Dictionary<long, decimal> productQuantities, string appUserId)
    {
        return Task.FromResult(Result.Success());
    }

    public Task<Result> DeductStock(Dictionary<long, decimal> productQuantities, string appUserId)
    {
        return Task.FromResult(Result.Success());
    }

    public Task<Result> RestoreStock(Dictionary<long, decimal> productQuantities, string appUserId)
    {
        return Task.FromResult(Result.Success());
    }
}

