﻿using ArchUnitNET.xUnit;
using static ArchUnitNET.Fluent.ArchRuleDefinition;

namespace InvadePay.ArchitectureTests.Invoicing;

public class InvoicingLayerTests : BaseArchitectureTest
{
    [Fact]
    public void Core_should_not_depend_on_Infrastructure()
    {
        var rule = Types().That().Are(InvoicingCoreModule)
            .Should().NotDependOnAny(InvoicingInfrastructureModule)
            .Because("Core should not depend on Infrastructure - InvadePay.Invoicing.Core should not reference InvadePay.Invoicing.Infrastructure")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }

    [Fact]
    public void Core_should_not_depend_on_Api()
    {
        var rule = Types().That().Are(InvoicingCoreModule)
            .Should().NotDependOnAny(InvoicingApiModule)
            .Because("Core should not depend on Api - Business logic shouldn't know about API concerns")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }

    [Fact]
    public void Infrastructure_should_not_depend_on_Api()
    {
        var rule = Types().That().Are(InvoicingInfrastructureModule)
            .Should().NotDependOnAny(InvoicingApiModule)
            .Because("Infrastructure can depend on Core - But not vice versa")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }
}

