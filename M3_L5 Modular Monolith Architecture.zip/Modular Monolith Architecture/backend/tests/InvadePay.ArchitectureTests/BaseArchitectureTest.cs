﻿using ArchUnitNET.Domain;
using ArchUnitNET.Loader;
using static ArchUnitNET.Fluent.ArchRuleDefinition;

namespace InvadePay.ArchitectureTests;

public abstract class BaseArchitectureTest
{
    private static readonly string CommonNamespacePattern = ToNamespacePattern(GetRootNamespace<InvadePay.Common.Api.IEndpoint>());
    private static readonly string UsersNamespacePattern = ToNamespacePattern(typeof(InvadePay.Users.UsersModuleEntryPoint).Namespace!);
    private static readonly string InventoryNamespacePattern = ToNamespacePattern(typeof(InvadePay.Inventory.InventoryModuleEntryPoint).Namespace!);
    private static readonly string InventoryContractsNamespacePattern = ToNamespacePattern(typeof(InvadePay.Inventory.Contracts.IInventoryTracker).Namespace!);
    private static readonly string InvoicingNamespacePattern = ToNamespacePattern(GetRootNamespace<InvadePay.Invoicing.Core.Features.Shared.IDbContext>());
    private static readonly string InvoicingContractsNamespacePattern = ToNamespacePattern(typeof(InvadePay.Invoicing.Contracts.IProductUsageChecker).Namespace!);
    private static readonly string InvoicingCoreNamespacePattern = ToNamespacePattern(GetRootNamespace<InvadePay.Invoicing.Core.Features.Shared.IDbContext>(3));
    private static readonly string InvoicingApiNamespacePattern = ToNamespacePattern(typeof(InvadePay.Invoicing.Api.InvoicingModuleEntryPoint).Namespace!);
    private static readonly string InvoicingInfrastructureNamespacePattern = ToNamespacePattern(GetRootNamespace<InvadePay.Invoicing.Infrastructure.Database.InvoicingContext>(3));

    protected static readonly Architecture Architecture = new ArchLoader()
        .LoadAssemblies(
            typeof(InvadePay.Common.Api.IEndpoint).Assembly,
            typeof(InvadePay.Users.UsersModuleEntryPoint).Assembly,
            typeof(InvadePay.Inventory.InventoryModuleEntryPoint).Assembly,
            typeof(InvadePay.Inventory.Contracts.IInventoryTracker).Assembly,
            typeof(InvadePay.Invoicing.Core.Features.Shared.IDbContext).Assembly,
            typeof(InvadePay.Invoicing.Api.InvoicingModuleEntryPoint).Assembly,
            typeof(InvadePay.Invoicing.Contracts.IProductUsageChecker).Assembly,
            typeof(InvadePay.Invoicing.Infrastructure.Database.InvoicingContext).Assembly
        )
        .Build();

    protected static readonly IObjectProvider<IType> CommonProject =
        Types().That().ResideInNamespaceMatching(CommonNamespacePattern);

    protected static readonly IObjectProvider<IType> UsersModule =
        Types().That().ResideInNamespaceMatching(UsersNamespacePattern);

    protected static readonly IObjectProvider<IType> InventoryModuleInternals =
        Types().That().ResideInNamespaceMatching(InventoryNamespacePattern)
            .And().DoNotResideInNamespaceMatching(InventoryContractsNamespacePattern);

    protected static readonly IObjectProvider<IType> InventoryModuleAll =
        Types().That().ResideInNamespaceMatching(InventoryNamespacePattern);

    protected static readonly IObjectProvider<IType> InvoicingModuleInternals =
        Types().That().ResideInNamespaceMatching(InvoicingNamespacePattern)
            .And().DoNotResideInNamespaceMatching(InvoicingContractsNamespacePattern);

    protected static readonly IObjectProvider<IType> InvoicingModuleAll =
        Types().That().ResideInNamespaceMatching(InvoicingNamespacePattern);

    protected static readonly IObjectProvider<IType> InvoicingCoreModule =
        Types().That().ResideInNamespaceMatching(InvoicingCoreNamespacePattern);

    protected static readonly IObjectProvider<IType> InvoicingApiModule =
        Types().That().ResideInNamespaceMatching(InvoicingApiNamespacePattern);

    protected static readonly IObjectProvider<IType> InvoicingInfrastructureModule =
        Types().That().ResideInNamespaceMatching(InvoicingInfrastructureNamespacePattern);

    /// <summary>
    /// Gets the root namespace from a type, taking the first N segments of the namespace.
    /// For example, for "InvadePay.Invoicing.Core.Features.Shared" with levels=2, returns "InvadePay.Invoicing"
    /// </summary>
    private static string GetRootNamespace<T>(int levels = 2)
    {
        var ns = typeof(T).Namespace!;
        var parts = ns.Split('.');
        return string.Join(".", parts.Take(levels));
    }

    /// <summary>
    /// Converts a namespace to a regex pattern that matches the namespace and all sub-namespaces.
    /// For example, "InvadePay.Users" becomes "^InvadePay\.Users($|\.)"
    /// </summary>
    private static string ToNamespacePattern(string ns)
    {
        // Escape dots for regex and create pattern that matches exact namespace or sub-namespaces
        var escaped = ns.Replace(".", @"\.");
        return $"^{escaped}($|\\.)";
    }
}

