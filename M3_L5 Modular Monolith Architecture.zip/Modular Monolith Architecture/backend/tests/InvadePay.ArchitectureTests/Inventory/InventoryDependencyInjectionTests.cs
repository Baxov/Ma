﻿using System.Reflection;
using InvadePay.Common.Interceptors;
using InvadePay.Inventory;
using InvadePay.Invoicing.Contracts;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Shouldly;

namespace InvadePay.ArchitectureTests.Inventory;

public class InventoryDependencyInjectionTests : BaseArchitectureTest
{
    private static readonly Assembly InventoryAssembly = typeof(InventoryModuleEntryPoint).Assembly;

    [Fact]
    public void All_UseCases_should_be_registered_in_DI_container()
    {
        var services = new ServiceCollection();
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["InventoryDatabase:ConnectionString"] = "Server=test;Database=test;",
                ["InventoryDatabase:CommandTimeout"] = "30",
                ["InventoryDatabase:MaxRetryCount"] = "3"
            })
            .Build();

        services.AddLogging();
        services.AddScoped<AuditInterceptor>();
        
        services.AddScoped<IProductUsageChecker, StubProductUsageChecker>();

        services.AddInventoryModule(configuration);
        var serviceProvider = services.BuildServiceProvider();
        
        var useCaseTypes = InventoryAssembly.GetTypes()
            .Where(t => t.IsClass && !t.IsAbstract && t.Name.EndsWith("UseCase"))
            .ToList();

        var unregisteredUseCases = new List<string>();

        foreach (var useCaseType in useCaseTypes)
        {
            var service = serviceProvider.GetService(useCaseType);
            if (service == null)
            {
                unregisteredUseCases.Add(useCaseType.FullName!);
            }
        }

        unregisteredUseCases.ShouldBeEmpty($"The following use cases are not registered " +
                                           $"in the DI container:\n{string.Join("\n", unregisteredUseCases)}");
    }
}

/// <summary>
/// Stub implementation of IProductUsageChecker for DI testing
/// </summary>
internal class StubProductUsageChecker : IProductUsageChecker
{
    public Task<bool> IsProductUsedInInvoices(long productId)
    {
        return Task.FromResult(false);
    }
}

