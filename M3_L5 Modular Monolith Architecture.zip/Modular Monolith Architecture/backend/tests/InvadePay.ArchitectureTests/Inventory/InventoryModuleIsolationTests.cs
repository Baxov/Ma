﻿using ArchUnitNET.xUnit;
using static ArchUnitNET.Fluent.ArchRuleDefinition;

namespace InvadePay.ArchitectureTests.Inventory;

public class InventoryModuleIsolationTests : BaseArchitectureTest
{
    [Fact]
    public void InventoryModule_should_not_depend_on_UsersModule()
    {
        var rule = Types().That().Are(InventoryModuleInternals)
            .Should().NotDependOnAny(UsersModule)
            .Because("Inventory module should not depend on Users module")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }

    [Fact]
    public void InventoryModule_should_not_depend_on_InvoicingModule_internals()
    {
        var rule = Types().That().Are(InventoryModuleInternals)
            .Should().NotDependOnAny(InvoicingModuleInternals)
            .Because("Inventory module should not depend on Invoicing module internals, only on Contracts")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }
}

