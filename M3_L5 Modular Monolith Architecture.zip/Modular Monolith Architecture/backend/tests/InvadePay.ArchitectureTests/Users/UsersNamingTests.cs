﻿using ArchUnitNET.xUnit;
using FluentValidation;
using InvadePay.Common.Api;
using static ArchUnitNET.Fluent.ArchRuleDefinition;

namespace InvadePay.ArchitectureTests.Users;

public class UsersNamingTests : BaseArchitectureTest
{
    [Fact]
    public void Validators_should_end_with_Validator()
    {
        var rule = Classes().That().Are(UsersModule)
            .And().AreAssignableTo(typeof(AbstractValidator<>))
            .Should().HaveNameEndingWith("Validator")
            .Because("Validators should end with Validator")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }

    [Fact]
    public void Endpoints_should_end_with_Endpoint()
    {
        var rule = Classes().That().Are(UsersModule)
            .And().AreAssignableTo(typeof(IEndpoint))
            .Should().HaveNameEndingWith("Endpoint")
            .Because("Endpoints should end with Endpoint")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }
}

