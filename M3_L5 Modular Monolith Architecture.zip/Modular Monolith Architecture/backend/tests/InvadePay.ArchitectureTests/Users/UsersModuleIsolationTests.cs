﻿using ArchUnitNET.xUnit;
using static ArchUnitNET.Fluent.ArchRuleDefinition;

namespace InvadePay.ArchitectureTests.Users;

public class UsersModuleIsolationTests : BaseArchitectureTest
{
    [Fact]
    public void UsersModule_should_not_depend_on_InventoryModule_internals()
    {
        var rule = Types().That().Are(UsersModule)
            .Should().NotDependOnAny(InventoryModuleInternals)
            .Because("Users module should not depend on Inventory module internals, only on Contracts")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }

    [Fact]
    public void UsersModule_should_not_depend_on_InvoicingModule_internals()
    {
        var rule = Types().That().Are(UsersModule)
            .Should().NotDependOnAny(InvoicingModuleInternals)
            .Because("Users module should not depend on Invoicing module internals, only on Contracts")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }
}

