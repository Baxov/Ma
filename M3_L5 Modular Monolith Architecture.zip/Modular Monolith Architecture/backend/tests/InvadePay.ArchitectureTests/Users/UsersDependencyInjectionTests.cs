﻿using System.Reflection;
using InvadePay.Common.Interceptors;
using InvadePay.Users;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Shouldly;

namespace InvadePay.ArchitectureTests.Users;

public class UsersDependencyInjectionTests : BaseArchitectureTest
{
    private static readonly Assembly UsersAssembly = typeof(UsersModuleEntryPoint).Assembly;

    [Fact]
    public void All_UseCases_should_be_registered_in_DI_container()
    {
        var services = new ServiceCollection();
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["UsersDatabase:ConnectionString"] = "Server=test;Database=test;",
                ["UsersDatabase:CommandTimeout"] = "30",
                ["UsersDatabase:MaxRetryCount"] = "3",
                ["Jwt:Key"] = "test-secret-key-that-is-long-enough-for-testing-purposes",
                ["Jwt:Issuer"] = "test-issuer",
                ["Jwt:Audience"] = "test-audience",
                ["Jwt:ExpiryInMinutes"] = "60",
                ["Jwt:RefreshTokenExpiryInMinutes"] = "10080"
            })
            .Build();

        services.AddLogging();
        services.AddDataProtection();
        services.AddScoped<AuditInterceptor>();
        services.AddUsersModule(configuration);
        var serviceProvider = services.BuildServiceProvider();

        var useCaseTypes = UsersAssembly.GetTypes()
            .Where(t => t.IsClass && !t.IsAbstract && t.Name.EndsWith("UseCase"))
            .ToList();

        var unregisteredUseCases = new List<string>();

        foreach (var useCaseType in useCaseTypes)
        {
            var service = serviceProvider.GetService(useCaseType);
            if (service == null)
            {
                unregisteredUseCases.Add(useCaseType.FullName!);
            }
        }

        unregisteredUseCases.ShouldBeEmpty($"The following use cases are not registered " +
                                           $"in the DI container:\n{string.Join("\n", unregisteredUseCases)}");
    }
}

