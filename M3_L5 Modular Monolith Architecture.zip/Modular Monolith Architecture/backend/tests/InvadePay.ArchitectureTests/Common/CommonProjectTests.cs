﻿using ArchUnitNET.xUnit;
using static ArchUnitNET.Fluent.ArchRuleDefinition;

namespace InvadePay.ArchitectureTests.Common;

public class CommonProjectTests : BaseArchitectureTest
{
    [Fact]
    public void CommonProject_should_not_depend_on_UsersModule()
    {
        var rule = Types().That().Are(CommonProject)
            .Should().NotDependOnAny(UsersModule)
            .Because("Common project should not depend on any module")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }

    [Fact]
    public void CommonProject_should_not_depend_on_InventoryModule()
    {
        var rule = Types().That().Are(CommonProject)
            .Should().NotDependOnAny(InventoryModuleAll)
            .Because("Common project should not depend on any module")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }

    [Fact]
    public void CommonProject_should_not_depend_on_InvoicingModule()
    {
        var rule = Types().That().Are(CommonProject)
            .Should().NotDependOnAny(InvoicingModuleAll)
            .Because("Common project should not depend on any module")
            .WithoutRequiringPositiveResults();

        rule.Check(Architecture);
    }
}

