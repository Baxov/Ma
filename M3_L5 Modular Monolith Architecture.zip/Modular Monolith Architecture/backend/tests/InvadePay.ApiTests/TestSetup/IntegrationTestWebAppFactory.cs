﻿using InvadePay.ApiTests.TestSetup.Fakes;
using Respawn;
using InvadePay.Users.Database;
using InvadePay.Inventory.Database;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Shared;
using InvadePay.Invoicing.Core.Features.Shared;
using InvadePay.Invoicing.Infrastructure.Database;
using InvadePay.Users.Shared.Emailing;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Testcontainers.MsSql;

namespace InvadePay.ApiTests.TestSetup;

public class IntegrationTestWebAppFactory : WebApplicationFactory<Program>, IAsyncLifetime
{
    private readonly MsSqlContainer _dbContainer = new MsSqlBuilder("mcr.microsoft.com/mssql/server:2022-latest")
        .WithPassword("Password123!")
        .WithName($"invadepaytests{Guid.NewGuid().ToString().Replace("-", "")}")
        .Build();

    private Respawner _respawner = null!;

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Test");

        builder.ConfigureTestServices(services =>
        {
            // Remove UsersContext descriptor
            var usersDbDescriptor = services.SingleOrDefault(
                d => d.ServiceType ==
                     typeof(DbContextOptions<UsersContext>));

            if (usersDbDescriptor != null)
            {
                services.Remove(usersDbDescriptor);
            }

            // Remove InventoryContext descriptor
            var inventoryDbDescriptor = services.SingleOrDefault(
                d => d.ServiceType ==
                     typeof(DbContextOptions<InventoryContext>));

            if (inventoryDbDescriptor != null)
            {
                services.Remove(inventoryDbDescriptor);
            }

            // Remove InvoicingContext descriptor
            var invoicingDbDescriptor = services.SingleOrDefault(
                d => d.ServiceType ==
                     typeof(DbContextOptions<InvoicingContext>));

            if (invoicingDbDescriptor != null)
            {
                services.Remove(invoicingDbDescriptor);
            }

            services.RemoveAll<IInvoicingEmailSender>();
            services.AddSingleton<IInvoicingEmailSender, FakeInvoicingEmailSender>();
            services.RemoveAll<IRecurringInvoiceJobService>();
            services.AddSingleton<IRecurringInvoiceJobService, FakeRecurringInvoiceJobService>();
            services.RemoveAll<IUserEmailSender>();
            services.AddSingleton<IUserEmailSender, FakeUserEmailSender>();

            // Configure UsersContext for testing
            services.AddDbContext<UsersContext>(options => options.UseSqlServer(_dbContainer.GetConnectionString()));

            // Configure InventoryContext for testing
            services.AddDbContext<InventoryContext>(options => options.UseSqlServer(_dbContainer.GetConnectionString()));

            // Configure InvoicingContext for testing
            services.AddDbContext<InvoicingContext>(options => options.UseSqlServer(_dbContainer.GetConnectionString()));
        });
    }

    public async Task InitializeAsync()
    {
        await _dbContainer.StartAsync();

        // Apply migrations after container is started
        using var scope = Services.CreateScope();

        // Migrate UsersContext
        var usersContext = scope.ServiceProvider.GetRequiredService<UsersContext>();
        await usersContext.Database.MigrateAsync();

        // Migrate InventoryContext
        var inventoryContext = scope.ServiceProvider.GetRequiredService<InventoryContext>();
        await inventoryContext.Database.MigrateAsync();

        // Migrate InvoicingContext
        var invoicingContext = scope.ServiceProvider.GetRequiredService<InvoicingContext>();
        await invoicingContext.Database.MigrateAsync();

        // Initialize Respawner after migrations
        _respawner = await Respawner.CreateAsync(_dbContainer.GetConnectionString(), new RespawnerOptions
        {
            DbAdapter = DbAdapter.SqlServer,
            TablesToIgnore = ["__EFMigrationsHistory"]
        });
    }

    public async Task ResetDatabaseAsync()
    {
        await _respawner.ResetAsync(_dbContainer.GetConnectionString());
    }

    public new async Task DisposeAsync()
    {
        await _dbContainer.DisposeAsync();
        await base.DisposeAsync();
    }
}
