﻿using System.Net.Http.Headers;
using InvadePay.ApiTests.Customers;
using InvadePay.ApiTests.Products;
using InvadePay.ApiTests.TestSetup.Defaults;
using InvadePay.ApiTests.Users;
using InvadePay.Inventory.Features.Create;
using InvadePay.Invoicing.Core.Features.Customers.Create;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Create;
using Refit;
using Shouldly;

namespace InvadePay.ApiTests.TestSetup;

public class RecurringInvoiceTestHelper
{
    private readonly IntegrationTestWebAppFactory _factory;

    public RecurringInvoiceTestHelper(IntegrationTestWebAppFactory factory)
    {
        _factory = factory;
    }

    public static RecurringInvoiceTestHelper Using(IntegrationTestWebAppFactory factory)
    {
        return new RecurringInvoiceTestHelper(factory);
    }

    public async Task<RecurringInvoiceTestData> CreateRecurringInvoiceTestData(TestUser? testUser = null)
    {
        var user = testUser ?? await CreateTestUser();
        var customer = await CreateTestCustomer(user);
        var product = await CreateTestProduct(user);

        return new RecurringInvoiceTestData
        {
            User = user,
            Customer = customer,
            Product = product
        };
    }

    public async Task<TestUser> CreateTestUser()
    {
        return await UserBuilder.New()
            .WithClient(_factory.CreateClient())
            .Register();
    }

    private async Task<CustomerResult> CreateTestCustomer(TestUser user)
    {
        var client = CreateAuthorizedClient(user);
        var customerApi = RestService.For<ICustomerApi>(client);

        var customerRequest = new CreateCustomerRequest("Test Customer", "customer@test.com");
        var customerResponse = await customerApi.CreateCustomer(customerRequest);

        customerResponse.IsSuccessful.ShouldBeTrue();

        return new CustomerResult
        {
            Id = customerResponse.Content!.Id,
            Name = customerResponse.Content.Name,
            Email = customerResponse.Content.Email
        };
    }

    public async Task<ProductResult> CreateTestProduct(TestUser user)
    {
        var client = CreateAuthorizedClient(user);
        var productApi = RestService.For<IProductApi>(client);

        var productRequest = new CreateProductRequest(DefaultProduct.Name, DefaultProduct.Price);
        var productResponse = await productApi.CreateProduct(productRequest);

        productResponse.IsSuccessful.ShouldBeTrue();

        return new ProductResult
        {
            Id = productResponse.Content!.Id,
            Name = productResponse.Content.Name,
            Price = productResponse.Content.DefaultPrice ?? 0
        };
    }

    public static CreateRecurringInvoiceRequest CreateDefaultRecurringInvoiceRequest(
        long customerId,
        long productId,
        string? time = null,
        string? frequency = null,
        DateTime? startDate = null,
        DateTime? endDate = null,
        decimal? quantity = null,
        decimal? price = null,
        decimal? discount = null)
    {
        var items = new List<CreateRecurringInvoiceLineRequest>
        {
            new(
                productId,
                quantity ?? DefaultRecurringInvoice.Item.Quantity,
                price ?? DefaultRecurringInvoice.Item.Price,
                discount ?? DefaultRecurringInvoice.Item.Discount)
        };

        DateOnly? computedEndDate;
        if (endDate != null)
        {
            computedEndDate = DateOnly.FromDateTime(endDate.Value);
        }
        else if (DefaultRecurringInvoice.EndDate != null)
        {
            computedEndDate = DateOnly.FromDateTime(DefaultRecurringInvoice.EndDate.Value);
        }
        else
        {
            computedEndDate = null;
        }

        return new CreateRecurringInvoiceRequest(
            customerId,
            time ?? DefaultRecurringInvoice.Time,
            frequency ?? DefaultRecurringInvoice.Frequency,
            startDate != null ? DateOnly.FromDateTime(startDate.Value) : DateOnly.FromDateTime(DefaultRecurringInvoice.StartDate),
            computedEndDate,
            items);
    }

    public static CreateRecurringInvoiceRequest CreateRecurringInvoiceRequestWithMultipleItems(
        long customerId,
        IEnumerable<(long ProductId, decimal Quantity, decimal Price, decimal? Discount)> items,
        string? time = null,
        string? frequency = null,
        DateTime? startDate = null,
        DateTime? endDate = null)
    {
        var lineItems = items.Select(item => new CreateRecurringInvoiceLineRequest(
            item.ProductId,
            item.Quantity,
            item.Price,
            item.Discount)).ToList();

        DateOnly? computedEndDate;
        if (endDate != null)
        {
            computedEndDate = DateOnly.FromDateTime(endDate.Value);
        }
        else if (DefaultRecurringInvoice.EndDate != null)
        {
            computedEndDate = DateOnly.FromDateTime(DefaultRecurringInvoice.EndDate.Value);
        }
        else
        {
            computedEndDate = null;
        }

        return new CreateRecurringInvoiceRequest(
            customerId,
            time ?? DefaultRecurringInvoice.Time,
            frequency ?? DefaultRecurringInvoice.Frequency,
            startDate != null ? DateOnly.FromDateTime(startDate.Value) : DateOnly.FromDateTime(DefaultRecurringInvoice.StartDate),
            computedEndDate,
            lineItems);
    }

    private HttpClient CreateAuthorizedClient(TestUser user)
    {
        var client = _factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", user.AccessToken);
        return client;
    }
}

public class RecurringInvoiceTestData
{
    public TestUser User { get; set; } = null!;
    public CustomerResult Customer { get; set; } = null!;
    public ProductResult Product { get; set; } = null!;
}

public class CustomerResult
{
    public long Id { get; set; }
    public string Name { get; set; } = null!;
    public string Email { get; set; } = null!;
}

public class ProductResult
{
    public long Id { get; set; }
    public string Name { get; set; } = null!;
    public decimal Price { get; set; }
}
