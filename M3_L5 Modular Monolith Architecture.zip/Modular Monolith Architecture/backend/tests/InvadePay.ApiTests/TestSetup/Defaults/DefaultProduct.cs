﻿namespace InvadePay.ApiTests.TestSetup.Defaults;

public static class DefaultProduct
{
    public const string Name = "Phone";
    public const decimal Price = 1000.00m;
}

public static class DefaultRecurringInvoice
{
    public const string Time = "17:00";
    public const string Frequency = "Monthly";
    public static readonly DateTime StartDate = DateTime.Today.AddDays(1);
    public static readonly DateTime? EndDate = DateTime.Today.AddDays(90);

    public static class Item
    {
        public const decimal Quantity = 2.0m;
        public const decimal Price = 500.00m;
        public static readonly decimal? Discount = 10.0m;
    }
}