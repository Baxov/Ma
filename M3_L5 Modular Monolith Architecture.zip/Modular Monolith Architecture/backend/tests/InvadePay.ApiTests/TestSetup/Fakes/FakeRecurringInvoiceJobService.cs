﻿using InvadePay.Invoicing.Core.Features.RecurringInvoices.Shared;

namespace InvadePay.ApiTests.TestSetup.Fakes;

public class FakeRecurringInvoiceJobService : IRecurringInvoiceJobService
{
    public Task ScheduleRecurringInvoice(long recurringInvoiceId) => Task.CompletedTask;

    public void UnscheduleRecurringInvoice(string hangfireJobId)
    {
    }
}