﻿using InvadePay.Common.Models;
using InvadePay.Invoicing.Core.Features.Shared;

namespace InvadePay.ApiTests.TestSetup.Fakes;

public class FakeInvoicingEmailSender: IInvoicingEmailSender
{
    public Task<Result> SendInvoiceEmail(string customerEmail, string customerName, string invoiceNumber, byte[] pdfAttachment)
    {
        return Task.FromResult(Result.Success());
    }

    public Task<Result> SendInvoiceDueDateReminderEmail(string customerEmail, string customerName, string invoiceNumber, DateTime dueDate)
    {
        return Task.FromResult(Result.Success());
    }
}
