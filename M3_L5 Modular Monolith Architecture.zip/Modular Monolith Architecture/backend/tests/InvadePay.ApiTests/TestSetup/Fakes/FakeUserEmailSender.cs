﻿using InvadePay.Common.Models;
using InvadePay.Users.Shared.Emailing;

namespace InvadePay.ApiTests.TestSetup.Fakes;

public class FakeUserEmailSender : IUserEmailSender
{
    public Task SendWelcomeEmail(string email)
    {
        return Task.CompletedTask;
    }

    public Task<Result> SendPasswordResetEmail(string email, string resetToken)
    {
        return Task.FromResult(Result.Success());
    }
}