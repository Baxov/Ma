﻿using System.Net.Http.Headers;
using InvadePay.ApiTests.Customers;
using InvadePay.ApiTests.Invoices;
using InvadePay.ApiTests.Products;
using InvadePay.ApiTests.TestSetup.Defaults;
using InvadePay.ApiTests.Users;
using InvadePay.Inventory.Features.Create;
using InvadePay.Invoicing.Core.Features.Customers.Create;
using InvadePay.Invoicing.Core.Features.Invoices.Create;
using Refit;
using Shouldly;

namespace InvadePay.ApiTests.TestSetup;

internal class SetupTest
{
    private readonly IntegrationTestWebAppFactory _factory;

    private SetupTest(IntegrationTestWebAppFactory factory)
    {
        _factory = factory;
    }


    public static SetupTest Using(IntegrationTestWebAppFactory factory)
    {
        return new SetupTest(factory);
    }

    public async Task<ProductResult> CreateProduct(TestUser? testUser = null)
    {
        HttpClient client;
        if (testUser != null)
        {
            client = CreateAuthorizedClient(testUser);
        }
        else
        {
            client = await CreateAuthorizedClient();
        }

        var productApi = RestService.For<IProductApi>(client);
        var productRequest = new CreateProductRequest(DefaultProduct.Name, DefaultProduct.Price);
        var productResponse = await productApi.CreateProduct(productRequest);

        productResponse.IsSuccessful.ShouldBeTrue();

        return new ProductResult
        {
            Id = productResponse.Content!.Id,
        };
    }

    public async Task<CustomerResult> CreateCustomer(TestUser? testUser = null)
    {
        HttpClient client;
        if (testUser != null)
        {
            client = CreateAuthorizedClient(testUser);
        }
        else
        {
            client = await CreateAuthorizedClient();
        }

        var customerApi = RestService.For<ICustomerApi>(client);

        var request = new CreateCustomerRequest(
            Name: "John Doe",
            Email: $"john.doe.{Guid.NewGuid()}@example.com"
        );

        var response = await customerApi.CreateCustomer(request);
        response.IsSuccessful.ShouldBeTrue();

        return new CustomerResult
        {
            Id = response.Content!.Id,
            Name = request.Name,
            Email = request.Email
        };
    }

    public async Task<CreateInvoiceResponse> CreateInvoice(TestUser? testUser = null)
    {
        var product = await CreateProduct(testUser);
        var customer = await CreateCustomer(testUser);

        HttpClient client;
        if(testUser != null)
        {
            client = CreateAuthorizedClient(testUser);
        }
        else
        {
            client = await CreateAuthorizedClient();
        }
        var invoiceApi = RestService.For<IInvoiceApi>(client);

        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnly.FromDateTime(DateTime.Today),
            DueDate: DateOnly.FromDateTime(DateTime.Today.AddDays(30)),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new CreateInvoiceLineRequest(
                    ProductId: product.Id,
                    Quantity: 1,
                    Price: 100.00m,
                    Discount: 0m
                )
            }
        );

        var response = await invoiceApi.CreateInvoice(request);
        response.IsSuccessful.ShouldBeTrue();
        return response.Content!;
    }

    internal HttpClient CreateAuthorizedClient(TestUser testUser)
    {
        var client = _factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", testUser.AccessToken);

        return client;
    }

    internal async Task<HttpClient> CreateAuthorizedClient()
    {
        var testUser = await UserBuilder.New()
            .WithClient(_factory.CreateClient())
            .Register();

        return CreateAuthorizedClient(testUser);
    }
}
