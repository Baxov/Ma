using System.Net;
using System.Net.Http.Headers;
using InvadePay.ApiTests.TestSetup;
using InvadePay.ApiTests.TestSetup.Defaults;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Update;
using Refit;
using Shouldly;

namespace InvadePay.ApiTests.RecurringInvoices;

public class RecurringInvoiceTests(IntegrationTestWebAppFactory factory) : BaseIntegrationTest(factory)
{
    [Fact]
    public async Task Create_recurring_invoice_returns_bad_request_when_customer_does_not_exist()
    {
        var testHelper = RecurringInvoiceTestHelper.Using(Factory);
        var testData = await testHelper.CreateRecurringInvoiceTestData();

        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", testData.User.AccessToken);
        var recurringInvoiceApi = RestService.For<IRecurringInvoiceApi>(client);

        var request = RecurringInvoiceTestHelper.CreateDefaultRecurringInvoiceRequest(
            999L,
            testData.Product.Id);

        var response = await recurringInvoiceApi.CreateRecurringInvoice(request);

        response.IsSuccessStatusCode.ShouldBeFalse();
        response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task Get_recurring_invoice_returns_ok_when_invoice_exists()
    {
        var testHelper = RecurringInvoiceTestHelper.Using(Factory);
        var testData = await testHelper.CreateRecurringInvoiceTestData();

        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", testData.User.AccessToken);
        var recurringInvoiceApi = RestService.For<IRecurringInvoiceApi>(client);

        var createRequest = RecurringInvoiceTestHelper.CreateDefaultRecurringInvoiceRequest(
            testData.Customer.Id,
            testData.Product.Id);
        var createResponse = await recurringInvoiceApi.CreateRecurringInvoice(createRequest);
        createResponse.IsSuccessStatusCode.ShouldBeTrue();

        var getResponse = await recurringInvoiceApi.GetRecurringInvoice(createResponse.Content!.Id);

        getResponse.IsSuccessStatusCode.ShouldBeTrue();
        getResponse.StatusCode.ShouldBe(HttpStatusCode.OK);
        getResponse.Content.ShouldNotBeNull();
        getResponse.Content.Id.ShouldBe(createResponse.Content.Id);
        getResponse.Content.CustomerName.ShouldBe(testData.Customer.Name);
        getResponse.Content.Items.Count.ShouldBe(1);

        var item = getResponse.Content.Items.First();
        item.ProductName.ShouldBe("Phone");
        item.Quantity.ShouldBe(DefaultRecurringInvoice.Item.Quantity);
        item.Price.ShouldBe(DefaultRecurringInvoice.Item.Price);
    }

    [Fact]
    public async Task Get_recurring_invoice_returns_not_found_when_invoice_does_not_exist()
    {
        var testHelper = RecurringInvoiceTestHelper.Using(Factory);
        var testData = await testHelper.CreateRecurringInvoiceTestData();

        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", testData.User.AccessToken);
        var recurringInvoiceApi = RestService.For<IRecurringInvoiceApi>(client);

        var response = await recurringInvoiceApi.GetRecurringInvoice(999L);

        response.IsSuccessStatusCode.ShouldBeFalse();
        response.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task Get_recurring_invoices_returns_paginated_list()
    {
        var testHelper = RecurringInvoiceTestHelper.Using(Factory);
        var testData = await testHelper.CreateRecurringInvoiceTestData();

        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", testData.User.AccessToken);
        var recurringInvoiceApi = RestService.For<IRecurringInvoiceApi>(client);

        for (var i = 0; i < 3; i++)
        {
            var createRequest = RecurringInvoiceTestHelper.CreateDefaultRecurringInvoiceRequest(
                testData.Customer.Id,
                testData.Product.Id);
            var createResponse = await recurringInvoiceApi.CreateRecurringInvoice(createRequest);
            createResponse.IsSuccessStatusCode.ShouldBeTrue();
        }

        var listResponse = await recurringInvoiceApi.GetRecurringInvoices(1, 10);

        listResponse.IsSuccessStatusCode.ShouldBeTrue();
        listResponse.StatusCode.ShouldBe(HttpStatusCode.OK);
        listResponse.Content.ShouldNotBeNull();
        listResponse.Content.Items.Count.ShouldBe(3);
        listResponse.Content.TotalCount.ShouldBe(3);
        listResponse.Content.Page.ShouldBe(1);
        listResponse.Content.PageSize.ShouldBe(10);
    }

    [Fact]
    public async Task Update_recurring_invoice_returns_ok_when_request_is_valid()
    {
        var testHelper = RecurringInvoiceTestHelper.Using(Factory);
        var testData = await testHelper.CreateRecurringInvoiceTestData();

        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", testData.User.AccessToken);
        var recurringInvoiceApi = RestService.For<IRecurringInvoiceApi>(client);

        var createRequest = RecurringInvoiceTestHelper.CreateDefaultRecurringInvoiceRequest(
            testData.Customer.Id,
            testData.Product.Id);
        var createResponse = await recurringInvoiceApi.CreateRecurringInvoice(createRequest);
        createResponse.IsSuccessStatusCode.ShouldBeTrue();

        var updateRequest = new UpdateRecurringInvoiceRequest(
            "Weekly",
            DateOnly.FromDateTime(DateTime.Today.AddDays(5)),
            DateOnly.FromDateTime(DateTime.Today.AddDays(60)),
            false);

        var updateResponse = await recurringInvoiceApi.UpdateRecurringInvoice(createResponse.Content!.Id, updateRequest);

        updateResponse.IsSuccessStatusCode.ShouldBeTrue();
        updateResponse.StatusCode.ShouldBe(HttpStatusCode.OK);
        updateResponse.Content.ShouldNotBeNull();
        updateResponse.Content.Frequency.ShouldBe("Weekly");
        updateResponse.Content.IsActive.ShouldBeFalse();
    }

    [Fact]
    public async Task Update_recurring_invoice_returns_not_found_when_invoice_does_not_exist()
    {
        var testHelper = RecurringInvoiceTestHelper.Using(Factory);
        var testData = await testHelper.CreateRecurringInvoiceTestData();

        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", testData.User.AccessToken);
        var recurringInvoiceApi = RestService.For<IRecurringInvoiceApi>(client);

        var updateRequest = new UpdateRecurringInvoiceRequest(
            "Weekly",
            DateOnly.FromDateTime(DateTime.Today.AddDays(1)),
            DateOnly.FromDateTime(DateTime.Today.AddDays(30)),
            true);

        var response = await recurringInvoiceApi.UpdateRecurringInvoice(999L, updateRequest);

        response.IsSuccessStatusCode.ShouldBeFalse();
        response.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task Delete_recurring_invoice_returns_ok_when_invoice_exists()
    {
        var testHelper = RecurringInvoiceTestHelper.Using(Factory);
        var testData = await testHelper.CreateRecurringInvoiceTestData();

        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", testData.User.AccessToken);
        var recurringInvoiceApi = RestService.For<IRecurringInvoiceApi>(client);

        var createRequest = RecurringInvoiceTestHelper.CreateDefaultRecurringInvoiceRequest(
            testData.Customer.Id,
            testData.Product.Id);
        var createResponse = await recurringInvoiceApi.CreateRecurringInvoice(createRequest);
        createResponse.IsSuccessStatusCode.ShouldBeTrue();

        var deleteResponse = await recurringInvoiceApi.DeleteRecurringInvoice(createResponse.Content!.Id);

        deleteResponse.IsSuccessStatusCode.ShouldBeTrue();
        deleteResponse.StatusCode.ShouldBe(HttpStatusCode.NoContent);

        var getResponse = await recurringInvoiceApi.GetRecurringInvoice(createResponse.Content.Id);
        getResponse.IsSuccessStatusCode.ShouldBeFalse();
        getResponse.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task Delete_recurring_invoice_returns_not_found_when_invoice_does_not_exist()
    {
        var testHelper = RecurringInvoiceTestHelper.Using(Factory);
        var testData = await testHelper.CreateRecurringInvoiceTestData();

        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", testData.User.AccessToken);
        var recurringInvoiceApi = RestService.For<IRecurringInvoiceApi>(client);

        var response = await recurringInvoiceApi.DeleteRecurringInvoice(999L);

        response.IsSuccessStatusCode.ShouldBeFalse();
        response.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task Create_recurring_invoice_with_multiple_items_succeeds()
    {
        var testHelper = RecurringInvoiceTestHelper.Using(Factory);
        var testData = await testHelper.CreateRecurringInvoiceTestData();

        var product2 = await testHelper.CreateTestProduct(testData.User);

        var client = Factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", testData.User.AccessToken);
        var recurringInvoiceApi = RestService.For<IRecurringInvoiceApi>(client);

        var items = new[]
        {
            (testData.Product.Id, 2.0m, 100.0m, 5.0m),
            (product2.Id, 1.0m, 200.0m, (decimal?)null)
        };

        var request = RecurringInvoiceTestHelper.CreateRecurringInvoiceRequestWithMultipleItems(
            testData.Customer.Id,
            items);

        var response = await recurringInvoiceApi.CreateRecurringInvoice(request);

        response.IsSuccessStatusCode.ShouldBeTrue();
        response.Content.ShouldNotBeNull();

        var getResponse = await recurringInvoiceApi.GetRecurringInvoice(response.Content.Id);
        getResponse.IsSuccessStatusCode.ShouldBeTrue();
        getResponse.Content!.Items.Count.ShouldBe(2);
    }
}
