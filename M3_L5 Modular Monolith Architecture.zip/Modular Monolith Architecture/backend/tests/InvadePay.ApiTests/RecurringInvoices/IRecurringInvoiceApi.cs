﻿using InvadePay.Invoicing.Core.Features.RecurringInvoices.Create;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.GetById;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.GetList;
using InvadePay.Invoicing.Core.Features.RecurringInvoices.Update;
using Refit;

namespace InvadePay.ApiTests.RecurringInvoices;

public interface IRecurringInvoiceApi
{
    [Post("/api/recurring-invoices")]
    Task<ApiResponse<CreateRecurringInvoiceResponse>> CreateRecurringInvoice(CreateRecurringInvoiceRequest request);

    [Get("/api/recurring-invoices/{id}")]
    Task<ApiResponse<SingleRecurringInvoiceResponse>> GetRecurringInvoice(long id);

    [Get("/api/recurring-invoices")]
    Task<ApiResponse<PagedRecurringInvoiceListResponse>> GetRecurringInvoices(int page = 1, int pageSize = 10);

    [Put("/api/recurring-invoices/{id}")]
    Task<ApiResponse<UpdateRecurringInvoiceResponse>> UpdateRecurringInvoice(long id, UpdateRecurringInvoiceRequest request);

    [Delete("/api/recurring-invoices/{id}")]
    Task<ApiResponse<string>> DeleteRecurringInvoice(long id);
}
