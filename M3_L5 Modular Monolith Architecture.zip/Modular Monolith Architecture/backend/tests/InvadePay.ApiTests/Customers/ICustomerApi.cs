using InvadePay.Common.Responses;
using InvadePay.Invoicing.Core.Features.Customers.Create;
using InvadePay.Invoicing.Core.Features.Customers.GetById;
using InvadePay.Invoicing.Core.Features.Customers.GetList;
using InvadePay.Invoicing.Core.Features.Customers.Statement;
using InvadePay.Invoicing.Core.Features.Customers.Update;
using Refit;

namespace InvadePay.ApiTests.Customers;

public interface ICustomerApi
{
    [Post("/api/customers")]
    Task<IApiResponse<CreateCustomerResponse>> CreateCustomer([Body] CreateCustomerRequest request);

    [Get("/api/customers")]
    Task<IApiResponse<PagedResponse<CustomerResponse>>> GetCustomers(int? page = null, int? pageSize = null);

    [Get("/api/customers/{id}")]
    Task<IApiResponse<SingleCustomerResponse>> GetCustomerById(long id);

    [Put("/api/customers/{id}")]
    Task<IApiResponse<UpdateCustomerResponse>> UpdateCustomer(long id, [Body] UpdateCustomerRequest request);

    [Delete("/api/customers/{id}")]
    Task<IApiResponse> DeleteCustomer(long id);
    
    [Get("/api/customers/{id}/statement")]
    Task<IApiResponse<CustomerStatementResponse>> GetCustomerStatement(
        long id, 
        DateTime startDate, 
        DateTime endDate);
}