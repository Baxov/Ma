using System.Net;
using InvadePay.ApiTests.Invoices;
using InvadePay.ApiTests.TestSetup;
using InvadePay.ApiTests.Users;
using InvadePay.Invoicing.Core.Features.Customers.Create;
using InvadePay.Invoicing.Core.Features.Customers.Update;
using InvadePay.Invoicing.Core.Features.Invoices.Create;
using InvadePay.Invoicing.Core.Features.Invoices.UpdateStatus;
using Refit;
using Shouldly;

namespace InvadePay.ApiTests.Customers;

public class CustomerTests(IntegrationTestWebAppFactory factory) : BaseIntegrationTest(factory)
{
    [Fact]
    public async Task GET_returns_customer_statement_with_outstanding_and_paid_invoices()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var setupTest = SetupTest.Using(Factory);

        var customer = await setupTest.CreateCustomer(testUser);
        var product = await setupTest.CreateProduct(testUser);

        var invoiceApi = await CreateInvoiceApiClient(testUser);

        var createInvoiceRequest1 = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnly.FromDateTime(DateTime.Today.AddDays(-10)),
            DueDate: DateOnly.FromDateTime(DateTime.Today.AddDays(30)),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(ProductId: product.Id, Quantity: 1, Price: 100.00m, Discount: 0m)
            }
        );

        var createInvoiceRequest2 = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnly.FromDateTime(DateTime.Today.AddDays(-5)),
            DueDate: DateOnly.FromDateTime(DateTime.Today.AddDays(30)),
            Time: "15:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(ProductId: product.Id, Quantity: 1, Price: 200.00m, Discount: 0m)
            }
        );

        var invoice1Response = await invoiceApi.CreateInvoice(createInvoiceRequest1);
        var invoice2Response = await invoiceApi.CreateInvoice(createInvoiceRequest2);

        var invoice1 = invoice1Response.Content!;
        var invoice2 = invoice2Response.Content!;

        var updateToSentRequest = new UpdateInvoiceStatusRequest("Sent");
        await invoiceApi.UpdateStatus(invoice1.Id, updateToSentRequest);

        var updateToPaidRequest = new UpdateInvoiceStatusRequest("Paid");
        await invoiceApi.UpdateStatus(invoice2.Id, updateToPaidRequest);

        var customerStatementApi = await CreateApiClient(testUser);

        var response = await customerStatementApi.GetCustomerStatement(
            customer.Id,
            DateTime.Today.AddDays(-30),
            DateTime.Today);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();

        result.CustomerId.ShouldBe(customer.Id);
        result.CustomerName.ShouldBe(customer.Name);
        result.CustomerEmail.ShouldBe(customer.Email);

        result.OutstandingInvoices.Count.ShouldBe(1);
        result.OutstandingInvoices[0].InvoiceId.ShouldBe(invoice1.Id);

        result.PaidInvoices.Count.ShouldBe(1);
        result.PaidInvoices[0].InvoiceId.ShouldBe(invoice2.Id);

        result.TotalOutstanding.ShouldBeGreaterThan(0);
        result.TotalPaid.ShouldBeGreaterThan(0);
        result.AccountBalance.ShouldBe(100);
    }

    private async Task<IInvoiceApi> CreateInvoiceApiClient(TestUser? testUser)
    {
        var setupTest = SetupTest.Using(Factory);
        HttpClient client;
        if (testUser == null)
        {
            client = await setupTest.CreateAuthorizedClient();
        }
        else
        {
            client = setupTest.CreateAuthorizedClient(testUser);
        }

        return RestService.For<IInvoiceApi>(client);
    }

    [Fact]
    public async Task POST_creates_new_customer()
    {
        var customerApi = await CreateApiClient();

        var request = new CreateCustomerRequest(
            Name: "John Doe",
            Email: "john.doe@example.com"
        );

        var response = await customerApi.CreateCustomer(request);

        response.StatusCode.ShouldBe(HttpStatusCode.Created);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBeGreaterThan(0);
        result.Name.ShouldBe("John Doe");
        result.Email.ShouldBe("john.doe@example.com");
    }

    [Fact]
    public async Task PUT_updates_customer()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var customerResult = await setupTest.CreateCustomer(testUser);

        var client = setupTest.CreateAuthorizedClient(testUser);
        var customerApi = RestService.For<ICustomerApi>(client);

        var request = new UpdateCustomerRequest(
            Name: "Jane Smith",
            Email: "jane.smith@example.com"
        );

        var response = await customerApi.UpdateCustomer(customerResult.Id, request);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBe(customerResult.Id);
        result.Name.ShouldBe("Jane Smith");
        result.Email.ShouldBe("jane.smith@example.com");
    }

    [Fact]
    public async Task PUT_fails_when_email_is_empty()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var customerResult = await setupTest.CreateCustomer(testUser);

        var client = setupTest.CreateAuthorizedClient(testUser);
        var customerApi = RestService.For<ICustomerApi>(client);

        var request = new UpdateCustomerRequest(
            Name: "Jane Smith",
            Email: ""
        );

        var response = await customerApi.UpdateCustomer(customerResult.Id, request);

        response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task GET_returns_paginated_customers()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var customerResult = await setupTest.CreateCustomer(testUser);

        var customerApi = await CreateApiClient(testUser);

        var response = await customerApi.GetCustomers(page: 1, pageSize: 10);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.TotalCount.ShouldBe(1);
        result.Items.Count().ShouldBe(1);

        var createdCustomer = result.Items.First(c => c.Id == customerResult.Id);
        createdCustomer.Id.ShouldBeGreaterThan(0);
        createdCustomer.Name.ShouldBe(customerResult.Name);
        createdCustomer.Email.ShouldBe(customerResult.Email);
    }

    [Fact]
    public async Task GET_by_id_returns_single_customer()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var customerResult = await setupTest.CreateCustomer(testUser);

        var customerApi = await CreateApiClient(testUser);

        var response = await customerApi.GetCustomerById(customerResult.Id);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBe(customerResult.Id);
        result.Name.ShouldBe(customerResult.Name);
        result.Email.ShouldBe(customerResult.Email);
    }

    [Fact]
    public async Task DELETE_removes_customer()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var customerResult = await setupTest.CreateCustomer(testUser);

        var customerApi = await CreateApiClient(testUser);

        var deleteResponse = await customerApi.DeleteCustomer(customerResult.Id);

        deleteResponse.StatusCode.ShouldBe(HttpStatusCode.NoContent);

        var getResponse = await customerApi.GetCustomerById(customerResult.Id);
        getResponse.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }

    private async Task<ICustomerApi> CreateApiClient(TestUser? testUser = null)
    {
        var setupTest = SetupTest.Using(Factory);
        HttpClient client;
        if (testUser != null)
        {
            client = setupTest.CreateAuthorizedClient(testUser);
        }
        else
        {
            client = await setupTest.CreateAuthorizedClient();
        }
        return RestService.For<ICustomerApi>(client);
    }
}
