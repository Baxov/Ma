﻿using InvadePay.Users.Features.Register;
using Refit;

namespace InvadePay.ApiTests.Users;

public class UserBuilder
{
    private HttpClient? _client;
    private const string ValidPassword = "ValidPassword123!";

    public UserBuilder WithClient(HttpClient client)
    {
        _client = client;
        return this;
    }


    public async Task<TestUser> Register()
    {
        if (_client == null)
        {
            throw new InvalidOperationException("Client is not set");
        }
        
        var request = new RegisterRequest(
            Email: Guid.NewGuid().ToString().Replace("-", "") + "@example.com",
            Password: ValidPassword,
            FirstName: "John",
            LastName: "Doe"
        );

        var usersApi = RestService.For<IUsersApi>(_client);
        var result = await usersApi.Register(request);

        return new TestUser(
            result.Content!.UserId,
            request.Email,
            request.Password,
            result.Content!.AccessToken,
            result.Content!.RefreshToken
        );
    }

    public static UserBuilder New()
    {
        return new UserBuilder();
    }
}