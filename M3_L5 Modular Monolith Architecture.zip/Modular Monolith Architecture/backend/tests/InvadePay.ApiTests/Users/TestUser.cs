﻿namespace InvadePay.ApiTests.Users;

public record TestUser(string UserId, string Email, string Password, string AccessToken, string RefreshToken);