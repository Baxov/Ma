﻿using InvadePay.Users.Features.Login;
using InvadePay.Users.Features.RefreshToken;
using InvadePay.Users.Features.Register;
using Refit;

namespace InvadePay.ApiTests.Users;

public interface IUsersApi
{
    [Post("/api/login")]
    Task<IApiResponse<LoginResponse>> Login([Body] LoginRequest request);

    [Post("/api/register")]
    Task<IApiResponse<RegisterResponse>> Register([Body] RegisterRequest request);

    [Post("/api/refresh-token")]
    Task<IApiResponse<RefreshTokenResponse>> RefreshToken([Body] RefreshTokenRequest request);
}