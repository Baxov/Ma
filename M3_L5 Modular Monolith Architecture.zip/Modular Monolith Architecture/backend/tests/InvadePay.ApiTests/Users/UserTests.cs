﻿using System.Net;
using InvadePay.ApiTests.TestSetup;
using InvadePay.Users.Features.Login;
using InvadePay.Users.Features.RefreshToken;
using InvadePay.Users.Features.Register;
using Refit;
using Shouldly;

namespace InvadePay.ApiTests.Users;

public class UserTests : BaseIntegrationTest
{
    private readonly IUsersApi _usersApi;
    public UserTests(IntegrationTestWebAppFactory factory) : base(factory)
    {
        var client = Factory.CreateClient();
        _usersApi = RestService.For<IUsersApi>(client);
    }

    [Fact]
    public async Task Register_fails_when_email_is_not_in_correct_format()
    {
        var request = new RegisterRequest(
            Email: "invalid-email",
            Password: "ValidPassword123!",
            FirstName: "John",
            LastName: "Doe"
        );

        var response = await _usersApi.Register(request);

        response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task Register_creates_new_user_in_application()
    {
        var request = new RegisterRequest(
            Email: "john.doe@example.com",
            Password: "ValidPassword123!",
            FirstName: "John",
            LastName: "Doe"
        );

        var response = await _usersApi.Register(request);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.AccessToken.ShouldNotBeNullOrEmpty();
        result.RefreshToken.ShouldNotBeNullOrEmpty();
        result.UserId.ShouldNotBeNullOrEmpty();
    }
    
    [Fact]
    public async Task Login_succeeds_when_login_data_is_valid()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();
        
        var loginRequest = new LoginRequest(
            Email: testUser.Email,
            Password: testUser.Password
        );

        var loginResponse = await _usersApi.Login(loginRequest);

        loginResponse.StatusCode.ShouldBe(HttpStatusCode.OK);
        var loginResult = loginResponse.Content;
        loginResult.ShouldNotBeNull();
        loginResult.AccessToken.ShouldNotBeNullOrEmpty();
        loginResult.RefreshToken.ShouldNotBeNullOrEmpty();
        loginResult.UserId.ShouldNotBeNullOrEmpty();
    }
    
    [Fact]
    public async Task Login_fails_when_login_data_is_invalid()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();
        
        var loginRequest = new LoginRequest(
            Email: testUser.Email,
            Password: "random"
        );

        var loginResponse = await _usersApi.Login(loginRequest);

        loginResponse.StatusCode.ShouldBe(HttpStatusCode.Unauthorized);
    }

    [Fact]
    public async Task RefreshToken_succeeds_when_refresh_token_is_valid()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var refreshRequest = new RefreshTokenRequest(
            UserId: testUser.UserId,
            RefreshToken: testUser.RefreshToken
        );
        
        var refreshResponse = await _usersApi.RefreshToken(refreshRequest);
        
        refreshResponse.StatusCode.ShouldBe(HttpStatusCode.OK);
        var refreshResult = refreshResponse.Content;
        refreshResult.ShouldNotBeNull();
        refreshResult.AccessToken.ShouldNotBeNullOrEmpty();
        refreshResult.RefreshToken.ShouldNotBeNullOrEmpty();
        refreshResult.UserId.ShouldBe(testUser.UserId);
        
        refreshResult.AccessToken.ShouldNotBe(testUser.AccessToken);
        refreshResult.RefreshToken.ShouldNotBe(testUser.RefreshToken);
    }

    [Fact]
    public async Task RefreshToken_fails_when_refresh_token_is_invalid()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var refreshRequest = new RefreshTokenRequest(
            UserId: testUser.UserId,
            RefreshToken: "invalid-refresh-token"
        );

        var refreshResponse = await _usersApi.RefreshToken(refreshRequest);

        refreshResponse.StatusCode.ShouldBe(HttpStatusCode.Unauthorized);
    }

    [Fact]
    public async Task RefreshToken_fails_when_user_id_is_invalid()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var refreshRequest = new RefreshTokenRequest(
            UserId: Guid.NewGuid().ToString(),
            RefreshToken: testUser.RefreshToken
        );
        
        var refreshResponse = await _usersApi.RefreshToken(refreshRequest);

        refreshResponse.StatusCode.ShouldBe(HttpStatusCode.Unauthorized);
    }
}