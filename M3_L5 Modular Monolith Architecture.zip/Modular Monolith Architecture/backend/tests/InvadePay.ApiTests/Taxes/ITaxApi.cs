﻿using InvadePay.Common.Responses;
using InvadePay.Invoicing.Core.Features.Taxes.Create;
using InvadePay.Invoicing.Core.Features.Taxes.GetById;
using InvadePay.Invoicing.Core.Features.Taxes.GetList;
using InvadePay.Invoicing.Core.Features.Taxes.Update;
using Refit;

namespace InvadePay.ApiTests.Taxes;

public interface ITaxApi
{
    [Post("/api/taxes")]
    Task<IApiResponse<CreateTaxResponse>> CreateTax([Body] CreateTaxRequest request);

    [Get("/api/taxes")]
    Task<IApiResponse<PagedResponse<TaxResponse>>> GetTaxes(int? page = null, int? pageSize = null);

    [Get("/api/taxes/{id}")]
    Task<IApiResponse<SingleTaxResponse>> GetTaxById(long id);

    [Put("/api/taxes/{id}")]
    Task<IApiResponse<UpdateTaxResponse>> UpdateTax(long id, [Body] UpdateTaxRequest request);

    [Delete("/api/taxes/{id}")]
    Task<IApiResponse> DeleteTax(long id);
}
