﻿using System.Net;
using InvadePay.ApiTests.TestSetup;
using InvadePay.ApiTests.Users;
using InvadePay.Invoicing.Core.Features.Taxes.Create;
using InvadePay.Invoicing.Core.Features.Taxes.Update;
using Refit;
using Shouldly;

namespace InvadePay.ApiTests.Taxes;

public class TaxTests(IntegrationTestWebAppFactory factory) : BaseIntegrationTest(factory)
{
    [Fact]
    public async Task POST_creates_new_tax()
    {
        var taxApi = await CreateApiClient();
        
        var request = new CreateTaxRequest("VAT", "Value Added Tax", 20.0m);

        var response = await taxApi.CreateTax(request);

        response.StatusCode.ShouldBe(HttpStatusCode.Created);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBeGreaterThan(0);
        result.Name.ShouldBe("VAT");
        result.Description.ShouldBe("Value Added Tax");
        result.Rate.ShouldBe(20.0m);
    }
    
    [Fact]
    public async Task POST_fails_when_name_is_empty()
    {
        var taxApi = await CreateApiClient();
        
        var request = new CreateTaxRequest("", "Description", 20.0m);

        var response = await taxApi.CreateTax(request);

        response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
    }
    
    [Fact]
    public async Task POST_fails_when_unauthorized()
    {
        var client = Factory.CreateClient(); // No authorization
        var taxApi = RestService.For<ITaxApi>(client);
        
        var request = new CreateTaxRequest("VAT", "Description", 20.0m);

        var response = await taxApi.CreateTax(request);

        response.StatusCode.ShouldBe(HttpStatusCode.Unauthorized);
    }

    [Fact]
    public async Task GET_returns_all_taxes()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var taxResult = await CreateTax(testUser);
        var taxApi = await CreateApiClient(testUser);

        var response = await taxApi.GetTaxes();

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.TotalCount.ShouldBe(1);
        result.Items.Count().ShouldBe(1);

        var createdTax = result.Items.First(t => t.Id == taxResult.Id);
        createdTax.Id.ShouldBeGreaterThan(0);
        createdTax.Name.ShouldBe("VAT");
        createdTax.Rate.ShouldBe(20.0m);
    }

    [Fact]
    public async Task GET_returns_only_user_taxes()
    {
        var user1 = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();
        
        var user2 = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        // Create tax for user1
        await CreateTax(user1);
        
        // Create tax for user2
        await CreateTax(user2);

        // User1 should only see their own tax
        var taxApi1 = await CreateApiClient(user1);
        var response1 = await taxApi1.GetTaxes();

        response1.StatusCode.ShouldBe(HttpStatusCode.OK);
        response1.Content!.TotalCount.ShouldBe(1);

        // User2 should only see their own tax
        var taxApi2 = await CreateApiClient(user2);
        var response2 = await taxApi2.GetTaxes();

        response2.StatusCode.ShouldBe(HttpStatusCode.OK);
        response2.Content!.TotalCount.ShouldBe(1);
    }

    [Fact]
    public async Task GET_by_id_returns_tax()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var taxResult = await CreateTax(testUser);
        var taxApi = await CreateApiClient(testUser);

        var response = await taxApi.GetTaxById(taxResult.Id);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBe(taxResult.Id);
        result.Name.ShouldBe("VAT");
        result.Description.ShouldBe("Value Added Tax");
        result.Rate.ShouldBe(20.0m);
    }

    [Fact]
    public async Task GET_by_id_returns_not_found_when_tax_does_not_exist()
    {
        var taxApi = await CreateApiClient();

        var response = await taxApi.GetTaxById(999);

        response.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task GET_by_id_returns_forbidden_when_tax_belongs_to_different_user()
    {
        var user1 = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();
        
        var user2 = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        // Create tax for user1
        var taxResult = await CreateTax(user1);

        // User2 tries to access user1's tax
        var taxApi2 = await CreateApiClient(user2);
        var response = await taxApi2.GetTaxById(taxResult.Id);

        response.StatusCode.ShouldBe(HttpStatusCode.Forbidden);
    }

    [Fact]
    public async Task PUT_updates_tax()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var taxResult = await CreateTax(testUser);
        var taxApi = await CreateApiClient(testUser);

        var request = new UpdateTaxRequest("GST", "Goods and Services Tax", 15.0m);

        var response = await taxApi.UpdateTax(taxResult.Id, request);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBe(taxResult.Id);
        result.Name.ShouldBe("GST");
        result.Description.ShouldBe("Goods and Services Tax");
        result.Rate.ShouldBe(15.0m);
    }

    [Fact]
    public async Task PUT_fails_when_tax_does_not_exist()
    {
        var taxApi = await CreateApiClient();
        var request = new UpdateTaxRequest("GST", "Description", 15.0m);

        var response = await taxApi.UpdateTax(999, request);

        response.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }
    
    [Fact]
    public async Task DELETE_removes_tax()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var taxResult = await CreateTax(testUser);
        var taxApi = await CreateApiClient(testUser);

        var response = await taxApi.DeleteTax(taxResult.Id);

        response.StatusCode.ShouldBe(HttpStatusCode.NoContent);

        // Verify tax is soft deleted by trying to get it
        var getResponse = await taxApi.GetTaxById(taxResult.Id);
        getResponse.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }

    private async Task<TaxResult> CreateTax(TestUser testUser)
    {
        var setupTest = SetupTest.Using(Factory);
        var client = setupTest.CreateAuthorizedClient(testUser);
        var taxApi = RestService.For<ITaxApi>(client);
        
        var request = new CreateTaxRequest("VAT", "Value Added Tax", 20.0m);
        var response = await taxApi.CreateTax(request);
        
        response.IsSuccessful.ShouldBeTrue();
        
        return new TaxResult
        {
            Id = response.Content!.Id,
            Name = response.Content.Name,
            Description = response.Content.Description,
            Rate = response.Content.Rate
        };
    }

    private async Task<ITaxApi> CreateApiClient(TestUser? testUser = null)
    {
        var setupTest = SetupTest.Using(Factory);
        HttpClient client;
        if (testUser != null)
        {
            client = setupTest.CreateAuthorizedClient(testUser);
        }
        else
        {
            client = await setupTest.CreateAuthorizedClient();
        }

        return RestService.For<ITaxApi>(client);
    }
}

public class TaxResult
{
    public long Id { get; set; }
    public string Name { get; set; } = null!;
    public string? Description { get; set; }
    public decimal Rate { get; set; }
}
