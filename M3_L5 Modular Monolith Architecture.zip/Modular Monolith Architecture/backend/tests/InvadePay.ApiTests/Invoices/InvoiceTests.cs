using System.Net;
using InvadePay.ApiTests.Products;
using InvadePay.ApiTests.TestSetup;
using InvadePay.ApiTests.Users;
using InvadePay.Inventory.Features.Create;
using InvadePay.Inventory.Models;
using InvadePay.Invoicing.Core.Features.Invoices.Create;
using InvadePay.Invoicing.Core.Features.Invoices.Update;
using InvadePay.Invoicing.Core.Features.Invoices.UpdateStatus;
using InvadePay.Invoicing.Core.Models.Invoices;
using Refit;
using Shouldly;

namespace InvadePay.ApiTests.Invoices;

public class InvoiceTests(IntegrationTestWebAppFactory factory) : BaseIntegrationTest(factory)
{
    [Fact]
    public async Task POST_creates_new_invoice()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var invoiceApi = await CreateApiClient(testUser);
        var setupTest = SetupTest.Using(Factory);
        var product = await setupTest.CreateProduct(testUser);
        var customer = await setupTest.CreateCustomer(testUser);

        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnly.FromDateTime(DateTime.Today),
            DueDate: DateOnly.FromDateTime(DateTime.Today.AddDays(30)),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new CreateInvoiceLineRequest(
                    ProductId: product.Id,
                    Quantity: 2,
                    Price: 100.00m,
                    Discount: 10m
                )
            }
        );

        var response = await invoiceApi.CreateInvoice(request);

        response.StatusCode.ShouldBe(HttpStatusCode.Created);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBeGreaterThan(0);
        result.InvoiceId.ShouldNotBeNullOrEmpty();
        result.CustomerName.ShouldBe(customer.Name);
        result.CustomerEmail.ShouldBe(customer.Email);
        result.Date.ShouldBe(DateOnly.FromDateTime(DateTime.Today));
        result.TotalAmount.ShouldBe(180.00m);
    }

    [Fact]
    public async Task GET_returns_all_invoices()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var invoiceResult = await setupTest.CreateInvoice(testUser);
        var invoiceApi = await CreateApiClient(testUser);

        var response = await invoiceApi.GetInvoices(page: 1, pageSize: 10);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.TotalCount.ShouldBe(1);
        result.Items.Count().ShouldBe(1);

        var createdInvoice = result.Items.First(i => i.Id == invoiceResult.Id);
        createdInvoice.Id.ShouldBeGreaterThan(0);
        createdInvoice.CustomerName.ShouldBe(invoiceResult.CustomerName);
        createdInvoice.CustomerEmail.ShouldBe(invoiceResult.CustomerEmail);
    }

    [Fact]
    public async Task GET_by_id_returns_single_invoice()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var invoiceResult = await setupTest.CreateInvoice(testUser);
        var invoiceApi = await CreateApiClient(testUser);

        var response = await invoiceApi.GetInvoiceById(invoiceResult.Id);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBe(invoiceResult.Id);
        result.CustomerName.ShouldBe(invoiceResult.CustomerName);
        result.CustomerEmail.ShouldBe(invoiceResult.CustomerEmail);
        result.Date.ShouldBe(invoiceResult.Date);
        result.TotalAmount.ShouldBe(invoiceResult.TotalAmount);

        result.Items.Count.ShouldBe(1);
        var item = result.Items.First();
        item.Id.ShouldBeGreaterThan(0);
        item.ProductId.ShouldBeGreaterThan(0);
        item.ProductName.ShouldNotBeNullOrEmpty();
        item.Quantity.ShouldBe(1);
        item.Price.ShouldBe(100.00m);
        item.Discount.ShouldBe(0m);
        item.LineTotal.ShouldBe(100.00m);
    }

    [Fact]
    public async Task GET_next_invoice_number_returns_first_number_for_new_user()
    {
        var invoiceApi = await CreateApiClient();

        var response = await invoiceApi.GetNextInvoiceNumber();

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        response.Content.ShouldNotBeNull();
        response.Content.InvoiceNumber.ShouldBe("1-1-1");
    }

    [Fact]
    public async Task PUT_updates_invoice()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var invoiceResult = await setupTest.CreateInvoice(testUser);
        var product = await setupTest.CreateProduct(testUser);
        var invoiceApi = await CreateApiClient(testUser);

        var request = new UpdateInvoiceRequest(
            CustomerId: invoiceResult.CustomerId,
            Date: invoiceResult.Date,
            DueDate: invoiceResult.DueDate,
            Time: "14:30",
            Items: new List<UpdateInvoiceLineRequest>
            {
                new(
                    Id: null,
                    ProductId: product.Id,
                    Quantity: 1,
                    Price: 200.00m,
                    Discount: 0m
                )
            }
        );

        var response = await invoiceApi.UpdateInvoice(invoiceResult.Id, request);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBe(invoiceResult.Id);
        result.TotalAmount.ShouldBe(200.00m);
    }

    [Fact]
    public async Task PUT_status_updates_invoice_status()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var invoiceResult = await setupTest.CreateInvoice(testUser);
        var invoiceApi = await CreateApiClient(testUser);

        var response = await invoiceApi.UpdateStatus(invoiceResult.Id, new UpdateInvoiceStatusRequest(nameof(InvoiceStatus.Sent)));

        response.StatusCode.ShouldBe(HttpStatusCode.OK);

        var updatedInvoice = await invoiceApi.GetInvoiceById(invoiceResult.Id);
        updatedInvoice.StatusCode.ShouldBe(HttpStatusCode.OK);

        var savedInvoice = await invoiceApi.GetInvoiceById(invoiceResult.Id);
        savedInvoice.StatusCode.ShouldBe(HttpStatusCode.OK);
        savedInvoice.Content!.Status.ShouldBe(nameof(InvoiceStatus.Sent));
    }

    [Fact]
    public async Task GET_by_id_returns_forbidden_when_invoice_belongs_to_different_user()
    {
        var user1 = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var user2 = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        // Create invoice for user1
        var setupTest = SetupTest.Using(Factory);
        var invoiceResult = await setupTest.CreateInvoice(user1);

        // User2 tries to access user1's invoice
        var invoiceApi2 = await CreateApiClient(user2);
        var response = await invoiceApi2.GetInvoiceById(invoiceResult.Id);

        response.StatusCode.ShouldBe(HttpStatusCode.Forbidden);
    }

    [Fact]
    public async Task POST_does_not_create_invoice_when_there_is_not_enough_product_in_stock()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var setupTest = SetupTest.Using(Factory);
        var invoiceApi = await CreateApiClient(testUser);

        var client = setupTest.CreateAuthorizedClient(testUser);
        var productApi = RestService.For<IProductApi>(client);
        var productRequest = new CreateProductRequest(
            Name: "Limited Stock Product",
            DefaultPrice: 100.00m,
            Type: ProductType.Product,
            UnitOfMeasure: "Unit",
            StockQuantity: 5,
            TrackInventory: true
        );
        var productResponse = await productApi.CreateProduct(productRequest);
        productResponse.IsSuccessful.ShouldBeTrue();
        var product = productResponse.Content!;

        var customer = await setupTest.CreateCustomer(testUser);

        // Try to create an invoice requesting more quantity than available in stock
        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnly.FromDateTime(DateTime.Today),
            DueDate: DateOnly.FromDateTime(DateTime.Today.AddDays(30)),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new CreateInvoiceLineRequest(
                    ProductId: product.Id,
                    Quantity: 10,
                    Price: 100.00m,
                    Discount: 0m
                )
            }
        );

        var response = await invoiceApi.CreateInvoice(request);

        response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
        response.Error.ShouldNotBeNull();
        var error = response.Error.Content!;
        error.ShouldContain("Insufficient stock");
        error.ShouldContain("Limited Stock Product");
        error.ShouldContain("Available: 5");
        error.ShouldContain("Requested: 10");
    }

    private async Task<IInvoiceApi> CreateApiClient(TestUser? testUser = null)
    {
        var setupTest = SetupTest.Using(Factory);
        HttpClient client;
        if (testUser == null)
        {
            client = await setupTest.CreateAuthorizedClient();
        }
        else
        {
            client = setupTest.CreateAuthorizedClient(testUser);
        }
        return RestService.For<IInvoiceApi>(client);
    }
}
