using InvadePay.Common.Responses;
using InvadePay.Invoicing.Core.Features.Invoices.Create;
using InvadePay.Invoicing.Core.Features.Invoices.GetById;
using InvadePay.Invoicing.Core.Features.Invoices.GetList;
using InvadePay.Invoicing.Core.Features.Invoices.NextInvoiceNumber;
using InvadePay.Invoicing.Core.Features.Invoices.SendEmail;
using InvadePay.Invoicing.Core.Features.Invoices.Update;
using InvadePay.Invoicing.Core.Features.Invoices.UpdateStatus;
using Refit;

namespace InvadePay.ApiTests.Invoices;

public interface IInvoiceApi
{
    [Post("/api/invoices")]
    Task<IApiResponse<CreateInvoiceResponse>> CreateInvoice([Body] CreateInvoiceRequest request);

    [Get("/api/invoices")]
    Task<IApiResponse<PagedResponse<InvoiceResponse>>> GetInvoices(int? page = null, int? pageSize = null, string? search = null);

    [Get("/api/invoices/{id}")]
    Task<IApiResponse<SingleInvoiceResponse>> GetInvoiceById(long id);
    
    [Get("/api/invoices/next-number")]
    Task<IApiResponse<NextInvoiceNumberResponse>> GetNextInvoiceNumber();

    [Put("/api/invoices/{id}")]
    Task<IApiResponse<UpdateInvoiceResponse>> UpdateInvoice(long id, [Body] UpdateInvoiceRequest request);

    [Put("/api/invoices/{id}/status")]
    Task<IApiResponse<bool>> UpdateStatus(long id, [Body] UpdateInvoiceStatusRequest request);

    [Post("/api/invoices/{id}/send-email")]
    Task<IApiResponse<SendInvoiceEmailResponse>> SendInvoiceEmail(long id);
}
