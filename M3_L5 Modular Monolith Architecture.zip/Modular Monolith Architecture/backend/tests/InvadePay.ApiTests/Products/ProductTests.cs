﻿using System.Net;
using InvadePay.ApiTests.Invoices;
using InvadePay.ApiTests.TestSetup;
using InvadePay.ApiTests.TestSetup.Defaults;
using InvadePay.ApiTests.Users;
using InvadePay.Inventory.Features.Create;
using InvadePay.Inventory.Features.Update;
using InvadePay.Inventory.Models;
using Refit;
using Shouldly;

namespace InvadePay.ApiTests.Products;

public class ProductTests(IntegrationTestWebAppFactory factory) : BaseIntegrationTest(factory)
{
    [Fact]
    public async Task POST_creates_new_product()
    {
        var productApi = await CreateApiClient();

        var request = new CreateProductRequest(
            "Laptop",
            1500.00m,
            ProductType.Product,
            "Unit",
            10,
            true
        );

        var response = await productApi.CreateProduct(request);

        response.StatusCode.ShouldBe(HttpStatusCode.Created);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBeGreaterThan(0);
        result.Name.ShouldBe("Laptop");
        result.DefaultPrice.ShouldBe(1500.00m);
    }

    [Fact]
    public async Task POST_fails_when_name_is_not_provided()
    {
        var setupTest = SetupTest.Using(Factory);
        var client = await setupTest.CreateAuthorizedClient();
        var productApi = RestService.For<IProductApi>(client);

        var request = new CreateProductRequest("", 1500.00m);

        var response = await productApi.CreateProduct(request);

        response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task GET_returns_all_products()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var productResult = await SetupTest
            .Using(Factory)
            .CreateProduct(testUser);

        var productApi = await CreateApiClient(testUser);

        var response = await productApi.GetProducts();

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.TotalCount.ShouldBe(1);
        result.Items.Count().ShouldBe(1);

        var createdProduct = result.Items.First(p => p.Id == productResult.Id);

        createdProduct.Id.ShouldBeGreaterThan(0);
        createdProduct.Name.ShouldBe(DefaultProduct.Name);
        createdProduct.DefaultPrice.ShouldBe(DefaultProduct.Price);
    }

    [Fact]
    public async Task GET_returns_all_products_when_paging_parameters_are_passed()
    {
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var productResult = await SetupTest
            .Using(Factory)
            .CreateProduct(testUser);

        var productApi = await CreateApiClient(testUser);

        var response = await productApi.GetProductsWithPaging();

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.TotalCount.ShouldBe(1);
        result.Items.Count().ShouldBe(1);

        var createdProduct = result.Items.First(p => p.Id == productResult.Id);
        createdProduct.Id.ShouldBeGreaterThan(0);
        createdProduct.Name.ShouldBe(DefaultProduct.Name);
        createdProduct.DefaultPrice.ShouldBe(DefaultProduct.Price);
    }

    [Fact]
    public async Task PUT_updates_product()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var productResult = await setupTest
            .CreateProduct(testUser);

        var client = setupTest.CreateAuthorizedClient(testUser);
        var productApi = RestService.For<IProductApi>(client);

        var request = new UpdateProductRequest(
            Name: "Updated Product",
            DefaultPrice: 1200.00m);

        var response = await productApi.UpdateProduct(productResult.Id, request);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBe(productResult.Id);
        result.Name.ShouldBe("Updated Product");
        result.DefaultPrice.ShouldBe(1200.00m);
    }

    [Fact]
    public async Task PUT_fails_when_product_does_not_exist()
    {
        var setupTest = SetupTest.Using(Factory);

        var client = await setupTest.CreateAuthorizedClient();
        var productApi = RestService.For<IProductApi>(client);

        var request = new UpdateProductRequest(
            Name: "Updated Product",
            DefaultPrice: 1200.00m);

        var response = await productApi.UpdateProduct(9999, request);

        response.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task PUT_fails_when_name_is_empty()
    {
        var setupTest = SetupTest.Using(Factory);

        var productResult = await setupTest.CreateProduct();

        var client = await setupTest.CreateAuthorizedClient();
        var productApi = RestService.For<IProductApi>(client);

        var request = new UpdateProductRequest(
            Name: "",
            DefaultPrice: 1200.00m);

        var response = await productApi.UpdateProduct(productResult.Id, request);

        response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task DELETE_removes_product()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var productResult = await setupTest.CreateProduct(testUser);

        var client = setupTest.CreateAuthorizedClient(testUser);
        var productApi = RestService.For<IProductApi>(client);

        var response = await productApi.DeleteProduct(productResult.Id);

        response.StatusCode.ShouldBe(HttpStatusCode.NoContent);

        var verifyResponse = await productApi.GetProductById(productResult.Id);
        verifyResponse.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task GET_by_id_returns_product()
    {
        var setupTest = SetupTest
            .Using(Factory);

        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var productResult = await setupTest
            .CreateProduct(testUser);

        var client = setupTest
            .CreateAuthorizedClient(testUser);

        var productApi = RestService.For<IProductApi>(client);

        var response = await productApi.GetProductById(productResult.Id);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBe(productResult.Id);
        result.Name.ShouldBe(DefaultProduct.Name);
        result.DefaultPrice.ShouldBe(DefaultProduct.Price);
    }

    [Fact]
    public async Task DELETE_fails_when_product_is_not_found()
    {
        var setupTest = SetupTest.Using(Factory);
        var client = await setupTest.CreateAuthorizedClient();
        var productApi = RestService.For<IProductApi>(client);

        var nonExistentProductId = 999L;

        var response = await productApi.DeleteProduct(nonExistentProductId);

        response.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task DELETE_fails_when_product_is_used_in_invoices()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        // Create an invoice which will create a product and use it
        var createdInvoice = await setupTest.CreateInvoice(testUser);

        var client = setupTest.CreateAuthorizedClient(testUser);
        var invoiceApi = RestService.For<IInvoiceApi>(client);
        var productApi = RestService.For<IProductApi>(client);

        // Get the invoice with items to access the product ID
        var invoiceResponse = await invoiceApi.GetInvoiceById(createdInvoice.Id);
        invoiceResponse.IsSuccessful.ShouldBeTrue();
        var invoice = invoiceResponse.Content!;

        // Try to delete the product that's used in the invoice
        var productId = invoice.Items.First().ProductId;
        var response = await productApi.DeleteProduct(productId);

        response.StatusCode.ShouldBe(HttpStatusCode.Conflict);

        // Verify product still exists
        var verifyResponse = await productApi.GetProductById(productId);
        verifyResponse.StatusCode.ShouldBe(HttpStatusCode.OK);
    }

    [Fact]
    public async Task DELETE_succeeds_when_product_exists_and_is_not_used_in_invoices()
    {
        var setupTest = SetupTest.Using(Factory);
        var testUser = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        // Create an invoice with a different product to establish that invoices exist in the system
        await setupTest.CreateInvoice(testUser);

        // Create a separate product not referenced by any invoice
        var productResult = await setupTest.CreateProduct(testUser);

        var client = setupTest.CreateAuthorizedClient(testUser);
        var productApi = RestService.For<IProductApi>(client);

        var response = await productApi.DeleteProduct(productResult.Id);

        response.StatusCode.ShouldBe(HttpStatusCode.NoContent);

        // Verify product has been deleted
        var verifyResponse = await productApi.GetProductById(productResult.Id);
        verifyResponse.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }

    private async Task<IProductApi> CreateApiClient(TestUser? testUser = null)
    {
        var setupTest = SetupTest.Using(Factory);
        HttpClient client;
        if (testUser != null)
        {
            client = setupTest.CreateAuthorizedClient(testUser);
        }
        else
        {
            client = await setupTest.CreateAuthorizedClient();
        }

        return RestService.For<IProductApi>(client);
    }
}
