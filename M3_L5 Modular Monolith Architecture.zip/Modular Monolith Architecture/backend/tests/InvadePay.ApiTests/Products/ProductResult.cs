﻿namespace InvadePay.ApiTests.Products;

internal class ProductResult
{
    public long Id { get; set; }
}