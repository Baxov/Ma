﻿using InvadePay.Common.Responses;
using InvadePay.Inventory.Features.Create;
using InvadePay.Inventory.Features.GetList;
using InvadePay.Inventory.Features.Update;
using Refit;

namespace InvadePay.ApiTests.Products;

public interface IProductApi
{
    [Post("/api/products")]
    Task<IApiResponse<CreateProductResponse>> CreateProduct([Body] CreateProductRequest request);

    [Get("/api/products")]
    Task<IApiResponse<PagedResponse<ProductResponse>>> GetProducts();

    [Get("/api/products?page=1&pageSize=10")]
    Task<IApiResponse<PagedResponse<ProductResponse>>> GetProductsWithPaging();

    [Get("/api/products/{id}")]
    Task<IApiResponse<ProductResponse>> GetProductById(long id);

    [Put("/api/products/{id}")]
    Task<IApiResponse<UpdateProductResponse>> UpdateProduct(long id, [Body] UpdateProductRequest request);

    [Delete("/api/products/{id}")]
    Task<IApiResponse> DeleteProduct(long id);
}