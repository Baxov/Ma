﻿using System.Net;
using InvadePay.ApiTests.TestSetup;
using InvadePay.ApiTests.Users;
using InvadePay.Invoicing.Core.Features.CompanySettings.Update;
using Refit;
using Shouldly;

namespace InvadePay.ApiTests.CompanySettings;

public class CompanySettingsTests(IntegrationTestWebAppFactory factory) : BaseIntegrationTest(factory)
{
    private async Task<ICompanySettingsApi> CreateApiClient(TestUser? testUser = null)
    {
        var client = testUser != null 
            ? SetupTest.Using(Factory).CreateAuthorizedClient(testUser)
            : await SetupTest.Using(Factory).CreateAuthorizedClient();
        
        return RestService.For<ICompanySettingsApi>(client);
    }

    [Fact]
    public async Task PUT_creates_new_company_settings()
    {
        var companySettingsApi = await CreateApiClient();
        
        var request = new UpdateCompanySettingsRequest(
            CompanyName: "Test Company Ltd",
            Address: "123 Test Street, Test City, TC 12345",
            Email: "contact@testcompany.com"
        );

        var response = await companySettingsApi.UpdateCompanySettings(request);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBeGreaterThan(0);
        result.CompanyName.ShouldBe("Test Company Ltd");
        result.Address.ShouldBe("123 Test Street, Test City, TC 12345");
        result.Email.ShouldBe("contact@testcompany.com");
    }

    [Fact]
    public async Task PUT_updates_existing_company_settings()
    {
        var companySettingsApi = await CreateApiClient();

        var createRequest = new UpdateCompanySettingsRequest(
            CompanyName: "Initial Company",
            Address: "Initial Address",
            Email: "initial@company.com"
        );
        await companySettingsApi.UpdateCompanySettings(createRequest);

        var updateRequest = new UpdateCompanySettingsRequest(
            CompanyName: "Updated Company Ltd",
            Address: "456 Updated Street, Updated City, UC 67890",
            Email: "updated@company.com"
        );

        var response = await companySettingsApi.UpdateCompanySettings(updateRequest);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.CompanyName.ShouldBe("Updated Company Ltd");
        result.Address.ShouldBe("456 Updated Street, Updated City, UC 67890");
        result.Email.ShouldBe("updated@company.com");
    }

    [Fact]
    public async Task GET_returns_company_settings()
    {
        var companySettingsApi = await CreateApiClient();
        
        // Create company settings first
        var createRequest = new UpdateCompanySettingsRequest(
            CompanyName: "Test Company",
            Address: "Test Address",
            Email: "test@company.com"
        );
        var createResponse = await companySettingsApi.UpdateCompanySettings(createRequest);

        var response = await companySettingsApi.GetCompanySettings();

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        var result = response.Content;
        result.ShouldNotBeNull();
        result.Id.ShouldBe(createResponse.Content!.Id);
        result.CompanyName.ShouldBe("Test Company");
        result.Address.ShouldBe("Test Address");
        result.Email.ShouldBe("test@company.com");
    }

    [Fact]
    public async Task GET_returns_not_found_when_no_company_settings_exist()
    {
        var companySettingsApi = await CreateApiClient();

        var response = await companySettingsApi.GetCompanySettings();

        response.StatusCode.ShouldBe(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task PUT_with_empty_company_name_fails()
    {
        var companySettingsApi = await CreateApiClient();
        
        var request = new UpdateCompanySettingsRequest(
            CompanyName: "",
            Address: "Test Address",
            Email: "test@company.com"
        );

        var response = await companySettingsApi.UpdateCompanySettings(request);

        response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task Company_settings_are_isolated_between_users()
    {
        var testUser1 = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();
        
        var testUser2 = await UserBuilder.New()
            .WithClient(Factory.CreateClient())
            .Register();

        var companySettingsApi1 = await CreateApiClient(testUser1);
        var companySettingsApi2 = await CreateApiClient(testUser2);
        
        // Create company settings for user 1
        var request1 = new UpdateCompanySettingsRequest(
            CompanyName: "User 1 Company",
            Address: "User 1 Address",
            Email: "user1@company.com"
        );
        await companySettingsApi1.UpdateCompanySettings(request1);

        // Create company settings for user 2
        var request2 = new UpdateCompanySettingsRequest(
            CompanyName: "User 2 Company",
            Address: "User 2 Address",
            Email: "user2@company.com"
        );
        await companySettingsApi2.UpdateCompanySettings(request2);

        // Verify user 1 can only see their settings
        var response1 = await companySettingsApi1.GetCompanySettings();
        response1.StatusCode.ShouldBe(HttpStatusCode.OK);
        response1.Content!.CompanyName.ShouldBe("User 1 Company");

        // Verify user 2 can only see their settings
        var response2 = await companySettingsApi2.GetCompanySettings();
        response2.StatusCode.ShouldBe(HttpStatusCode.OK);
        response2.Content!.CompanyName.ShouldBe("User 2 Company");
    }
}
