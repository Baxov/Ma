﻿using InvadePay.Invoicing.Core.Features.CompanySettings.Get;
using InvadePay.Invoicing.Core.Features.CompanySettings.Update;
using Refit;

namespace InvadePay.ApiTests.CompanySettings;

public interface ICompanySettingsApi
{
    [Get("/api/company-settings")]
    Task<IApiResponse<CompanySettingsResponse>> GetCompanySettings();

    [Put("/api/company-settings")]
    Task<IApiResponse<UpdateCompanySettingsResponse>> UpdateCompanySettings([Body] UpdateCompanySettingsRequest request);
}
