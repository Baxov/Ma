﻿using InvadePay.Core.Features.CompanySettings.Update;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared;
using InvadePay.UnitTests.TestSetup;
using Shouldly;

namespace InvadePay.UnitTests.CompanySettings;

public class UpdateCompanySettingsUseCaseTests
{
    private static UpdateCompanySettingsUseCase CreateUseCase(IDbContext dbContext)
    {
        return new UpdateCompanySettingsUseCase(dbContext);
    }

    [Fact]
    public async Task New_company_settings_are_created_when_none_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new UpdateCompanySettingsRequest(
            CompanyName: "Test Company Ltd",
            Address: "123 Test Street, Test City, TC 12345",
            Email: "contact@testcompany.com"
        );

        var result = await useCase.Execute(request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Id.ShouldBeGreaterThan(0);
        result.Value.CompanyName.ShouldBe("Test Company Ltd");
        result.Value.Address.ShouldBe("123 Test Street, Test City, TC 12345");
        result.Value.Email.ShouldBe("contact@testcompany.com");
    }

    [Fact]
    public async Task Existing_company_settings_are_updated()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();
        
        var initialSettings = Company.Create(
            "Initial Company",
            "Initial Address",
            "initial@company.com",
            appUser.Id
        ).Value;
        dbContext.Set<Company>().Add(initialSettings);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new UpdateCompanySettingsRequest(
            CompanyName: "Updated Company Ltd",
            Address: "456 Updated Street, Updated City, UC 67890",
            Email: "updated@company.com"
        );

        var result = await useCase.Execute(request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Id.ShouldBe(initialSettings.Id);
        result.Value.CompanyName.ShouldBe("Updated Company Ltd");
        result.Value.Address.ShouldBe("456 Updated Street, Updated City, UC 67890");
        result.Value.Email.ShouldBe("updated@company.com");
    }
    
    [Fact]
    public async Task Fails_when_company_name_is_empty()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new UpdateCompanySettingsRequest(
            CompanyName: "",
            Address: "Test Address",
            Email: "test@company.com"
        );

        var result = await useCase.Execute(request, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldContain("Company name is required");
    }
}
