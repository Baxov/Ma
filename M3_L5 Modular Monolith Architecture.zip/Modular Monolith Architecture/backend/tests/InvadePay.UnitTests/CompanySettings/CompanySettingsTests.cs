﻿using InvadePay.Core.Models.Users;
using Shouldly;

namespace InvadePay.UnitTests.CompanySettings;

public class CompanySettingsTests
{
    [Fact]
    public void Company_settings_are_created_with_valid_parameters()
    {
        var companyName = "Test Company Ltd";
        var address = "123 Test Street, Test City, TC 12345";
        var email = "contact@testcompany.com";
        var appUserId = "test-user-id";

        var result = Company.Create(companyName, address, email, appUserId);

        result.IsSuccess.ShouldBeTrue();
        result.Value.CompanyName.ShouldBe(companyName);
        result.Value.Address.ShouldBe(address);
        result.Value.Email.ShouldBe(email);
        result.Value.AppUserId.ShouldBe(appUserId);
    }

    [Fact]
    public void Company_settings_are_created_with_null_optional_fields()
    {
        var companyName = "Test Company Ltd";
        var appUserId = "test-user-id";

        var result = Company.Create(companyName, null, null, appUserId);

        result.IsSuccess.ShouldBeTrue();
        result.Value.CompanyName.ShouldBe(companyName);
        result.Value.Address.ShouldBeNull();
        result.Value.Email.ShouldBeNull();
        result.Value.AppUserId.ShouldBe(appUserId);
    }

    [Theory]
    [InlineData("")]
    [InlineData(" ")]
    [InlineData(null)]
    public void Create_fails_when_company_name_is_null_or_empty(string? companyName)
    {
        var result = Company.Create(companyName!, "Address", "email@test.com", "user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Company name is required and must not exceed maximum length.");
    }

    [Fact]
    public void Create_fails_when_company_name_exceeds_max_length()
    {
        var longCompanyName = new string('A', Company.MaxLengths.CompanyName + 1);

        var result = Company.Create(longCompanyName, "Address", "email@test.com", "user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Company name is required and must not exceed maximum length.");
    }

    [Fact]
    public void Create_fails_when_address_exceeds_max_length()
    {
        var longAddress = new string('A', Company.MaxLengths.Address + 1);

        var result = Company.Create("Company", longAddress, "email@test.com", "user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Address must not exceed maximum length.");
    }
    
    [Theory]
    [InlineData("invalid-email")]
    [InlineData("@test.com")]
    [InlineData("test@")]
    [InlineData("test.com")]
    public void Create_fails_when_email_is_invalid(string invalidEmail)
    {
        var result = Company.Create("Company", "Address", invalidEmail, "user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Email must be valid and not exceed maximum length.");
    }

    [Theory]
    [InlineData("")]
    [InlineData(" ")]
    [InlineData(null)]
    public void Create_fails_when_app_user_id_is_null_or_empty(string? appUserId)
    {
        var result = Company.Create("Company", "Address", "email@test.com", appUserId!);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("AppUserId is required.");
    }

    [Fact]
    public void Company_settings_can_be_updated()
    {
        var companySettings = Company.Create("Original Company", "Original Address", "original@test.com", "user-id").Value;

        var result = companySettings.Update("Updated Company", "Updated Address", "updated@test.com");

        result.IsSuccess.ShouldBeTrue();
        companySettings.CompanyName.ShouldBe("Updated Company");
        companySettings.Address.ShouldBe("Updated Address");
        companySettings.Email.ShouldBe("updated@test.com");
    }

    [Fact]
    public void Company_settings_can_be_updated_with_null_optional_fields()
    {
        var companySettings = Company.Create("Original Company", "Original Address", "original@test.com", "user-id").Value;

        var result = companySettings.Update("Updated Company", null, null);

        result.IsSuccess.ShouldBeTrue();
        companySettings.CompanyName.ShouldBe("Updated Company");
        companySettings.Address.ShouldBeNull();
        companySettings.Email.ShouldBeNull();
    }

    [Theory]
    [InlineData("")]
    [InlineData(" ")]
    [InlineData(null)]
    public void Company_settings_update_fails_when_company_name_is_null_or_empty(string? companyName)
    {
        var companySettings = Company.Create("Original Company", "Original Address", "original@test.com", "user-id").Value;

        var result = companySettings.Update(companyName!, "Address", "email@test.com");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Company name is required and must not exceed maximum length.");
        companySettings.CompanyName.ShouldBe("Original Company"); // Should remain unchanged
    }

    [Fact]
    public void Company_settings_update_fails_when_email_is_invalid()
    {
        var companySettings = Company.Create("Original Company", "Original Address", "original@test.com", "user-id").Value;

        var result = companySettings.Update("Updated Company", "Address", "invalid-email");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Email must be valid and not exceed maximum length.");
        companySettings.Email.ShouldBe("original@test.com"); // Should remain unchanged
    }
}
