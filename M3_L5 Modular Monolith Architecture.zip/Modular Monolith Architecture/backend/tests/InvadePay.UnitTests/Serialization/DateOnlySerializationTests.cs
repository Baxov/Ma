﻿using System.Text.Json;
using InvadePay.Api.Configuration;
using Shouldly;

namespace InvadePay.UnitTests.Serialization;

public class DateOnlySerializationTests
{
    private readonly JsonSerializerOptions _options;

    public DateOnlySerializationTests()
    {
        _options = new JsonSerializerOptions();
        _options.Converters.Add(new DateOnlyJsonConverter());
        _options.Converters.Add(new NullableDateOnlyJsonConverter());
    }

    [Fact]
    public void DateOnly_serializes_to_yyyy_mm_dd_format()
    {
        var date = new DateOnly(2025, 1, 15);

        var json = JsonSerializer.Serialize(date, _options);

        json.ShouldBe("\"2025-01-15\"");
    }

    [Fact]
    public void DateOnly_deserializes_from_yyyy_mm_dd_format()
    {
        var json = "\"2025-01-15\"";

        var date = JsonSerializer.Deserialize<DateOnly>(json, _options);

        date.ShouldBe(new DateOnly(2025, 1, 15));
    }

    [Fact]
    public void DateOnly_deserializes_from_iso_datetime_string()
    {
        var json = "\"2025-01-15T10:30:00.000Z\"";

        var date = JsonSerializer.Deserialize<DateOnly>(json, _options);

        date.ShouldBe(new DateOnly(2025, 1, 15));
    }

    [Fact]
    public void Nullable_date_only_serializes_null_value()
    {
        DateOnly? date = null;

        var json = JsonSerializer.Serialize(date, _options);

        json.ShouldBe("null");
    }

    [Fact]
    public void Nullable_date_only_serializes_non_null_value()
    {
        DateOnly? date = new DateOnly(2025, 1, 15);

        var json = JsonSerializer.Serialize(date, _options);

        json.ShouldBe("\"2025-01-15\"");
    }

    [Fact]
    public void Nullable_date_only_deserializes_null_value()
    {
        var json = "null";

        var date = JsonSerializer.Deserialize<DateOnly?>(json, _options);

        date.ShouldBeNull();
    }

    [Fact]
    public void Nullable_date_only_deserializes_non_null_value()
    {
        var json = "\"2025-01-15\"";

        var date = JsonSerializer.Deserialize<DateOnly?>(json, _options);

        date.ShouldBe(new DateOnly(2025, 1, 15));
    }
}
