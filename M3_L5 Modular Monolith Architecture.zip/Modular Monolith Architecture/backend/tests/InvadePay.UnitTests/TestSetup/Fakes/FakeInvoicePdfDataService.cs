﻿using InvadePay.Core.Features.Invoices.GeneratePdf;
using InvadePay.Core.Features.Invoices.GetById;

namespace InvadePay.UnitTests.TestSetup.Fakes;

public class FakeInvoicePdfDataService : IInvoicePdfDataService
{
    public bool ShouldReturnNull { get; set; } = false;

    public Task<InvoicePdfData?> GetInvoicePdfData(long invoiceId, string userId)
    {
        if (ShouldReturnNull)
        {
            return Task.FromResult<InvoicePdfData?>(null);
        }

        var pdfData = new InvoicePdfData(
            invoiceId,
            "1-1-1",
            "Test Customer",
            "customer@test.com",
            DateTime.Today,
            "Draft",
            100.0m,
            0.0m,
            100.0m,
            new List<InvoiceItemResponse>
            {
                new InvoiceItemResponse(1, 1, "Test Product", 1, 100.0m, 0, 100.0m)
            });

        return Task.FromResult<InvoicePdfData?>(pdfData);
    }
}