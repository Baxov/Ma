﻿using InvadePay.Core.Models.Shared;
using InvadePay.Core.Shared;

namespace InvadePay.UnitTests.TestSetup.Fakes;

public class FakeEmailSender : IEmailSender
{
    public bool ShouldFail { get; set; } = false;
    public List<(string CustomerEmail, string CustomerName, string InvoiceNumber, byte[] PdfAttachment)> SentInvoiceEmails { get; } = new();
    public List<(string Email, string Name, string InvoiceNumber, DateTime DueDate)> SentReminders { get; } = new();

    public Task SendWelcomeEmail(string email) => Task.CompletedTask;

    public Task<Result> SendPasswordResetEmail(string email, string resetToken) => Task.FromResult(Result.Success());

    public Task<Result> SendInvoiceEmail(string customerEmail, string customerName, string invoiceNumber, byte[] pdfAttachment)
    {
        if (ShouldFail)
        {
            return Task.FromResult<Result>(Result.Error("Email sending failed"));
        }

        SentInvoiceEmails.Add((customerEmail, customerName, invoiceNumber, pdfAttachment));
        return Task.FromResult(Result.Success());
    }

    public Task<Result> SendInvoiceDueDateReminderEmail(string customerEmail, string customerName, string invoiceNumber, DateTime dueDate)
    {
        SentReminders.Add((customerEmail, customerName, invoiceNumber, dueDate));
        return Task.FromResult(Result.Success());
    }
}