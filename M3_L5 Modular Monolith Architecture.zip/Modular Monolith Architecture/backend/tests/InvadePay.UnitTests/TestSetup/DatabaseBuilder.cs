﻿using InvadePay.Core.Shared;
using InvadePay.Infrastructure.Database;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.UnitTests.TestSetup;

public class DatabaseBuilder: IDisposable
{
    private readonly SqliteConnection _connection;
    private readonly AppDbContext _context;

    public DatabaseBuilder()
    {
        _connection = new SqliteConnection("DataSource=:memory:");
        _connection.Open();
    
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseSqlite(_connection)
            .Options;
    
        _context = new AppDbContext(options);
        _context.Database.EnsureCreated();
    }

    public IDbContext CreateDbContext()
    {
        // Reset database state
        _context.Database.EnsureDeleted();
        _context.Database.EnsureCreated();
        
        return _context;
    }
    
    public void Dispose()
    {
        _context.Dispose();
        _connection.Dispose();
    }
}