﻿using InvadePay.Core.Features.RecurringInvoices.Update;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using InvadePay.UnitTests.TestSetup.Fakes;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.UnitTests.RecurringInvoices;

public class UpdateRecurringInvoiceUseCaseTests
{
    private static UpdateRecurringInvoiceUseCase CreateUseCase(IDbContext dbContext, FakeRecurringInvoiceJobService? jobService = null)
    {
        return new UpdateRecurringInvoiceUseCase(dbContext, jobService ?? new FakeRecurringInvoiceJobService());
    }

    [Fact]
    public async Task Recurring_invoice_is_updated_successfully_when_all_parameters_are_valid()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();
        
        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .WithFrequency(RecurringFrequency.Monthly)
            .WithStartDate(DateOnlyCreator.Today().AddDays(1))
            .WithEndDate(DateOnlyCreator.Today().AddDays(30))
            .WithIsActive(true)
            .Build();
        
        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var newStartDate = DateOnlyCreator.Today().AddDays(5);
        var newEndDate = DateOnlyCreator.Today().AddDays(60);
        
        var request = new UpdateRecurringInvoiceRequest(
            "Weekly",
            newStartDate,
            newEndDate,
            false);

        var result = await useCase.Execute(recurringInvoice.Id, request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Id.ShouldBe(recurringInvoice.Id);
        result.Value.Frequency.ShouldBe("Weekly");
        result.Value.StartDate.ShouldBe(newStartDate);
        result.Value.EndDate.ShouldBe(newEndDate);
        result.Value.IsActive.ShouldBeFalse();
        result.Value.NextRunDate.ShouldBe(newStartDate);
    }

    [Fact]
    public async Task Updating_recurring_invoice_fails_when_it_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new UpdateRecurringInvoiceRequest(
            "Weekly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            true);

        var result = await useCase.Execute(999L, request, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Updating_recurring_invoice_fails_when_it_belongs_to_different_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser1 = new AppUser("user1@example.com", "User", "One");
        var appUser2 = new AppUser("user2@example.com", "User", "Two");
        dbContext.Set<AppUser>().AddRange(appUser1, appUser2);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser1.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser1.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();
        
        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser1.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .Build();
        
        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new UpdateRecurringInvoiceRequest(
            "Weekly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            true);

        var result = await useCase.Execute(recurringInvoice.Id, request, appUser2.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Updating_recurring_invoice_fails_when_frequency_is_invalid()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();
        
        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .Build();
        
        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new UpdateRecurringInvoiceRequest(
            "invalidFrequency",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            true);

        var result = await useCase.Execute(recurringInvoice.Id, request, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.UnprocessableEntity);
        result.ErrorMessage.ShouldContain("Invalid frequency");
    }

    [Fact]
    public async Task Updating_recurring_invoice_can_change_frequency_to_different_values()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();
        
        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .WithFrequency(RecurringFrequency.Monthly)
            .Build();
        
        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        
        var quarterlyRequest = new UpdateRecurringInvoiceRequest(
            "Quarterly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(90),
            true);

        var quarterlyResult = await useCase.Execute(recurringInvoice.Id, quarterlyRequest, appUser.Id);
        quarterlyResult.IsSuccess.ShouldBeTrue();
        quarterlyResult.Value.Frequency.ShouldBe("Quarterly");
    }

    [Fact]
    public async Task Updating_recurring_invoice_can_remove_end_date()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();
        
        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .WithEndDate(DateOnlyCreator.Today().AddDays(30))
            .Build();
        
        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new UpdateRecurringInvoiceRequest(
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            null,
            true);

        var result = await useCase.Execute(recurringInvoice.Id, request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.EndDate.ShouldBeNull();
        
        var updatedInvoice = await dbContext.Set<RecurringInvoice>()
            .FirstAsync(ri => ri.Id == recurringInvoice.Id);
        updatedInvoice.EndDate.ShouldBeNull();
    }

    [Fact]
    public async Task Updating_recurring_invoice_can_toggle_active_status()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();
        
        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .WithIsActive(true)
            .Build();
        
        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        
        var deactivateRequest = new UpdateRecurringInvoiceRequest(
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            false);

        var deactivateResult = await useCase.Execute(recurringInvoice.Id, deactivateRequest, appUser.Id);
        deactivateResult.IsSuccess.ShouldBeTrue();
        deactivateResult.Value.IsActive.ShouldBeFalse();
    }

    [Fact]
    public async Task Should_reschedule_job_when_updating_active_recurring_invoice()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .WithFrequency(RecurringFrequency.Monthly)
            .WithStartDate(DateOnlyCreator.Today().AddDays(1))
            .WithEndDate(DateOnlyCreator.Today().AddDays(30))
            .WithIsActive(true)
            .WithHangfireJobId("old-job-123")
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var newStartDate = DateOnlyCreator.Today().AddDays(5);
        var newEndDate = DateOnlyCreator.Today().AddDays(60);

        var request = new UpdateRecurringInvoiceRequest(
            "Weekly",
            newStartDate,
            newEndDate,
            true);

        var result = await useCase.Execute(recurringInvoice.Id, request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();

        // Should unschedule the old job
        jobService.UnscheduledHangfireJobIds.ShouldContain("old-job-123");

        // Should schedule a new job
        jobService.ScheduledRecurringInvoiceIds.ShouldContain(recurringInvoice.Id);
    }

    [Fact]
    public async Task Should_unschedule_job_when_deactivating_recurring_invoice()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .WithFrequency(RecurringFrequency.Monthly)
            .WithStartDate(DateOnlyCreator.Today().AddDays(1))
            .WithEndDate(DateOnlyCreator.Today().AddDays(30))
            .WithIsActive(true)
            .WithHangfireJobId("active-job-456")
            .Build();

        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);

        var request = new UpdateRecurringInvoiceRequest(
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            false); // Deactivating

        var result = await useCase.Execute(recurringInvoice.Id, request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.IsActive.ShouldBeFalse();

        // Should unschedule the job
        jobService.UnscheduledHangfireJobIds.ShouldContain("active-job-456");

        // Should not schedule a new job since it's deactivated
        jobService.ScheduledRecurringInvoiceIds.ShouldNotContain(recurringInvoice.Id);
    }
}
