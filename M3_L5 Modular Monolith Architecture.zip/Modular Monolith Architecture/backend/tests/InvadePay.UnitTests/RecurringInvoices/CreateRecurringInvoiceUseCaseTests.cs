﻿using InvadePay.Core.Features.RecurringInvoices.Create;
using InvadePay.Core.Features.RecurringInvoices.Shared;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using InvadePay.UnitTests.TestSetup.Fakes;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.UnitTests.RecurringInvoices;

public class CreateRecurringInvoiceUseCaseTests
{
    private static CreateRecurringInvoiceUseCase CreateUseCase(IDbContext dbContext, IRecurringInvoiceJobService jobService)
    {
        return new CreateRecurringInvoiceUseCase(dbContext, jobService, new InvoiceValidator(dbContext));
    }

    [Fact]
    public async Task Recurring_invoice_is_created_successfully_when_all_parameters_are_valid()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = RecurringInvoiceTestBuilder.Create()
            .WithCustomer(customer)
            .WithItem(product, 2.0m, 50.0m, 10.0m)
            .BuildCreateRequest();

        var result = await useCase.Execute(request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Id.ShouldBeGreaterThan(0);
        result.Value.CustomerName.ShouldBe("Test Customer");
        result.Value.CustomerEmail.ShouldBe("customer@test.com");
        result.Value.Frequency.ShouldBe("Monthly");
        result.Value.IsActive.ShouldBeTrue();
        result.Value.NextRunDate.ShouldNotBeNull();
        
        jobService.ScheduledRecurringInvoiceIds.ShouldContain(result.Value.Id);
        
        var savedRecurringInvoice = await dbContext.Set<RecurringInvoice>()
            .Include(ri => ri.Items)
            .FirstAsync(ri => ri.Id == result.Value.Id);
        
        savedRecurringInvoice.Items.Count.ShouldBe(1);
        savedRecurringInvoice.Items.First().Quantity.ShouldBe(2.0m);
        savedRecurringInvoice.Items.First().Price.ShouldBe(50.0m);
        savedRecurringInvoice.Items.First().Discount.ShouldBe(10.0m);
    }

    [Fact]
    public async Task Creating_recurring_invoice_fails_when_customer_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            999L,
            "17:00",
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            []);

        var result = await useCase.Execute(request, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
        result.ErrorMessage.ShouldBe("Customer with id 999 was not found.");
        
        jobService.ScheduledRecurringInvoiceIds.ShouldBeEmpty();
    }

    [Fact]
    public async Task Creating_recurring_invoice_fails_when_customer_belongs_to_different_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();
        
        var appUser1 = new AppUser("user1@example.com", "User", "One");
        var appUser2 = new AppUser("user2@example.com", "User", "Two");
        dbContext.Set<AppUser>().AddRange(appUser1, appUser2);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser1.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            customer.Id,
            "17:00",
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            []);

        var result = await useCase.Execute(request, appUser2.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Creating_recurring_invoice_fails_when_frequency_is_invalid()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            customer.Id,
            "17:00",
            "invalidFrequency",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            []);

        var result = await useCase.Execute(request, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.UnprocessableEntity);
        result.ErrorMessage.ShouldContain("Invalid frequency");
    }

    [Fact]
    public async Task Creating_recurring_invoice_fails_when_product_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            customer.Id,
            "17:00",
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            [
                new(999L, 1.0m, 100.0m)
            ]);

        var result = await useCase.Execute(request, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
        result.ErrorMessage.ShouldContain("Products with ids 999 were not found");
    }

    [Fact]
    public async Task Creating_recurring_invoice_fails_when_tax_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            customer.Id,
            "17:00",
            "Monthly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            [
                new(product.Id, 1.0m, 100.0m)
            ],
            999L);

        var result = await useCase.Execute(request, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
        result.ErrorMessage.ShouldContain("Tax");
    }

    [Fact]
    public async Task Creating_recurring_invoice_with_multiple_items_succeeds()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product1 = new Product
        {
            Name = "Product 1",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        var product2 = new Product
        {
            Name = "Product 2",
            DefaultPrice = 200.0m,
            AppUserId = appUser.Id
        };
        
        dbContext.Set<Product>().AddRange(product1, product2);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            customer.Id,
            "17:00",
            "Weekly",
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            [
                new(product1.Id, 2.0m, 100.0m, 5.0m),
                new(product2.Id, 1.0m, 200.0m, null)
            ]);

        var result = await useCase.Execute(request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        
        var savedRecurringInvoice = await dbContext.Set<RecurringInvoice>()
            .Include(ri => ri.Items)
            .FirstAsync(ri => ri.Id == result.Value.Id);
        
        savedRecurringInvoice.Items.Count.ShouldBe(2);
        savedRecurringInvoice.Frequency.ShouldBe(RecurringFrequency.Weekly);
        
        jobService.ScheduledRecurringInvoiceIds.ShouldContain(result.Value.Id);
    }
    
    
    [Theory]
    [InlineData("Weekly")]
    [InlineData("Monthly")]
    [InlineData("Quarterly")]
    [InlineData("Yearly")]
    public async Task Create_recurring_invoice_supports_all_frequency_types(string frequency)
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var jobService = new FakeRecurringInvoiceJobService();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext, jobService);
        var request = new CreateRecurringInvoiceRequest(
            customer.Id,
            "17:00",
            frequency,
            DateOnlyCreator.Today().AddDays(1),
            DateOnlyCreator.Today().AddDays(30),
            [
                new(product.Id, 1.0m, 100.0m)
            ]);

        var result = await useCase.Execute(request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Frequency.ShouldBe(frequency);
    }
}
