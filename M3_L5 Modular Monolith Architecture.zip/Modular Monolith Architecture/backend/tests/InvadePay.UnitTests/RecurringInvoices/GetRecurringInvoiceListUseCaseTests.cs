﻿using InvadePay.Core.Features.RecurringInvoices.GetList;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using Shouldly;

namespace InvadePay.UnitTests.RecurringInvoices;

public class GetRecurringInvoiceListUseCaseTests
{
    private static GetRecurringInvoiceListUseCase CreateUseCase(IDbContext dbContext)
    {
        return new GetRecurringInvoiceListUseCase(dbContext);
    }

    [Fact]
    public async Task Recurring_invoice_list_is_retrieved_successfully_when_user_has_recurring_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();
        
        var recurringInvoice1 = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .WithFrequency(RecurringFrequency.Monthly)
            .Build();
        
        var recurringInvoice2 = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .WithFrequency(RecurringFrequency.Weekly)
            .Build();
        
        dbContext.Set<RecurringInvoice>().AddRange(recurringInvoice1, recurringInvoice2);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(1, 10, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Items.Count.ShouldBe(2);
        result.Value.TotalCount.ShouldBe(2);
        result.Value.Page.ShouldBe(1);
        result.Value.PageSize.ShouldBe(10);
        
        var firstInvoice = result.Value.Items.First();
        firstInvoice.CustomerName.ShouldBe("Test Customer");
        firstInvoice.CustomerEmail.ShouldBe("customer@test.com");
        firstInvoice.IsActive.ShouldBeTrue();
    }

    [Fact]
    public async Task Recurring_invoice_list_returns_empty_when_user_has_no_recurring_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(1, 10, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Items.ShouldBeEmpty();
        result.Value.TotalCount.ShouldBe(0);
        result.Value.Page.ShouldBe(1);
        result.Value.PageSize.ShouldBe(10);
    }

    [Fact]
    public async Task Recurring_invoice_list_only_returns_invoices_for_current_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser1 = new AppUser("user1@example.com", "User", "One");
        var appUser2 = new AppUser("user2@example.com", "User", "Two");
        dbContext.Set<AppUser>().AddRange(appUser1, appUser2);
        
        var customer1Result = Customer.Create("Customer 1", "customer1@test.com", appUser1.Id);
        var customer1 = customer1Result.Value;
        var customer2Result = Customer.Create("Customer 2", "customer2@test.com", appUser2.Id);
        var customer2 = customer2Result.Value;
        dbContext.Set<Customer>().AddRange(customer1, customer2);
        
        var product1 = new Product
        {
            Name = "Product 1",
            DefaultPrice = 100.0m,
            AppUserId = appUser1.Id
        };
        var product2 = new Product
        {
            Name = "Product 2",
            DefaultPrice = 200.0m,
            AppUserId = appUser2.Id
        };
        dbContext.Set<Product>().AddRange(product1, product2);
        await dbContext.SaveChangesAsync();
        
        var recurringInvoice1 = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser1.Id)
            .WithCustomer(customer1)
            .WithItem(product1)
            .Build();
        
        var recurringInvoice2 = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser2.Id)
            .WithCustomer(customer2)
            .WithItem(product2)
            .Build();
        
        dbContext.Set<RecurringInvoice>().AddRange(recurringInvoice1, recurringInvoice2);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(1, 10, appUser1.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Items.Count.ShouldBe(1);
        result.Value.Items.First().CustomerName.ShouldBe("Customer 1");
    }

    [Fact]
    public async Task Recurring_invoice_list_supports_pagination()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();
        
        var recurringInvoices = new List<RecurringInvoice>();
        for (int i = 0; i < 5; i++)
        {
            var recurringInvoice = RecurringInvoiceTestBuilder.Create()
                .WithAppUserId(appUser.Id)
                .WithCustomer(customer)
                .WithItem(product)
                .Build();
            recurringInvoices.Add(recurringInvoice);
        }
        
        dbContext.Set<RecurringInvoice>().AddRange(recurringInvoices);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        
        var firstPageResult = await useCase.Execute(1, 2, appUser.Id);
        firstPageResult.IsSuccess.ShouldBeTrue();
        firstPageResult.Value.Items.Count.ShouldBe(2);
        firstPageResult.Value.TotalCount.ShouldBe(5);
        firstPageResult.Value.Page.ShouldBe(1);
        firstPageResult.Value.PageSize.ShouldBe(2);
        
        var secondPageResult = await useCase.Execute(2, 2, appUser.Id);
        secondPageResult.IsSuccess.ShouldBeTrue();
        secondPageResult.Value.Items.Count.ShouldBe(2);
        secondPageResult.Value.TotalCount.ShouldBe(5);
        secondPageResult.Value.Page.ShouldBe(2);
        secondPageResult.Value.PageSize.ShouldBe(2);
        
        var thirdPageResult = await useCase.Execute(3, 2, appUser.Id);
        thirdPageResult.IsSuccess.ShouldBeTrue();
        thirdPageResult.Value.Items.Count.ShouldBe(1);
        thirdPageResult.Value.TotalCount.ShouldBe(5);
        thirdPageResult.Value.Page.ShouldBe(3);
        thirdPageResult.Value.PageSize.ShouldBe(2);
    }

    [Fact]
    public async Task Recurring_invoice_list_shows_correct_frequency_and_dates()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();
        
        var startDate = DateOnlyCreator.Today().AddDays(5);
        var endDate = DateOnlyCreator.Today().AddDays(35);
        
        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .WithFrequency(RecurringFrequency.Quarterly)
            .WithStartDate(startDate)
            .WithEndDate(endDate)
            .Build();
        
        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(1, 10, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        var invoice = result.Value.Items.First();
        invoice.Frequency.ShouldBe("Quarterly");
        invoice.StartDate.ShouldBe(startDate);
        invoice.EndDate.ShouldBe(endDate);
        invoice.NextRunDate.ShouldBe(startDate);
    }
}
