﻿using InvadePay.Core.Features.RecurringInvoices.GetById;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared;
using InvadePay.UnitTests.TestSetup;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.UnitTests.RecurringInvoices;

public class GetRecurringInvoiceByIdUseCaseTests
{
    private static GetRecurringInvoiceByIdUseCase CreateUseCase(IDbContext dbContext)
    {
        return new GetRecurringInvoiceByIdUseCase(dbContext);
    }

    [Fact]
    public async Task Recurring_invoice_is_retrieved_successfully_when_it_exists()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();
        
        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product, 2.0m, 50.0m, 10.0m)
            .WithFrequency(RecurringFrequency.Weekly)
            .WithTime("09:30")
            .Build();
        
        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(recurringInvoice.Id, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Id.ShouldBe(recurringInvoice.Id);
        result.Value.CustomerName.ShouldBe("Test Customer");
        result.Value.CustomerEmail.ShouldBe("customer@test.com");
        result.Value.Time.ShouldBe("09:30");
        result.Value.Frequency.ShouldBe("Weekly");
        result.Value.IsActive.ShouldBeTrue();
        result.Value.Items.Count.ShouldBe(1);
        
        var item = result.Value.Items.First();
        item.ProductName.ShouldBe("Test Product");
        item.Quantity.ShouldBe(2.0m);
        item.Price.ShouldBe(50.0m);
        item.Discount.ShouldBe(10.0m);
        item.Total.ShouldBe(90.0m);
    }

    [Fact]
    public async Task Recurring_invoice_is_retrieved_with_tax_information_when_tax_is_assigned()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        
        var taxResult = Tax.Create("VAT", "Value Added Tax", 20.0m, appUser.Id);
        var tax = taxResult.Value;
        dbContext.Set<Tax>().Add(tax);
        
        await dbContext.SaveChangesAsync();
        
        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .WithTaxId(tax.Id)
            .Build();
        
        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(recurringInvoice.Id, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.TaxId.ShouldBe(tax.Id);
        result.Value.TaxName.ShouldBe("VAT");
        result.Value.TaxRate.ShouldBe(20.0m);
    }

    [Fact]
    public async Task Getting_recurring_invoice_fails_when_it_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(999L, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Getting_recurring_invoice_fails_when_it_belongs_to_different_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser1 = new AppUser("user1@example.com", "User", "One");
        var appUser2 = new AppUser("user2@example.com", "User", "Two");
        dbContext.Set<AppUser>().AddRange(appUser1, appUser2);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser1.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser1.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();
        
        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser1.Id)
            .WithCustomer(customer)
            .WithItem(product)
            .Build();
        
        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(recurringInvoice.Id, appUser2.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Recurring_invoice_with_multiple_items_is_retrieved_correctly()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        
        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);
        
        var product1 = new Product
        {
            Name = "Product 1",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        var product2 = new Product
        {
            Name = "Product 2",
            DefaultPrice = 200.0m,
            AppUserId = appUser.Id
        };
        
        dbContext.Set<Product>().AddRange(product1, product2);
        await dbContext.SaveChangesAsync();
        
        var recurringInvoice = RecurringInvoiceTestBuilder.Create()
            .WithAppUserId(appUser.Id)
            .WithCustomer(customer)
            .WithItem(product1, 2.0m, 100.0m, 5.0m)
            .WithItem(product2, 1.0m, 200.0m, null)
            .Build();
        
        dbContext.Set<RecurringInvoice>().Add(recurringInvoice);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var result = await useCase.Execute(recurringInvoice.Id, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Items.Count.ShouldBe(2);
        
        var item1 = result.Value.Items.First(i => i.ProductName == "Product 1");
        item1.Quantity.ShouldBe(2.0m);
        item1.Price.ShouldBe(100.0m);
        item1.Discount.ShouldBe(5.0m);
        item1.Total.ShouldBe(190.0m);
        
        var item2 = result.Value.Items.First(i => i.ProductName == "Product 2");
        item2.Quantity.ShouldBe(1.0m);
        item2.Price.ShouldBe(200.0m);
        item2.Discount.ShouldBeNull();
        item2.Total.ShouldBe(200.0m);
    }
}
