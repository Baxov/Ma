﻿using InvadePay.Core.Features.Taxes.Create;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared;
using InvadePay.UnitTests.TestSetup;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.UnitTests.Taxes;

public class CreateTaxUseCaseTests
{
    [Fact]
    public async Task Tax_is_created_successfully_when_all_parameters_are_valid()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new CreateTaxRequest("VAT", "Value Added Tax", 20.0m);

        var result = await useCase.Execute(request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Id.ShouldBeGreaterThan(0);
        result.Value.Name.ShouldBe("VAT");
        result.Value.Description.ShouldBe("Value Added Tax");
        result.Value.Rate.ShouldBe(20.0m);
        
        var savedTax = await dbContext.Set<Tax>().FirstOrDefaultAsync(x => x.Id == result.Value.Id);
        savedTax.ShouldNotBeNull();
        savedTax!.Name.ShouldBe("VAT");
        savedTax.Description.ShouldBe("Value Added Tax");
        savedTax.Rate.ShouldBe(20.0m);
        savedTax.AppUserId.ShouldBe(appUser.Id);
    }
    
    [Fact]
    public async Task Creating_tax_fails_when_name_is_empty()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new CreateTaxRequest("", "Description", 20.0m);

        var result = await useCase.Execute(request, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Tax name is required and must not exceed maximum length.");
        
        var taxCount = await dbContext.Set<Tax>().CountAsync();
        taxCount.ShouldBe(0);
    }
    
    private static CreateTaxUseCase CreateUseCase(IDbContext dbContext)
    {
        return new CreateTaxUseCase(dbContext);
    }
}
