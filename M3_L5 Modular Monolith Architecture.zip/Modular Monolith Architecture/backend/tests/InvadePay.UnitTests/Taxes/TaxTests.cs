﻿using InvadePay.Core.Models.Invoices;
using Shouldly;

namespace InvadePay.UnitTests.Taxes;

public class TaxTests
{
    [Fact]
    public void Tax_is_created_when_all_parameters_are_valid()
    {
        var name = "VAT";
        var description = "Value Added Tax";
        var rate = 20.0m;
        var appUserId = "test-user-id";

        var result = Tax.Create(name, description, rate, appUserId);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Name.ShouldBe(name);
        result.Value.Description.ShouldBe(description);
        result.Value.Rate.ShouldBe(rate);
        result.Value.AppUserId.ShouldBe(appUserId);
    }

    [Fact]
    public void Tax_is_created_when_description_is_null()
    {
        var name = "VAT";
        var rate = 20.0m;
        var appUserId = "test-user-id";

        var result = Tax.Create(name, null, rate, appUserId);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Name.ShouldBe(name);
        result.Value.Description.ShouldBeNull();
        result.Value.Rate.ShouldBe(rate);
        result.Value.AppUserId.ShouldBe(appUserId);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void Tax_creation_fails_when_name_is_empty(string invalidName)
    {
        var description = "Test tax";
        var rate = 20.0m;
        var appUserId = "test-user-id";

        var result = Tax.Create(invalidName, description, rate, appUserId);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Tax name is required and must not exceed maximum length.");
    }

    [Fact]
    public void Tax_creation_fails_when_name_exceeds_max_length()
    {
        var name = new string('A', Tax.MaxLengths.Name + 1);
        var description = "Test tax";
        var rate = 20.0m;
        var appUserId = "test-user-id";

        var result = Tax.Create(name, description, rate, appUserId);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Tax name is required and must not exceed maximum length.");
    }

    [Fact]
    public void Tax_is_created_when_name_is_at_max_length()
    {
        var name = new string('A', Tax.MaxLengths.Name);
        var description = "Test tax";
        var rate = 20.0m;
        var appUserId = "test-user-id";

        var result = Tax.Create(name, description, rate, appUserId);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Name.ShouldBe(name);
    }

    [Fact]
    public void Tax_creation_fails_when_description_exceeds_max_length()
    {
        var name = "VAT";
        var description = new string('A', Tax.MaxLengths.Description + 1);
        var rate = 20.0m;
        var appUserId = "test-user-id";

        var result = Tax.Create(name, description, rate, appUserId);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Tax description must not exceed maximum length.");
    }

    [Fact]
    public void Tax_is_created_when_description_is_at_max_length()
    {
        var name = "VAT";
        var description = new string('A', Tax.MaxLengths.Description);
        var rate = 20.0m;
        var appUserId = "test-user-id";

        var result = Tax.Create(name, description, rate, appUserId);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Description.ShouldBe(description);
    }

    [Theory]
    [InlineData(-0.01)]
    [InlineData(-1)]
    [InlineData(-100)]
    [InlineData(100.01)]
    [InlineData(101)]
    [InlineData(200)]
    public void Tax_creation_fails_when_rate_is_outside_valid_range(decimal invalidRate)
    {
        var name = "VAT";
        var description = "Test tax";
        var appUserId = "test-user-id";

        var result = Tax.Create(name, description, invalidRate, appUserId);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Tax rate must be between 0 and 100 percent.");
    }

    [Theory]
    [InlineData(0)]
    [InlineData(0.01)]
    [InlineData(5.5)]
    [InlineData(20)]
    [InlineData(99.99)]
    [InlineData(100)]
    public void Tax_is_created_when_rate_is_within_valid_range(decimal validRate)
    {
        var name = "VAT";
        var description = "Test tax";
        var appUserId = "test-user-id";

        var result = Tax.Create(name, description, validRate, appUserId);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Rate.ShouldBe(validRate);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void Tax_creation_fails_when_app_user_id_is_empty(string invalidAppUserId)
    {
        var name = "VAT";
        var description = "Test tax";
        var rate = 20.0m;

        var result = Tax.Create(name, description, rate, invalidAppUserId);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("AppUserId is required.");
    }

    [Fact]
    public void New_instance_is_returned_each_time_tax_is_created()
    {
        var name = "VAT";
        var description = "Test tax";
        var rate = 20.0m;
        var appUserId = "test-user-id";

        var result1 = Tax.Create(name, description, rate, appUserId);
        var result2 = Tax.Create(name, description, rate, appUserId);

        result1.IsSuccess.ShouldBeTrue();
        result2.IsSuccess.ShouldBeTrue();
        result1.Value.ShouldNotBeSameAs(result2.Value);
    }
    
        [Fact]
    public void Tax_is_updated_when_all_parameters_are_valid()
    {
        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, "test-user-id").Value;
        var newName = "GST";
        var newDescription = "Goods and Services Tax";
        var newRate = 15.0m;

        var result = tax.Update(newName, newDescription, newRate);

        result.IsSuccess.ShouldBeTrue();
        tax.Name.ShouldBe(newName);
        tax.Description.ShouldBe(newDescription);
        tax.Rate.ShouldBe(newRate);
    }

    [Fact]
    public void Tax_is_updated_when_description_is_null()
    {
        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, "test-user-id").Value;
        var newName = "GST";
        var newRate = 15.0m;

        var result = tax.Update(newName, null, newRate);

        result.IsSuccess.ShouldBeTrue();
        tax.Name.ShouldBe(newName);
        tax.Description.ShouldBeNull();
        tax.Rate.ShouldBe(newRate);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void Tax_update_fails_when_name_is_empty(string invalidName)
    {
        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, "test-user-id").Value;
        var originalName = tax.Name;

        var result = tax.Update(invalidName, "Updated description", 15.0m);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Tax name is required and must not exceed maximum length.");
        tax.Name.ShouldBe(originalName); // Should not change
    }

    [Fact]
    public void Tax_update_fails_when_name_exceeds_max_length()
    {
        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, "test-user-id").Value;
        var originalName = tax.Name;
        var invalidName = new string('A', Tax.MaxLengths.Name + 1);

        var result = tax.Update(invalidName, "Updated description", 15.0m);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Tax name is required and must not exceed maximum length.");
        tax.Name.ShouldBe(originalName); // Should not change
    }

    [Fact]
    public void Tax_is_updated_when_name_is_at_max_length()
    {
        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, "test-user-id").Value;
        var newName = new string('A', Tax.MaxLengths.Name);

        var result = tax.Update(newName, "Updated description", 15.0m);

        result.IsSuccess.ShouldBeTrue();
        tax.Name.ShouldBe(newName);
    }

    [Fact]
    public void Tax_update_fails_when_description_exceeds_max_length()
    {
        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, "test-user-id").Value;
        var originalDescription = tax.Description;
        var invalidDescription = new string('A', Tax.MaxLengths.Description + 1);

        var result = tax.Update("Updated VAT", invalidDescription, 15.0m);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Tax description must not exceed maximum length.");
        tax.Description.ShouldBe(originalDescription); // Should not change
    }

    [Fact]
    public void Tax_is_updated_when_description_is_at_max_length()
    {
        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, "test-user-id").Value;
        var newDescription = new string('A', Tax.MaxLengths.Description);

        var result = tax.Update("Updated VAT", newDescription, 15.0m);

        result.IsSuccess.ShouldBeTrue();
        tax.Description.ShouldBe(newDescription);
    }

    [Theory]
    [InlineData(-0.01)]
    [InlineData(-1)]
    [InlineData(-100)]
    [InlineData(100.01)]
    [InlineData(101)]
    [InlineData(200)]
    public void Tax_update_fails_when_rate_is_outside_valid_range(decimal invalidRate)
    {
        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, "test-user-id").Value;
        var originalRate = tax.Rate;

        var result = tax.Update("Updated VAT", "Updated description", invalidRate);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Tax rate must be between 0 and 100 percent.");
        tax.Rate.ShouldBe(originalRate); // Should not change
    }

    [Theory]
    [InlineData(0)]
    [InlineData(0.01)]
    [InlineData(5.5)]
    [InlineData(20)]
    [InlineData(99.99)]
    [InlineData(100)]
    public void Tax_is_updated_when_rate_is_within_valid_range(decimal validRate)
    {
        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, "test-user-id").Value;

        var result = tax.Update("Updated VAT", "Updated description", validRate);

        result.IsSuccess.ShouldBeTrue();
        tax.Rate.ShouldBe(validRate);
    }
}
