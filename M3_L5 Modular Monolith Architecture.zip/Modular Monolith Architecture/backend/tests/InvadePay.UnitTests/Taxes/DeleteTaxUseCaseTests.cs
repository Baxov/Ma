﻿using InvadePay.Core.Features.Taxes.Delete;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.UnitTests.Taxes;

public class DeleteTaxUseCaseTests
{
    private static DeleteTaxUseCase CreateUseCase(IDbContext dbContext)
    {
        return new DeleteTaxUseCase(dbContext);
    }

    [Fact]
    public async Task Tax_deletion_fails_when_tax_is_not_found()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var nonExistentTaxId = 999L;

        var result = await useCase.Execute(nonExistentTaxId, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
        result.ErrorMessage.ShouldBe("Tax with id 999 was not found.");
    }

    [Fact]
    public async Task Tax_deletion_fails_when_tax_is_used_in_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        var taxResult = Tax.Create("VAT", "Value Added Tax", 20.0m, appUser.Id);
        var tax = taxResult.Value;
        dbContext.Set<Tax>().Add(tax);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems,
            tax.Id).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(tax.Id, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.Conflict);
        result.ErrorMessage.ShouldBe("Tax cannot be deleted because it is used in invoices.");

        // Verify tax still exists
        var taxStillExists = await dbContext.Set<Tax>()
            .FirstOrDefaultAsync(x => x.Id == tax.Id);
        taxStillExists.ShouldNotBeNull();
    }

    [Fact]
    public async Task Tax_can_be_deleted_when_tax_exists_and_is_not_used_in_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var taxResult = Tax.Create("VAT", "Value Added Tax", 20.0m, appUser.Id);
        var tax = taxResult.Value;
        dbContext.Set<Tax>().Add(tax);

        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(tax.Id, appUser.Id);

        result.IsSuccess.ShouldBeTrue();

        // Verify tax has been deleted
        var deletedTax = await dbContext.Set<Tax>()
            .FirstOrDefaultAsync(x => x.Id == tax.Id);
        deletedTax.ShouldBeNull();
    }
}
