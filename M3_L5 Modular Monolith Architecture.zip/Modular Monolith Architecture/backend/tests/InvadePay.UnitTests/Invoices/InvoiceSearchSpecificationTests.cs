using InvadePay.Core.Features.Invoices.GetList;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using Shouldly;

namespace InvadePay.UnitTests.Invoices;

public class InvoiceSearchSpecificationTests
{
    private static Customer CreateTestCustomer()
    {
        var customerResult = Customer.Create("Test Customer", "test@example.com", "test-user-id");
        customerResult.Value.Id = 1;
        return customerResult.Value;
    }

    private static Invoice CreateTestInvoice(long invoiceNumber = 1, string customerName = "Test Customer", string customerEmail = "test@example.com", InvoiceStatus status = InvoiceStatus.Draft, string productName = "Test Product")
    {
        var customer = Customer.Create(customerName, customerEmail, "test-user-id").Value;
        customer.Id = 1;
        var product = new Product
        {
            Id = 1,
            Name = productName,
            DefaultPrice = 100.00m,
            AppUserId = "test-user-id"
        };
        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Product = product,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            invoiceNumber,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems).Value;

        invoice.SetStatusTo(status);
        invoice.Customer = customer;
        return invoice;
    }

    [Fact]
    public void Search_matches_invoice_number()
    {
        var specification = new InvoiceSearchSpecification("123");
        var invoice = CreateTestInvoice(123);

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeTrue();
    }

    [Fact]
    public void Search_matches_customer_name()
    {
        var specification = new InvoiceSearchSpecification("john");
        var invoice = CreateTestInvoice(1, "John Doe", "john@example.com");

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeTrue();
    }

    [Fact]
    public void Search_matches_customer_email()
    {
        var specification = new InvoiceSearchSpecification("example");
        var invoice = CreateTestInvoice(1, "John Doe", "john@example.com");

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeTrue();
    }

    [Fact]
    public void Search_matches_invoice_status()
    {
        var specification = new InvoiceSearchSpecification("se");
        var invoice = CreateTestInvoice(1, "John Doe", "john@example.com", InvoiceStatus.Sent);

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeTrue();
    }

    [Fact]
    public void Search_matches_product_name()
    {
        var specification = new InvoiceSearchSpecification("laptop");
        var invoice = CreateTestInvoice(1, "John Doe", "john@example.com", InvoiceStatus.Draft, "Gaming Laptop");

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeTrue();
    }

    [Fact]
    public void Search_is_case_insensitive()
    {
        var specification = new InvoiceSearchSpecification("MIKE");
        var invoice = CreateTestInvoice(1, "Mike Doe", "mike@example.com");

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeTrue();
    }

    [Fact]
    public void Search_returns_false_when_no_match()
    {
        var specification = new InvoiceSearchSpecification("nonexistent");
        var invoice = CreateTestInvoice(1, "John Doe", "john@example.com");

        var result = specification.IsSatisfiedBy(invoice);

        result.ShouldBeFalse();
    }
}