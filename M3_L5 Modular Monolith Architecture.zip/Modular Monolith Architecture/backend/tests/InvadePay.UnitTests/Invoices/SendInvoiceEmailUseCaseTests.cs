﻿using InvadePay.Core.Features.Invoices.GeneratePdf;
using InvadePay.Core.Features.Invoices.SendEmail;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using InvadePay.UnitTests.TestSetup.Fakes;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.UnitTests.Invoices;

public class SendInvoiceEmailUseCaseTests
{
    private static SendInvoiceEmailUseCase CreateUseCase(
        IDbContext dbContext,
        IInvoicePdfDataService? pdfDataService = null,
        IInvoicePdfGenerator? pdfGenerator = null,
        IEmailSender? emailSender = null)
    {
        return new SendInvoiceEmailUseCase(
            dbContext,
            pdfDataService ?? new FakeInvoicePdfDataService(),
            pdfGenerator ?? new FakeInvoicePdfGenerator(),
            emailSender ?? new FakeEmailSender());
    }

    [Fact]
    public async Task Send_invoice_email_fails_when_invoice_is_not_found()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var nonExistentInvoiceId = 999L;
        var userId = "test-user-id";

        var result = await useCase.Execute(nonExistentInvoiceId, userId);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Send_invoice_email_fails_when_invoice_belongs_to_different_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var appUser1 = new AppUser("user1@example.com", "User", "One");
        var appUser2 = new AppUser("user2@example.com", "User", "Two");
        dbContext.Set<AppUser>().AddRange(appUser1, appUser2);

        var customer = Customer.Create("Test Customer", "customer@test.com", appUser1.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser1.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser1.Id,
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(invoice.Id, appUser2.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Send_invoice_email_fails_when_invoice_is_reversed()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = Customer.Create("Test Customer", "customer@test.com", appUser.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        // Set invoice to Sent first, then to Reversed (valid transition)
        invoice.SetStatusTo(InvoiceStatus.Sent);
        invoice.SetStatusTo(InvoiceStatus.Reversed);

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(invoice.Id, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Cannot send a reversed invoice.");
    }

    [Fact]
    public async Task Send_invoice_email_fails_when_pdf_data_retrieval_fails()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var failingPdfDataService = new FakeInvoicePdfDataService { ShouldReturnNull = true };
        var useCase = CreateUseCase(dbContext, pdfDataService: failingPdfDataService);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = Customer.Create("Test Customer", "customer@test.com", appUser.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(invoice.Id, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Failed to retrieve invoice data for PDF generation.");
    }

    [Fact]
    public async Task Send_invoice_email_fails_when_email_sending_fails()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var failingEmailSender = new FakeEmailSender { ShouldFail = true };
        var useCase = CreateUseCase(dbContext, emailSender: failingEmailSender);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = Customer.Create("Test Customer", "customer@test.com", appUser.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(invoice.Id, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Failed to send email: Email sending failed");
    }

    [Fact]
    public async Task Send_invoice_email_succeeds_and_changes_draft_invoice_status_to_sent()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var emailSender = new FakeEmailSender();
        var useCase = CreateUseCase(dbContext, emailSender: emailSender);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = Customer.Create("Test Customer", "customer@test.com", appUser.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();
        
        invoice.Status.ShouldBe(InvoiceStatus.Draft);

        var result = await useCase.Execute(invoice.Id, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Success.ShouldBeTrue();
        result.Value.Message.ShouldBe($"Invoice {invoice.InvoiceNumber} has been sent successfully to {customer.Email}");
        
        emailSender.SentInvoiceEmails.Count.ShouldBe(1);
        var sentEmail = emailSender.SentInvoiceEmails.First();
        sentEmail.CustomerEmail.ShouldBe(customer.Email);
        sentEmail.CustomerName.ShouldBe(customer.Name);
        sentEmail.InvoiceNumber.ShouldBe(invoice.InvoiceNumber.ToString());
        sentEmail.PdfAttachment.ShouldNotBeNull();
        
        var updatedInvoice = await dbContext.Set<Invoice>()
            .FirstAsync(i => i.Id == invoice.Id);
        updatedInvoice.Status.ShouldBe(InvoiceStatus.Sent);
    }

    [Fact]
    public async Task Send_invoice_email_succeeds_and_does_not_change_sent_invoice_status()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var emailSender = new FakeEmailSender();
        var useCase = CreateUseCase(dbContext, emailSender: emailSender);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = Customer.Create("Test Customer", "customer@test.com", appUser.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;
        
        invoice.SetStatusTo(InvoiceStatus.Sent);

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(invoice.Id, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Success.ShouldBeTrue();
        result.Value.Message.ShouldBe($"Invoice {invoice.InvoiceNumber} has been sent successfully to {customer.Email}");
        
        emailSender.SentInvoiceEmails.Count.ShouldBe(1);
        
        var updatedInvoice = await dbContext.Set<Invoice>()
            .FirstAsync(i => i.Id == invoice.Id);
        updatedInvoice.Status.ShouldBe(InvoiceStatus.Sent);
    }

    [Fact]
    public async Task Send_invoice_email_succeeds_and_does_not_change_paid_invoice_status()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var emailSender = new FakeEmailSender();
        var useCase = CreateUseCase(dbContext, emailSender: emailSender);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = Customer.Create("Test Customer", "customer@test.com", appUser.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;
        
        invoice.SetStatusTo(InvoiceStatus.Paid);

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(invoice.Id, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Success.ShouldBeTrue();
        result.Value.Message.ShouldBe($"Invoice {invoice.InvoiceNumber} has been sent successfully to {customer.Email}");

        emailSender.SentInvoiceEmails.Count.ShouldBe(1);
        
        var updatedInvoice = await dbContext.Set<Invoice>()
            .FirstAsync(i => i.Id == invoice.Id);
        updatedInvoice.Status.ShouldBe(InvoiceStatus.Paid);
    }
}