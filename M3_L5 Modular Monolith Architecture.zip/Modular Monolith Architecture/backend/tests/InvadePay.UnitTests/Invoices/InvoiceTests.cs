﻿using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using Shouldly;

namespace InvadePay.UnitTests.Invoices;

public class InvoiceTests
{
    private static Customer CreateTestCustomer()
    {
        var customerResult = Customer.Create("Test Customer", "test@example.com", "test-user-id");
        customerResult.Value.Id = 1;
        return customerResult.Value;
    }

    private static Invoice CreateTestInvoice(InvoiceStatus status = InvoiceStatus.Draft)
    {
        var customer = CreateTestCustomer();
        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoiceResult = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30), // Due date 30 days from invoice date
            "14:30",
            "test-user-id",
            invoiceItems);

        var invoice = invoiceResult.Value;
        if (status == InvoiceStatus.Reversed)
        {
            invoice.SetStatusTo(InvoiceStatus.Paid);
        }
        invoice.SetStatusTo(status);
        return invoice;
    }

    [Fact]
    public void Status_is_not_changed_when_new_status_is_the_same()
    {
        var invoice = CreateTestInvoice();

        var result = invoice.SetStatusTo(InvoiceStatus.Draft);

        result.IsSuccess.ShouldBeTrue();
        invoice.Status.ShouldBe(InvoiceStatus.Draft);
    }

    [Theory]
    [InlineData(InvoiceStatus.Draft, InvoiceStatus.Reversed)]
    [InlineData(InvoiceStatus.Sent, InvoiceStatus.Draft)]
    [InlineData(InvoiceStatus.Paid, InvoiceStatus.Draft)]
    [InlineData(InvoiceStatus.Paid, InvoiceStatus.Sent)]
    [InlineData(InvoiceStatus.Reversed, InvoiceStatus.Draft)]
    [InlineData(InvoiceStatus.Reversed, InvoiceStatus.Sent)]
    [InlineData(InvoiceStatus.Reversed, InvoiceStatus.Paid)]
    public void Status_change_fails_when_it_is_invalid_status_transition(InvoiceStatus currentStatus, InvoiceStatus newStatus)
    {
        var invoice = CreateTestInvoice(currentStatus);

        var result = invoice.SetStatusTo(newStatus);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe($"Cannot transition from {currentStatus} to {newStatus}.");
        invoice.Status.ShouldBe(currentStatus);
    }

    [Fact]
    public void Status_change_is_changed_to_new_one_for_valid_transition()
    {
        var invoice = CreateTestInvoice();

        var result = invoice.SetStatusTo(InvoiceStatus.Sent);

        result.IsSuccess.ShouldBeTrue();
        invoice.Status.ShouldBe(InvoiceStatus.Sent);
    }

    [Fact]
    public void Invoice_is_created_when_all_parameters_are_valid()
    {
        var customer = CreateTestCustomer();
        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = 1,
                Quantity = 2,
                Price = 50.00m,
                Discount = 10m
            }
        };

        var result = Invoice.Create(
            123,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "15:30",
            "test-user-id",
            invoiceItems,
            456);

        result.IsSuccess.ShouldBeTrue();
        result.Value.InvoiceNumber.ShouldBe(123);
        result.Value.CustomerId.ShouldBe(customer.Id);
        result.Value.Date.ShouldBe(DateOnlyCreator.Today());
        result.Value.Time.ShouldBe("15:30");
        result.Value.AppUserId.ShouldBe("test-user-id");
        result.Value.TaxId.ShouldBe(456);
        result.Value.Items.ShouldBe(invoiceItems);
        result.Value.Status.ShouldBe(InvoiceStatus.Draft);
    }

    [Fact]
    public void Invoice_creation_fails_when_app_user_id_is_empty()
    {
        var customer = CreateTestCustomer();
        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem { ProductId = 1, Quantity = 1, Price = 100.00m }
        };

        var result = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "",
            invoiceItems);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("AppUserId is required.");
    }

    [Fact]
    public void Invoice_creation_fails_when_time_is_empty()
    {
        var customer = CreateTestCustomer();
        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem { ProductId = 1, Quantity = 1, Price = 100.00m }
        };

        var result = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "",
            "test-user-id",
            invoiceItems);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Time is required.");
    }

    [Fact]
    public void Invoice_creation_fails_when_items_are_empty()
    {
        var customer = CreateTestCustomer();
        var invoiceItems = new List<InvoiceItem>();

        var result = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("At least one invoice item is required.");
    }

    [Fact]
    public void Invoice_creation_fails_when_invoice_number_is_zero()
    {
        var customer = CreateTestCustomer();
        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem { ProductId = 1, Quantity = 1, Price = 100.00m }
        };

        var result = Invoice.Create(
            0,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            "test-user-id",
            invoiceItems);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Invoice number must be greater than zero.");
    }
}