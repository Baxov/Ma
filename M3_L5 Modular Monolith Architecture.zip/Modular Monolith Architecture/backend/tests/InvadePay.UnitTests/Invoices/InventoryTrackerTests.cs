﻿using InvadePay.Core.Features.Invoices.Create;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared;
using InvadePay.UnitTests.TestSetup;
using Shouldly;

namespace InvadePay.UnitTests.Invoices;

public class InventoryTrackerTests
{
    private const string TestUserId = "test-user-id";
    private const string OtherUserId = "other-user-id";

    private static async Task SeedUsers(IDbContext dbContext)
    {
        var testUser = new AppUser("test@example.com", "Test", "User")
        {
            Id = TestUserId
        };

        var otherUser = new AppUser("other@example.com", "Other", "User")
        {
            Id = OtherUserId
        };

        dbContext.Set<AppUser>().Add(testUser);
        dbContext.Set<AppUser>().Add(otherUser);
        await dbContext.SaveChangesAsync();
    }

    [Fact]
    public async Task Stock_availability_returns_success_when_no_products_provided()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var tracker = new InventoryTracker(dbContext);

        var productQuantities = new Dictionary<long, decimal>();

        var result = await tracker.ValidateStockAvailability(productQuantities, TestUserId);

        result.IsSuccess.ShouldBeTrue();
    }

    [Fact]
    public async Task Stock_availability_returns_not_found_when_product_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var tracker = new InventoryTracker(dbContext);

        var productQuantities = new Dictionary<long, decimal> { { 999, 5 } };

        var result = await tracker.ValidateStockAvailability(productQuantities, TestUserId);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
        result.ErrorMessage.ShouldContain("Products with IDs 999 were not found");
    }

    [Fact]
    public async Task Stock_availability_returns_not_found_when_product_belongs_to_different_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        await SeedUsers(dbContext);
        var tracker = new InventoryTracker(dbContext);

        // Create product for different user
        var product = CreateTestProduct("Test Product", OtherUserId);
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        var productQuantities = new Dictionary<long, decimal> { { product.Id, 5 } };

        var result = await tracker.ValidateStockAvailability(productQuantities, TestUserId);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
        result.ErrorMessage.ShouldContain($"Products with IDs {product.Id} were not found");
    }

    [Fact]
    public async Task Stock_availability_returns_success_for_service_type_products()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        await SeedUsers(dbContext);
        var tracker = new InventoryTracker(dbContext);

        var product = CreateTestProduct("Test Service", TestUserId, ProductType.Service);
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        var productQuantities = new Dictionary<long, decimal> { { product.Id, 5 } };

        var result = await tracker.ValidateStockAvailability(productQuantities, TestUserId);

        result.IsSuccess.ShouldBeTrue();
    }

    [Fact]
    public async Task Stock_availability_returns_success_for_products_without_inventory_tracking()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        await SeedUsers(dbContext);
        var tracker = new InventoryTracker(dbContext);

        var product = CreateTestProduct("Test Product", TestUserId, trackInventory: false);
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        var productQuantities = new Dictionary<long, decimal> { { product.Id, 5 } };

        var result = await tracker.ValidateStockAvailability(productQuantities, TestUserId);

        result.IsSuccess.ShouldBeTrue();
    }
    
    [Fact]
    public async Task Stock_availability_returns_error_when_insufficient_stock()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        await SeedUsers(dbContext);
        var tracker = new InventoryTracker(dbContext);

        var product = CreateTestProduct("Test Product", TestUserId, trackInventory: true, stockQuantity: 3);
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        var productQuantities = new Dictionary<long, decimal> { { product.Id, 5 } };

        var result = await tracker.ValidateStockAvailability(productQuantities, TestUserId);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldContain("Insufficient stock for product 'Test Product'. Available: 3, Requested: 5");
    }

    [Fact]
    public async Task Stock_availability_returns_success_when_sufficient_stock()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        await SeedUsers(dbContext);
        var tracker = new InventoryTracker(dbContext);

        var product = CreateTestProduct("Test Product", TestUserId, trackInventory: true, stockQuantity: 10);
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        var productQuantities = new Dictionary<long, decimal> { { product.Id, 5 } };

        var result = await tracker.ValidateStockAvailability(productQuantities, TestUserId);

        result.IsSuccess.ShouldBeTrue();
    }

    [Fact]
    public async Task Stock_availability_returns_success_when_exact_stock_available()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        await SeedUsers(dbContext);
        var tracker = new InventoryTracker(dbContext);

        var product = CreateTestProduct("Test Product", TestUserId, trackInventory: true, stockQuantity: 5);
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        var productQuantities = new Dictionary<long, decimal> { { product.Id, 5 } };

        var result = await tracker.ValidateStockAvailability(productQuantities, TestUserId);

        result.IsSuccess.ShouldBeTrue();
    }

    [Fact]
    public async Task Stock_availability_returns_multiple_errors_for_multiple_products()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        await SeedUsers(dbContext);
        var tracker = new InventoryTracker(dbContext);

        var product1 = CreateTestProduct("Product 1", TestUserId, trackInventory: true, stockQuantity: 3);
        var product2 = CreateTestProduct("Product 2", TestUserId, trackInventory: true, stockQuantity: 2);
        dbContext.Set<Product>().AddRange(product1, product2);
        await dbContext.SaveChangesAsync();

        var productQuantities = new Dictionary<long, decimal>
        {
            { product1.Id, 5 },
            { product2.Id, 5 }
        };

        var result = await tracker.ValidateStockAvailability(productQuantities, TestUserId);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldContain("Insufficient stock for product 'Product 1'. Available: 3, Requested: 5");
        result.ErrorMessage.ShouldContain("Insufficient stock for product 'Product 2'. Available: 2, Requested: 5");
    }

    [Fact]
    public async Task Stock_deduction_returns_success_when_no_products_provided()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var tracker = new InventoryTracker(dbContext);

        var productQuantities = new Dictionary<long, decimal>();

        var result = await tracker.DeductStock(productQuantities, TestUserId);

        result.IsSuccess.ShouldBeTrue();
    }

    [Fact]
    public async Task Stock_deduction_returns_error_when_validation_fails()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var tracker = new InventoryTracker(dbContext);

        var productQuantities = new Dictionary<long, decimal> { { 999, 5 } };

        var result = await tracker.DeductStock(productQuantities, TestUserId);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Stock_deduction_reduces_stock_quantity_for_tracked_products()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        await SeedUsers(dbContext);
        var tracker = new InventoryTracker(dbContext);

        var product = CreateTestProduct("Test Product", TestUserId, trackInventory: true, stockQuantity: 10);
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        var productQuantities = new Dictionary<long, decimal> { { product.Id, 3 } };

        var result = await tracker.DeductStock(productQuantities, TestUserId);

        result.IsSuccess.ShouldBeTrue();
        product.StockQuantity.ShouldBe(7);
    }

    [Fact]
    public async Task Stock_deduction_does_not_reduce_stock_for_service_products()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        await SeedUsers(dbContext);
        var tracker = new InventoryTracker(dbContext);

        var product = CreateTestProduct("Test Service", TestUserId, ProductType.Service, stockQuantity: 10);
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        var productQuantities = new Dictionary<long, decimal> { { product.Id, 3 } };

        var result = await tracker.DeductStock(productQuantities, TestUserId);

        result.IsSuccess.ShouldBeTrue();
        product.StockQuantity.ShouldBe(10); // Should remain unchanged
    }

    [Fact]
    public async Task Stock_deduction_does_not_reduce_stock_for_untracked_products()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        await SeedUsers(dbContext);
        var tracker = new InventoryTracker(dbContext);

        var product = CreateTestProduct("Test Product", TestUserId, trackInventory: false, stockQuantity: 10);
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        var productQuantities = new Dictionary<long, decimal> { { product.Id, 3 } };

        var result = await tracker.DeductStock(productQuantities, TestUserId);

        result.IsSuccess.ShouldBeTrue();
        product.StockQuantity.ShouldBe(10); // Should remain unchanged
    }
    
    [Fact]
    public async Task Stock_deduction_handles_multiple_products_correctly()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        await SeedUsers(dbContext);
        var tracker = new InventoryTracker(dbContext);

        var product1 = CreateTestProduct("Product 1", TestUserId, trackInventory: true, stockQuantity: 10);
        var product2 = CreateTestProduct("Product 2", TestUserId, trackInventory: true, stockQuantity: 5);
        var product3 = CreateTestProduct("Service 1", TestUserId, ProductType.Service, stockQuantity: 20);
        dbContext.Set<Product>().AddRange(product1, product2, product3);
        await dbContext.SaveChangesAsync();

        var productQuantities = new Dictionary<long, decimal>
        {
            { product1.Id, 3 },
            { product2.Id, 2 },
            { product3.Id, 1 }
        };

        var result = await tracker.DeductStock(productQuantities, TestUserId);

        result.IsSuccess.ShouldBeTrue();
        product1.StockQuantity.ShouldBe(7);
        product2.StockQuantity.ShouldBe(3);
        product3.StockQuantity.ShouldBe(20);
    }

    private static Product CreateTestProduct(
        string name, 
        string appUserId, 
        ProductType type = ProductType.Product, 
        bool trackInventory = true, 
        decimal? stockQuantity = 10)
    {
        return new Product
        {
            Name = name,
            AppUserId = appUserId,
            Type = type,
            TrackInventory = trackInventory,
            StockQuantity = stockQuantity,
            DefaultPrice = 100m,
            UnitOfMeasure = "Unit"
        };
    }
}
