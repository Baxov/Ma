﻿using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared.Extensions;
using InvadePay.Infrastructure.Emailing;
using InvadePay.UnitTests.TestSetup;
using InvadePay.UnitTests.TestSetup.Fakes;
using Microsoft.Extensions.Logging;
using Shouldly;

namespace InvadePay.UnitTests.Invoices;

public class DueDateReminderHandlerTests
{
    [Fact]
    public async Task Handle_schedules_reminder_email_when_invoice_is_sent_and_due_date_is_after_invoice_date()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var emailSender = new FakeEmailSender();
        var logger = new FakeLogger();

        var backgroundJobScheduler = new FakeBackgroundJobScheduler();
        var handler = new DueDateReminderHandler(dbContext, emailSender, backgroundJobScheduler, logger);
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = Customer.Create("Test Customer", "test@example.com", appUser.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Product = product,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoiceDate = DateOnlyCreator.Today();
        var dueDate = DateOnlyCreator.Today().AddDays(30);

        var invoice = Invoice.Create(
            1,
            customer.Id,
            invoiceDate,
            dueDate,
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var invoiceSentEvent = new InvoiceSentEvent { ParentId = invoice.Id };

        await handler.Handle(invoiceSentEvent);

        var expectedScheduleTime = dueDate.ToDateTime(TimeOnly.Parse("14:30"));
        backgroundJobScheduler.EnqueueAt.ShouldBe(expectedScheduleTime);
    }

    [Fact]
    public async Task Handle_does_not_schedule_reminder_when_invoice_is_sent_but_due_date_is_not_after_invoice_date()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var emailSender = new FakeEmailSender();
        var logger = new FakeLogger();

        var backgroundJobScheduler = new FakeBackgroundJobScheduler();
        var handler = new DueDateReminderHandler(dbContext, emailSender, backgroundJobScheduler, logger);
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = Customer.Create("Test Customer", "test@example.com", appUser.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Product = product,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoiceDate = DateOnlyCreator.Today();
        var dueDate = DateOnlyCreator.Today();

        var invoice = Invoice.Create(
            1,
            customer.Id,
            invoiceDate,
            dueDate,
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var invoiceSentEvent = new InvoiceSentEvent { ParentId = invoice.Id };

        await handler.Handle(invoiceSentEvent);

        backgroundJobScheduler.EnqueueAt.ShouldBe(default(DateTimeOffset));
    }

    [Fact]
    public async Task SendDueDateReminderEmailAsync_does_not_send_email_when_invoice_is_paid()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var emailSender = new FakeEmailSender();
        var logger = new FakeLogger();

        var backgroundJobScheduler = new FakeBackgroundJobScheduler();
        var handler = new DueDateReminderHandler(dbContext, emailSender, backgroundJobScheduler, logger);
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = Customer.Create("Test Customer", "test@example.com", appUser.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Product = product,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        invoice.SetStatusTo(InvoiceStatus.Paid);

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        await handler.SendDueDateReminderEmailAsync(invoice.Id);

        emailSender.SentReminders.ShouldBeEmpty();
    }

    [Fact]
    public async Task SendDueDateReminderEmailAsync_sends_email_when_invoice_is_not_paid()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var emailSender = new FakeEmailSender();
        var logger = new FakeLogger();

        var backgroundJobScheduler = new FakeBackgroundJobScheduler();
        var handler = new DueDateReminderHandler(dbContext, emailSender, backgroundJobScheduler, logger);
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = Customer.Create("Test Customer", "test@example.com", appUser.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Product = product,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        await handler.SendDueDateReminderEmailAsync(invoice.Id);

        emailSender.SentReminders.ShouldHaveSingleItem();
        var sentReminder = emailSender.SentReminders.First();
        sentReminder.Email.ShouldBe("test@example.com");
        sentReminder.Name.ShouldBe("Test Customer");
        sentReminder.InvoiceNumber.ShouldBe("1-1-1");
        sentReminder.DueDate.ShouldBe(invoice.DueDate.ToDateTime(TimeOnly.MinValue));
    }
}

file class FakeLogger : ILogger<DueDateReminderHandler>
{
    public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;
    public bool IsEnabled(LogLevel logLevel) => true;

    public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
    {
    }
}
