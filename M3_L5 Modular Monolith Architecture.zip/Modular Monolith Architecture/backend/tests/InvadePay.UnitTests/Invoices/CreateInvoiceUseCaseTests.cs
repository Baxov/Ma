﻿using InvadePay.Core.Features.Invoices.Create;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.UnitTests.Invoices;

public class CreateInvoiceUseCaseTests
{
    [Fact]
    public async Task Invoice_creation_fails_when_product_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = appUser.Id };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnly.FromDateTime(DateTime.Today),
            DueDate: DateOnly.FromDateTime(DateTime.Today.AddDays(30)),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(
                    ProductId: 9999,
                    Quantity: 1,
                    Price: 100.00m,
                    Discount: 0m
                )
            }
        );

        var result = await useCase.Execute(request, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }
    
    [Fact]
    public async Task Invoice_creation_fails_when_customer_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var product = new Product
        {
            Name = "Phone",
            DefaultPrice = 1000.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var request = new CreateInvoiceRequest(
            CustomerId: 9999, // Non-existent customer
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(
                    ProductId: product.Id,
                    Quantity: 1,
                    Price: 100.00m,
                    Discount: 0m
                )
            }
        );

        var result = await useCase.Execute(request, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
        result.ErrorMessage.ShouldContain("Customer with id 9999 was not found");
    }

    [Fact]
    public async Task Invoice_creation_creates_new_invoice()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = appUser.Id };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var product = new Product
        {
            Name = "Phone",
            DefaultPrice = 1000.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(
                    ProductId: product.Id,
                    Quantity: 1,
                    Price: 100.00m,
                    Discount: 0m
                )
            }
        );

        var result = await useCase.Execute(request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        var invoice = await dbContext.Set<Invoice>().FirstOrDefaultAsync(x => x.Id == result.Value.Id);
        invoice.ShouldNotBeNull();
        invoice!.CustomerId.ShouldBe(customer.Id);
        invoice.Date.ShouldBe(request.Date);
        invoice.Items.Count.ShouldBe(1);
        var firstItem = request.Items.First();
        invoice.Items.First().Price.ShouldBe(firstItem.Price);
        invoice.Items.First().Quantity.ShouldBe(firstItem.Quantity);
        invoice.Items.First().Discount.ShouldBe(firstItem.Discount);
        invoice.Items.First().ProductId.ShouldBe(firstItem.ProductId);
        invoice.AppUserId.ShouldBe(appUser.Id);
        invoice.InvoiceNumber.ShouldBeGreaterThan(0);
        invoice.Status.ShouldBe(InvoiceStatus.Draft);
        invoice.Time.ShouldBe(request.Time);
    }

    [Fact]
    public async Task Invoice_creation_assigns_next_invoice_number()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var product = new Product
        {
            Name = "Phone",
            DefaultPrice = 1000.00m,
            AppUserId = appUser.Id
        };

        dbContext.Set<Customer>().Add(new Customer
        {
            Name = "John Doe",
            Email = "john@example.com",
            AppUserId = appUser.Id
        });

        dbContext.Set<Product>().Add(product);

        var customer = Customer.Create("Test Customer", "test@example.com", appUser.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        // Save customer and product first to get their IDs
        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();
        
        var useCase = CreateUseCase(dbContext);
        
        var request = new CreateInvoiceRequest(
            CustomerId: 1, // Use the customer we created above
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(
                    ProductId: product.Id,
                    Quantity: 1,
                    Price: 100.00m,
                    Discount: 0m
                )
            }
        );
        
        var result = await useCase.Execute(request, appUser.Id);
        
        result.IsSuccess.ShouldBeTrue();
        result.Value.InvoiceId.ShouldBe("2-1-1");
    }

    [Fact]
    public async Task Invoice_creation_supports_multiple_invoice_lines()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = appUser.Id };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var product1 = new Product { Name = "Phone", DefaultPrice = 1000.00m, AppUserId = appUser.Id };
        var product2 = new Product { Name = "Case", DefaultPrice = 50.00m, AppUserId = appUser.Id };
        dbContext.Set<Product>().AddRange(product1, product2);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);

        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(
                    ProductId: product1.Id,
                    Quantity: 2,
                    Price: 1000.00m,
                    Discount: 10.00m
                ),
                new(
                    ProductId: product2.Id,
                    Quantity: 1,
                    Price: 50.00m,
                    Discount: 0m
                )
            }
        );

        var result = await useCase.Execute(request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        var invoice = await dbContext.Set<Invoice>().FirstOrDefaultAsync(x => x.Id == result.Value.Id);
        invoice.ShouldNotBeNull();
        invoice!.Items.Count.ShouldBe(2);
        
        var firstItem = invoice.Items.First(i => i.ProductId == product1.Id);
        firstItem.Quantity.ShouldBe(2);
        firstItem.Price.ShouldBe(1000.00m);
        firstItem.Discount.ShouldBe(10.00m);
        
        var secondItem = invoice.Items.First(i => i.ProductId == product2.Id);
        secondItem.Quantity.ShouldBe(1);
        secondItem.Price.ShouldBe(50.00m);
        secondItem.Discount.ShouldBe(0m);
        
        result.Value.TotalAmount.ShouldBe(1850.00m);
    }

    [Fact]
    public async Task Invoice_creation_calculates_tax_correctly_with_single_item()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = appUser.Id };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var product = new Product
        {
            Name = "Laptop",
            DefaultPrice = 1000.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, appUser.Id).Value;
        dbContext.Set<Tax>().Add(tax);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(ProductId: product.Id, Quantity: 1, Price: 100.00m, Discount: 0m)
            },
            TaxId: tax.Id
        );

        var result = await useCase.Execute(request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.SubtotalAmount.ShouldBe(100.00m);
        result.Value.TaxAmount.ShouldBe(20.00m);
        result.Value.TotalAmount.ShouldBe(120.00m);
        result.Value.TaxId.ShouldBe(tax.Id);
        result.Value.TaxName.ShouldBe("VAT");
        result.Value.TaxRate.ShouldBe(20.0m);
    }

    [Fact]
    public async Task Invoice_creation_calculates_tax_correctly_with_multiple_items()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = appUser.Id };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var product1 = new Product { Name = "Laptop", DefaultPrice = 1000.00m, AppUserId = appUser.Id };
        var product2 = new Product { Name = "Mouse", DefaultPrice = 50.00m, AppUserId = appUser.Id };
        dbContext.Set<Product>().AddRange(product1, product2);

        var tax = Tax.Create("VAT", "Value Added Tax", 10.0m, appUser.Id).Value;
        dbContext.Set<Tax>().Add(tax);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(ProductId: product1.Id, Quantity: 2, Price: 500.00m, Discount: 0m),
                new(ProductId: product2.Id, Quantity: 1, Price: 30.00m, Discount: 0m)
            },
            TaxId: tax.Id
        );

        var result = await useCase.Execute(request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.SubtotalAmount.ShouldBe(1030.00m); 
        result.Value.TaxAmount.ShouldBe(103.00m);
        result.Value.TotalAmount.ShouldBe(1133.00m);
    }

    [Fact]
    public async Task Invoice_creation_calculates_tax_correctly_with_discounts()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = appUser.Id };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var product = new Product
        {
            Name = "Laptop",
            DefaultPrice = 1000.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        var tax = Tax.Create("VAT", "Value Added Tax", 20.0m, appUser.Id).Value;
        dbContext.Set<Tax>().Add(tax);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(ProductId: product.Id, Quantity: 1, Price: 100.00m, Discount: 10.0m)
            },
            TaxId: tax.Id
        );

        var result = await useCase.Execute(request, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        result.Value.SubtotalAmount.ShouldBe(90.00m);
        result.Value.TaxAmount.ShouldBe(18.00m);
        result.Value.TotalAmount.ShouldBe(108.00m);
    }
    
    [Fact]
    public async Task Invoice_creation_fails_when_tax_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = appUser.Id };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var product = new Product
        {
            Name = "Laptop",
            DefaultPrice = 1000.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items: new List<CreateInvoiceLineRequest>
            {
                new(ProductId: product.Id, Quantity: 1, Price: 100.00m, Discount: 0m)
            },
            TaxId: 999 // Non-existent tax ID
        );

        var result = await useCase.Execute(request, appUser.Id);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Tax with id 999 was not found.");
    }

    [Fact]
    public async Task Invoice_creation_fails_when_tax_belongs_to_different_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser1 = new AppUser("user1@example.com", "User", "One");
        var appUser2 = new AppUser("user2@example.com", "User", "Two");
        dbContext.Set<AppUser>().AddRange(appUser1, appUser2);

        var customer = new Customer { Name = "John Doe", Email = "john@example.com", AppUserId = appUser1.Id };
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var product = new Product
        {
            Name = "Laptop",
            DefaultPrice = 1000.00m,
            AppUserId = appUser1.Id
        };
        dbContext.Set<Product>().Add(product);

        var userTwoTax = Tax.Create("VAT", "Value Added Tax", 20.0m, appUser2.Id).Value;
        dbContext.Set<Tax>().Add(userTwoTax);

        await dbContext.SaveChangesAsync();

        var useCase = CreateUseCase(dbContext);
        var request = new CreateInvoiceRequest(
            CustomerId: customer.Id,
            Date: DateOnlyCreator.Today(),
            DueDate: DateOnlyCreator.Today().AddDays(30),
            Time: "14:30",
            Items:
            [
                new(ProductId: product.Id, Quantity: 1, Price: 100.00m, Discount: 0m)
            ],
            TaxId: userTwoTax.Id
        );
        
        var result = await useCase.Execute(request, appUser1.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }
    
    private static CreateInvoiceUseCase CreateUseCase(IDbContext dbContext)
    {
        return new CreateInvoiceUseCase(dbContext, new InventoryTracker(dbContext), new InvoiceValidator(dbContext));
    }
}