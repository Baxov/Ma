using InvadePay.Core.Features.Invoices.UpdateStatus;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using Shouldly;

namespace InvadePay.UnitTests.Invoices;

public class UpdateInvoiceStatusUseCaseTests
{
    [Fact]
    public async Task Update_status_returns_not_found_for_non_existent_invoice()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = new UpdateInvoiceStatusUseCase(dbContext);

        var result = await useCase.Execute(999, "Paid", "test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Update_status_returns_validation_error_for_invalid_status()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = new UpdateInvoiceStatusUseCase(dbContext);

        var result = await useCase.Execute(1, "InvalidStatus", "test-user-id");

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.Error);
        result.ErrorMessage.ShouldBe("Invalid invoice status: InvalidStatus");
    }

    [Theory]
    [InlineData("sent")]
    [InlineData("SENT")]
    [InlineData("Sent")]
    public async Task Update_status_accepts_case_insensitive_status(string status)
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var product = new Product
        {
            Name = "Phone",
            DefaultPrice = 1000.00m,
            AppUserId = appUser.Id
        };

        dbContext.Set<Customer>().Add(new Customer
        {
            Name = "John Doe",
            Email = "john@example.com",
            AppUserId = appUser.Id
        });

        dbContext.Set<Product>().Add(product);

        var customer = Customer.Create("Test Customer", "test@example.com", appUser.Id).Value;
        dbContext.Set<Customer>().Add(customer);

        // Save customer and product first to get their IDs
        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;
        invoice.SetStatusTo(InvoiceStatus.Draft);

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();
        
        var useCase = new UpdateInvoiceStatusUseCase(dbContext);

        var result = await useCase.Execute(1, status, appUser.Id);

        result.IsSuccess.ShouldBeTrue();
        var updatedInvoice = await dbContext.Set<Invoice>().FindAsync(1L);
        updatedInvoice!.Status.ShouldBe(InvoiceStatus.Sent);
    }
}