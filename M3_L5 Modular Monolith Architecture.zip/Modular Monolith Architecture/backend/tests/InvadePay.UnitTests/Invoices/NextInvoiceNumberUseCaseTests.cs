using InvadePay.Core.Features.Invoices.NextInvoiceNumber;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using Shouldly;

namespace InvadePay.UnitTests.Invoices;

public class NextInvoiceNumberUseCaseTests
{
    [Fact]
    public async Task Next_invoice_number_is_one_when_user_does_not_have_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var useCase = new NextInvoiceNumberUseCase(dbContext);
        
        var result = await useCase.Execute("test-user-id");
        
        result.IsSuccess.ShouldBeTrue();
        result.Value.InvoiceNumber.ShouldBe("1-1-1");
    }
    
    [Fact]
    public async Task Next_invoice_number_is_correctly_returned_when_user_has_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var customer = new Customer
        {
            Name = "John Doe",
            Email = "john@example.com",
            AppUserId = appUser.Id
        };
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        // Save customer and product first to get their IDs
        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice1 = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        var invoice2 = Invoice.Create(
            2,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice1);
        dbContext.Set<Invoice>().Add(invoice2);

        await dbContext.SaveChangesAsync();
        
        var useCase = new NextInvoiceNumberUseCase(dbContext);
        
        var result = await useCase.Execute(appUser.Id);
        
        result.IsSuccess.ShouldBeTrue();
        result.Value.InvoiceNumber.ShouldBe("3-1-1");
    }
}