﻿using InvadePay.Core.Features.Products.Delete;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.UnitTests.Products;

public class DeleteProductUseCaseTests
{
    private static DeleteProductUseCase CreateUseCase(IDbContext dbContext)
    {
        return new DeleteProductUseCase(dbContext);
    }

    [Fact]
    public async Task Product_deletion_fails_when_product_is_not_found()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var nonExistentProductId = 999L;

        var result = await useCase.Execute(nonExistentProductId);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Product_deletion_fails_when_product_is_used_in_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id,
            Type = ProductType.Product,
            TrackInventory = false
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(product.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.Conflict);

        // Verify product still exists
        var productStillExists = await dbContext.Set<Product>()
            .FirstOrDefaultAsync(x => x.Id == product.Id);
        productStillExists.ShouldNotBeNull();
    }

    [Fact]
    public async Task Product_can_be_deleted_when_product_exists_and_is_not_used_in_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id,
            Type = ProductType.Product,
            TrackInventory = false
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(product.Id);

        result.IsSuccess.ShouldBeTrue();

        // Verify product has been deleted
        var deletedProduct = await dbContext.Set<Product>()
            .FirstOrDefaultAsync(x => x.Id == product.Id);
        deletedProduct.ShouldBeNull();
    }
}
