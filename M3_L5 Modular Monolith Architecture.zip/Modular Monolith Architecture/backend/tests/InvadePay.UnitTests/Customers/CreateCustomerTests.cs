﻿using InvadePay.Core.Models.Customers;
using Shouldly;

namespace InvadePay.UnitTests.Customers;

public class CreateCustomerTests
{
    [Fact]
    public void Customer_is_created_when_name_and_email_are_valid()
    {
        var name = "John Doe";
        var email = "john.doe@example.com";
        var appUserId = "test-user-id";

        var result = Customer.Create(name, email, appUserId);

        result.IsSuccess.ShouldBeTrue();
        result.Value.Name.ShouldBe(name);
        result.Value.Email.ShouldBe(email);
        result.Value.AppUserId.ShouldBe(appUserId);
    }

    [Fact]
    public void Customer_created_event_is_raised_when_customer_is_created()
    {
        var name = "John Doe";
        var email = "john.doe@example.com";

        var result = Customer.Create(name, email, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.DomainEvents.Count.ShouldBe(1);
        result.Value.DomainEvents.First().ShouldBeOfType<CustomerCreatedEvent>();
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void Customer_creation_fails_when_name_is_empty(string invalidName)
    {
        var email = "john.doe@example.com";

        var result = Customer.Create(invalidName, email, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Invalid customer name.");
    }

    [Fact]
    public void Customer_creation_fails_when_name_exceeds_max_length()
    {
        var name = new string('A', Customer.MaxLengths.Name + 1);
        var email = "john.doe@example.com";

        var result = Customer.Create(name, email, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Invalid customer name.");
    }

    [Fact]
    public void Customer_is_created_when_name_is_at_max_length()
    {
        var name = new string('A', Customer.MaxLengths.Name);
        var email = "john.doe@example.com";

        var result = Customer.Create(name, email, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Name.ShouldBe(name);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void Customer_creation_fails_when_email_is_empty(string invalidEmail)
    {
        var name = "John Doe";

        var result = Customer.Create(name, invalidEmail, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Invalid customer email.");
    }

    [Fact]
    public void Customer_creation_fails_when_email_exceeds_max_length()
    {
        var name = "John Doe";
        var email = new string('a', Customer.MaxLengths.Email) + "@test.com";

        var result = Customer.Create(name, email, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Invalid customer email.");
    }

    [Theory]
    [InlineData("invalid-email")]
    [InlineData("@example.com")]
    [InlineData("user@")]
    [InlineData("user.example.com")]
    public void Customer_creation_fails_when_email_format_is_invalid(string invalidEmail)
    {
        var name = "John Doe";

        var result = Customer.Create(name, invalidEmail, "test-user-id");

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("Invalid customer email.");
    }

    [Theory]
    [InlineData("user@example.com")]
    [InlineData("test.email@domain.co.uk")]
    [InlineData("user+tag@example.org")]
    [InlineData("firstname.lastname@company.com")]
    [InlineData("user123@test123.net")]
    public void Customer_is_created_when_email_format_is_valid(string validEmail)
    {
        var name = "John Doe";

        var result = Customer.Create(name, validEmail, "test-user-id");

        result.IsSuccess.ShouldBeTrue();
        result.Value.Email.ShouldBe(validEmail);
    }

    [Fact]
    public void New_instance_is_returned_each_time_customer_is_created()
    {
        var name = "John Doe";
        var email = "john.doe@example.com";

        var result1 = Customer.Create(name, email, "test-user-id");
        var result2 = Customer.Create(name, email, "test-user-id");

        result1.IsSuccess.ShouldBeTrue();
        result2.IsSuccess.ShouldBeTrue();
        result1.Value.ShouldNotBeSameAs(result2.Value);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void Customer_creation_fails_when_app_user_id_is_empty(string invalidAppUserId)
    {
        var name = "John Doe";
        var email = "john.doe@example.com";

        var result = Customer.Create(name, email, invalidAppUserId);

        result.IsError.ShouldBeTrue();
        result.ErrorMessage.ShouldBe("AppUserId is required.");
    }
}
