﻿using InvadePay.Core.Features.Customers.Delete;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using Microsoft.EntityFrameworkCore;
using Shouldly;

namespace InvadePay.UnitTests.Customers;

public class DeleteCustomerUseCaseTests
{
    private static DeleteCustomerUseCase CreateUseCase(IDbContext dbContext)
    {
        return new DeleteCustomerUseCase(dbContext);
    }

    [Fact]
    public async Task Customer_deletion_fails_when_customer_is_not_found()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var nonExistentCustomerId = 999L;

        var result = await useCase.Execute(nonExistentCustomerId);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Customer_deletion_fails_when_customer_has_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new InvoiceItem
            {
                ProductId = product.Id,
                Quantity = 1,
                Price = 100.00m,
                Discount = 0m
            }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today(),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems).Value;

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(customer.Id);

        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.Conflict);

        // Verify customer still exists
        var customerStillExists = await dbContext.Set<Customer>()
            .FirstOrDefaultAsync(x => x.Id == customer.Id);
        customerStillExists.ShouldNotBeNull();
    }

    [Fact]
    public async Task Customer_can_be_deleted_when_customer_exists_and_has_no_invoices()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        var useCase = CreateUseCase(dbContext);

        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);

        var customerResult = Customer.Create("Test Customer", "customer@test.com", appUser.Id);
        var customer = customerResult.Value;
        dbContext.Set<Customer>().Add(customer);

        await dbContext.SaveChangesAsync();

        var result = await useCase.Execute(customer.Id);

        result.IsSuccess.ShouldBeTrue();
        
        var deletedCustomer = await dbContext.Set<Customer>()
            .FirstOrDefaultAsync(x => x.Id == customer.Id);
        deletedCustomer.ShouldBeNull();
    }
}
