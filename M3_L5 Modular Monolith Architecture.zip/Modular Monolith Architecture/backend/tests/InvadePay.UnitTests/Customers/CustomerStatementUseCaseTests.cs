﻿using InvadePay.Core.Features.Customers.Statement;
using InvadePay.Core.Models.Customers;
using InvadePay.Core.Models.Invoices;
using InvadePay.Core.Models.Products;
using InvadePay.Core.Models.Shared;
using InvadePay.Core.Models.Users;
using InvadePay.Core.Shared.Extensions;
using InvadePay.UnitTests.TestSetup;
using Shouldly;

namespace InvadePay.UnitTests.Customers;

public class CustomerStatementUseCaseTests
{
    [Fact]
    public async Task Customer_statement_is_not_returned_when_customer_does_not_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var useCase = new CustomerStatementUseCase(dbContext);
        var request = new CustomerStatementRequest(9999, DateOnlyCreator.Today().AddDays(-30).ToDateTime(TimeOnly.MinValue), DateOnlyCreator.Today().ToDateTime(TimeOnly.MinValue));
        
        var result = await useCase.Execute(request, "test-user-id");
        
        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Customer_statement_fails_when_customer_belongs_to_different_user()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser1 = new AppUser("user1@example.com", "User", "One");
        var appUser2 = new AppUser("user2@example.com", "User", "Two");
        dbContext.Set<AppUser>().AddRange(appUser1, appUser2);
        await dbContext.SaveChangesAsync();

        var customer = new Customer
        {
            Name = "John Doe",
            Email = "john@example.com",
            AppUserId = appUser1.Id
        };
        dbContext.Set<Customer>().Add(customer);
        await dbContext.SaveChangesAsync();
        
        var useCase = new CustomerStatementUseCase(dbContext);
        var request = new CustomerStatementRequest(customer.Id, DateOnlyCreator.Today().AddDays(-30).ToDateTime(TimeOnly.MinValue), DateOnlyCreator.Today().ToDateTime(TimeOnly.MinValue));
        
        var result = await useCase.Execute(request, appUser2.Id);
        
        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.NotFound);
    }

    [Fact]
    public async Task Customer_statement_fails_when_start_date_is_after_end_date()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var customer = new Customer
        {
            Name = "John Doe",
            Email = "john@example.com",
            AppUserId = appUser.Id
        };
        dbContext.Set<Customer>().Add(customer);
        await dbContext.SaveChangesAsync();
        
        var useCase = new CustomerStatementUseCase(dbContext);
        var request = new CustomerStatementRequest(customer.Id, DateOnlyCreator.Today().ToDateTime(TimeOnly.MinValue), DateOnlyCreator.Today().AddDays(-1).ToDateTime(TimeOnly.MinValue));
        
        var result = await useCase.Execute(request, appUser.Id);
        
        result.IsError.ShouldBeTrue();
        result.Status.ShouldBe(ResultStatus.UnprocessableEntity);
        result.ErrorMessage.ShouldContain("Start date cannot be after end date");
    }

    [Fact]
    public async Task Customer_statement_returns_empty_statement_when_no_invoices_exist()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var customer = new Customer
        {
            Name = "John Doe",
            Email = "john@example.com",
            AppUserId = appUser.Id
        };
        dbContext.Set<Customer>().Add(customer);
        await dbContext.SaveChangesAsync();
        
        var useCase = new CustomerStatementUseCase(dbContext);
        var request = new CustomerStatementRequest(customer.Id, DateOnlyCreator.Today().AddDays(-30).ToDateTime(TimeOnly.MinValue), DateOnlyCreator.Today().ToDateTime(TimeOnly.MinValue));
        
        var result = await useCase.Execute(request, appUser.Id);
        
        result.IsSuccess.ShouldBeTrue();
        result.Value.CustomerId.ShouldBe(customer.Id);
        result.Value.CustomerName.ShouldBe("John Doe");
        result.Value.CustomerEmail.ShouldBe("john@example.com");
        result.Value.TotalOutstanding.ShouldBe(0);
        result.Value.TotalPaid.ShouldBe(0);
        result.Value.AccountBalance.ShouldBe(0);
        result.Value.OutstandingInvoices.ShouldBeEmpty();
        result.Value.PaidInvoices.ShouldBeEmpty();
    }

    [Fact]
    public async Task Customer_statement_correctly_calculates_outstanding_and_paid_amounts()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var customer = new Customer
        {
            Name = "John Doe",
            Email = "john@example.com",
            AppUserId = appUser.Id
        };
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();
        
        var outstandingInvoiceItems = new List<InvoiceItem>
        {
            new() { ProductId = product.Id, Quantity = 1, Price = 100.00m, Discount = 0 }
        };

        var outstandingInvoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today().AddDays(-10),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            outstandingInvoiceItems).Value;
        outstandingInvoice.SetStatusTo(InvoiceStatus.Sent);
        
        var paidInvoiceItems = new List<InvoiceItem>
        {
            new() { ProductId = product.Id, Quantity = 2, Price = 50.00m, Discount = 10 }
        };

        var paidInvoice = Invoice.Create(
            2,
            customer.Id,
            DateOnlyCreator.Today().AddDays(-5),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            paidInvoiceItems).Value;
        paidInvoice.SetStatusTo(InvoiceStatus.Paid);

        dbContext.Set<Invoice>().AddRange(outstandingInvoice, paidInvoice);
        await dbContext.SaveChangesAsync();
        
        var useCase = new CustomerStatementUseCase(dbContext);
        var request = new CustomerStatementRequest(customer.Id, DateOnlyCreator.Today().AddDays(-30).ToDateTime(TimeOnly.MinValue), DateOnlyCreator.Today().ToDateTime(TimeOnly.MinValue));
        
        var result = await useCase.Execute(request, appUser.Id);
        
        result.IsSuccess.ShouldBeTrue();
        result.Value.TotalOutstanding.ShouldBe(100.00m);
        result.Value.TotalPaid.ShouldBe(90.00m);
        result.Value.AccountBalance.ShouldBe(-10.00m);
        result.Value.OutstandingInvoices.Count.ShouldBe(1);
        result.Value.PaidInvoices.Count.ShouldBe(1);
    }

    [Fact]
    public async Task Customer_statement_includes_tax_calculations()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var customer = new Customer
        {
            Name = "John Doe",
            Email = "john@example.com",
            AppUserId = appUser.Id
        };
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);

        var tax = new Tax
        {
            Name = "VAT",
            Rate = 20.0m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Tax>().Add(tax);
        await dbContext.SaveChangesAsync();

        var invoiceItems = new List<InvoiceItem>
        {
            new() { ProductId = product.Id, Quantity = 1, Price = 100.00m, Discount = 0 }
        };

        var invoice = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today().AddDays(-10),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceItems,
            tax.Id).Value;
        invoice.SetStatusTo(InvoiceStatus.Sent);

        dbContext.Set<Invoice>().Add(invoice);
        await dbContext.SaveChangesAsync();
        
        var useCase = new CustomerStatementUseCase(dbContext);
        var request = new CustomerStatementRequest(customer.Id, DateOnlyCreator.Today().AddDays(-30).ToDateTime(TimeOnly.MinValue), DateOnlyCreator.Today().ToDateTime(TimeOnly.MinValue));
        
        var result = await useCase.Execute(request, appUser.Id);
        
        result.IsSuccess.ShouldBeTrue();
        var statementInvoice = result.Value.OutstandingInvoices.First();
        statementInvoice.SubtotalAmount.ShouldBe(100.00m);
        statementInvoice.TaxAmount.ShouldBe(20.00m);
        statementInvoice.TotalAmount.ShouldBe(120.00m);
        statementInvoice.TaxName.ShouldBe("VAT");
        statementInvoice.TaxRate.ShouldBe(20.0m);
    }

    [Fact]
    public async Task Customer_statement_filters_invoices_by_date_range()
    {
        using var builder = new DatabaseBuilder();
        var dbContext = builder.CreateDbContext();
        
        var appUser = new AppUser("test@example.com", "Test", "User");
        dbContext.Set<AppUser>().Add(appUser);
        await dbContext.SaveChangesAsync();

        var customer = new Customer
        {
            Name = "John Doe",
            Email = "john@example.com",
            AppUserId = appUser.Id
        };
        dbContext.Set<Customer>().Add(customer);

        var product = new Product
        {
            Name = "Test Product",
            DefaultPrice = 100.00m,
            AppUserId = appUser.Id
        };
        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        // Invoice within date range
        var invoiceInRangeItems = new List<InvoiceItem>
        {
            new() { ProductId = product.Id, Quantity = 1, Price = 100.00m, Discount = 0 }
        };

        var invoiceInRange = Invoice.Create(
            1,
            customer.Id,
            DateOnlyCreator.Today().AddDays(-10),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceInRangeItems).Value;
        invoiceInRange.SetStatusTo(InvoiceStatus.Sent);

        // Invoice outside date range
        var invoiceOutOfRangeItems = new List<InvoiceItem>
        {
            new() { ProductId = product.Id, Quantity = 1, Price = 200.00m, Discount = 0 }
        };

        var invoiceOutOfRange = Invoice.Create(
            2,
            customer.Id,
            DateOnlyCreator.Today().AddDays(-40),
            DateOnlyCreator.Today().AddDays(30),
            "14:30",
            appUser.Id,
            invoiceOutOfRangeItems).Value;
        invoiceOutOfRange.SetStatusTo(InvoiceStatus.Sent);

        dbContext.Set<Invoice>().AddRange(invoiceInRange, invoiceOutOfRange);
        await dbContext.SaveChangesAsync();
        
        var useCase = new CustomerStatementUseCase(dbContext);
        var request = new CustomerStatementRequest(customer.Id, DateOnlyCreator.Today().AddDays(-30).ToDateTime(TimeOnly.MinValue), DateOnlyCreator.Today().ToDateTime(TimeOnly.MinValue));
        
        var result = await useCase.Execute(request, appUser.Id);
        
        result.IsSuccess.ShouldBeTrue();
        result.Value.OutstandingInvoices.Count.ShouldBe(1);
        result.Value.OutstandingInvoices.First().TotalAmount.ShouldBe(100.00m);
    }
}
