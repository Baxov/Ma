﻿using System.ComponentModel.DataAnnotations;

namespace InvadePay.Api.Configuration;

public class HangfireOptions
{
    [Required]
    public string ConnectionString { get; set; } = string.Empty;
}
