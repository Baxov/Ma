namespace InvadePay.Api.Configuration;

public static class Security
{
    public const string CorsPolicy = "OpenCorsPolicy";
    public const string RateLimitPolicy = "fixed";
}