﻿using Hangfire;
using Hangfire.Common;
using Hangfire.Dashboard;
using Hangfire.SqlServer;
using Hangfire.Server;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;

namespace InvadePay.Api.Configuration;

public static class HangfireExtensions
{
    public static IServiceCollection AddHangfire(this IServiceCollection services, IWebHostEnvironment? environment = null)
    {
        if (environment?.EnvironmentName == "Test")
        {
            return services;
        }

        var hangfire = services.BuildServiceProvider().GetRequiredService<IOptions<HangfireOptions>>().Value;
        EnsureHangfireDatabaseExists(hangfire.ConnectionString);

        services.AddHangfire((serviceProvider, configuration) =>
        {
            var hangfireOptions = serviceProvider.GetRequiredService<IOptions<HangfireOptions>>().Value;

            configuration
                .SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
                .UseSimpleAssemblyNameTypeSerializer()
                .UseRecommendedSerializerSettings()
                .UseSqlServerStorage(hangfireOptions.ConnectionString, new SqlServerStorageOptions
                {
                    CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
                    SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
                    QueuePollInterval = TimeSpan.Zero,
                    UseRecommendedIsolationLevel = true,
                    DisableGlobalLocks = true,
                    // Add connection timeout settings
                    PrepareSchemaIfNecessary = true,
                    EnableHeavyMigrations = true
                });
        });

        services.AddHangfireServer(options =>
        {
            // Configure server options to prevent timeout issues
            options.HeartbeatInterval = TimeSpan.FromSeconds(30);
            options.ServerTimeout = TimeSpan.FromMinutes(5);
            options.SchedulePollingInterval = TimeSpan.FromSeconds(15);
            options.WorkerCount = Math.Max(Environment.ProcessorCount, 2);
            options.ServerName = $"{Environment.MachineName}-{Environment.ProcessId}";

            // Add server filters for better error handling
            options.FilterProvider = new HangfireFilterProvider();
        });

        return services;
    }

    public static IApplicationBuilder UseHangfire(this IApplicationBuilder app)
    {
        if (app is not WebApplication webApplication)
        {
            throw new InvalidOperationException("UseHangfire can only be used with WebApplication");
        }

        if (webApplication.Environment.EnvironmentName == "Test")
        {
            return app;
        }

        // Add Hangfire dashboard (only in development for security)
        if (webApplication.Environment.IsDevelopment())
        {
            var dashboardOptions = new DashboardOptions
            {
                Authorization = new[] { new AllowAllConnectionsFilter() },
                DashboardTitle = "InvadePay Hangfire Dashboard",
                StatsPollingInterval = 2000
            };

            app.UseHangfireDashboard("/hangfire", dashboardOptions);
        }

        return app;
    }

    private static void EnsureHangfireDatabaseExists(string connectionString)
    {
        var builder = new SqlConnectionStringBuilder(connectionString);
        var databaseName = builder.InitialCatalog;
        builder.InitialCatalog = "master";
        var masterConnectionString = builder.ToString();

        using var connection = new SqlConnection(masterConnectionString);
        connection.Open();

        var checkDbCommand = connection.CreateCommand();
        checkDbCommand.CommandText = $"SELECT database_id FROM sys.databases WHERE Name = '{databaseName}'";
        var databaseExists = checkDbCommand.ExecuteScalar() != null;

        if (!databaseExists)
        {
            var createDbCommand = connection.CreateCommand();
            createDbCommand.CommandText = $"CREATE DATABASE [{databaseName}]";
            createDbCommand.ExecuteNonQuery();
        }
    }
}

// Allow all connections in development - DO NOT USE IN PRODUCTION
public class AllowAllConnectionsFilter : IDashboardAuthorizationFilter
{
    public bool Authorize(DashboardContext context)
    {
        return true; // Allow all connections in development
    }
}

public class HangfireFilterProvider : IJobFilterProvider
{
    public IEnumerable<JobFilter> GetFilters(Job job)
    {
        yield return new JobFilter(new HangfireLoggingFilter(), JobFilterScope.Global, order: null);
        yield return new JobFilter(new AutomaticRetryAttribute { Attempts = 3 }, JobFilterScope.Global, order: null);
    }
}

public class HangfireLoggingFilter : IServerFilter
{
    public void OnPerforming(PerformingContext context)
    {
        var logger = context.BackgroundJob.Job.Args.OfType<ILogger>().FirstOrDefault();
        logger?.LogInformation("Starting job {JobId}: {JobMethod}",
            context.BackgroundJob.Id,
            context.BackgroundJob.Job.Method.Name);
    }

    public void OnPerformed(PerformedContext context)
    {
        var logger = context.BackgroundJob.Job.Args.OfType<ILogger>().FirstOrDefault();
        if (context.Exception != null)
        {
            logger?.LogError(context.Exception, "Job {JobId} failed: {JobMethod}",
                context.BackgroundJob.Id,
                context.BackgroundJob.Job.Method.Name);
        }
        else
        {
            logger?.LogInformation("Completed job {JobId}: {JobMethod}",
                context.BackgroundJob.Id,
                context.BackgroundJob.Job.Method.Name);
        }
    }
}
