﻿using InvadePay.Common.Options;

namespace InvadePay.Api.Configuration;

public static class OptionsExtensions
{
    public static IServiceCollection AddCustomOptions(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<HangfireOptions>()
            .Bind(configuration.GetSection("Hangfire"))
            .ValidateDataAnnotations();

        services.AddOptions<EmailOptions>()
            .Bind(configuration.GetSection("Email"))
            .ValidateDataAnnotations();

        return services;
    }
}