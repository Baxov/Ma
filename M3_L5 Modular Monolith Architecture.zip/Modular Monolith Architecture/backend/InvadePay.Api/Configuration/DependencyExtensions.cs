﻿using InvadePay.Common;
using InvadePay.Common.BackgroundJobs;
using InvadePay.Common.DomainEvents;
using InvadePay.Common.Interceptors;

namespace InvadePay.Api.Configuration;

public static class DependencyExtensions
{
    public static IServiceCollection AddDependencyInjection(this IServiceCollection services)
    {
        services.AddScoped<DomainEventDispatcher>();
        services.AddScoped<DomainEventInterceptor>();
        services.AddScoped<AuditInterceptor>();
        
        services.AddTransient<IUserContext, UserContext>();
        services.AddScoped<IBackgroundJobScheduler, BackgroundJobScheduler>();

        return services;
    }
}