using InvadePay.Api.Configuration;
using InvadePay.Api.Middlewares;
using InvadePay.Common.Api;
using InvadePay.Inventory;
using InvadePay.Users;
using InvadePay.Invoicing.Api;
using Scalar.AspNetCore;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// Configure Serilog
builder.Host.UseSerilog((context, configuration) =>
    configuration.ReadFrom.Configuration(context.Configuration));

builder.Services
    .AddOpenApi()
    .AddEndpointsApiExplorer()
    .AddHttpContextAccessor()
    .AddCustomOptions(builder.Configuration)
    .AddHangfire(builder.Environment)
    .AddDependencyInjection()
    .AddSecurity(builder.Configuration)
    .AddExceptionHandler<GlobalExceptionHandler>()
    .AddProblemDetails()
    .AddSerializationOptions()
    .AddUsersModule(builder.Configuration)
    .AddInventoryModule(builder.Configuration)
    .AddInvoicingModule(builder.Configuration);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference();
}

app.UseExceptionHandler()
    .UseHttpsRedirection()
    .UseHangfire()
    .UseCors(Security.CorsPolicy)
    .UseAuthentication()
    .UseAuthorization()
    .UseUsersModule()
    .UseInventoryModule()
    .UseInvoicingModule()
    .MapEndpoints();

await app.RunAsync();

// ReSharper disable once ClassNeverInstantiated.Global
// Needed for testing
public partial class Program;
