﻿using InvadePay.Common.Models;

namespace InvadePay.Inventory.Contracts;

public interface IProductDetailsHandler
{
    Task<Result<List<ProductDetailsResponse>>> GetMultipleProducts(IEnumerable<long> productIds, string userId);
}