﻿namespace InvadePay.Inventory.Contracts;

public class ProductDetailsResponse
{
    public long Id { get; set; }
    public string Name { get; set; } = null!;
    public decimal? DefaultPrice { get; set; }
    public string? UnitOfMeasure { get; set; }
    public decimal? StockQuantity { get; set; }
    public bool TrackInventory { get; set; }
}