﻿using InvadePay.Common.Models;

namespace InvadePay.Inventory.Contracts;

public interface IInventoryTracker
{
    Task<Result> ValidateStockAvailability(Dictionary<long, decimal> productQuantities, string appUserId);
    Task<Result> DeductStock(Dictionary<long, decimal> productQuantities, string appUserId);
    Task<Result> RestoreStock(Dictionary<long, decimal> productQuantities, string appUserId);
}