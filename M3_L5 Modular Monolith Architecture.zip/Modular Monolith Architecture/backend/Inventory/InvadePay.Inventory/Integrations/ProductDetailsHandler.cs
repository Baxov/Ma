﻿using InvadePay.Common.Models;
using InvadePay.Inventory.Contracts;
using InvadePay.Inventory.Database;
using InvadePay.Inventory.Models;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Inventory.Integrations;

public class ProductDetailsHandler(IDbContext dbContext): IProductDetailsHandler
{
    public async Task<Result<List<ProductDetailsResponse>>> GetMultipleProducts(IEnumerable<long> productIds, string userId)
    {
        var products = await dbContext.Set<Product>()
            .Where(x => productIds.Contains(x.Id) && x.AppUserId == userId)
            .Select(x => new ProductDetailsResponse
                {
                    Id = x.Id,
                    Name = x.Name,
                    DefaultPrice = x.DefaultPrice,
                    UnitOfMeasure = x.UnitOfMeasure,
                    StockQuantity = x.StockQuantity,
                    TrackInventory = x.TrackInventory
                })
            .ToListAsync();

        return products;
    }
}