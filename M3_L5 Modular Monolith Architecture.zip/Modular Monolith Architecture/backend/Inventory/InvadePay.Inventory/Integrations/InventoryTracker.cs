﻿using InvadePay.Common.Models;
using InvadePay.Inventory.Contracts;
using InvadePay.Inventory.Database;
using InvadePay.Inventory.Models;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Inventory.Integrations;

public class InventoryTracker(IDbContext dbContext) : IInventoryTracker
{
    public async Task<Result> ValidateStockAvailability(Dictionary<long, decimal> productQuantities, string appUserId)
    {
        if (productQuantities.Count == 0)
        {
            return Result.Success();
        }
        
        var productIds = productQuantities.Keys.ToList();
        var products = await dbContext.Set<Product>()
            .Where(p => productIds.Contains(p.Id) && p.AppUserId == appUserId)
            .ToListAsync();
        
        var missingProductIds = productIds.Except(products.Select(p => p.Id)).ToList();
        if (missingProductIds.Any())
        {
            return Result.NotFound($"Products with IDs {string.Join(", ", missingProductIds)} were not found.");
        }
        
        var stockValidationErrors = new List<string>();
        
        foreach (var product in products)
        {
            var requestedQuantity = productQuantities[product.Id];
        
            if (product is not { Type: ProductType.Product, TrackInventory: true })
            {
                continue;
            }
        
            if (product.StockQuantity < requestedQuantity)
            {
                stockValidationErrors.Add($"Insufficient stock for product '{product.Name}'. Available: {product.StockQuantity}, Requested: {requestedQuantity}");
            }
        }
        
        if (stockValidationErrors.Any())
        {
            return Result.Error(string.Join(" ", stockValidationErrors));
        }

        return Result.Success();
    }

    public async Task<Result> DeductStock(Dictionary<long, decimal> productQuantities, string appUserId)
    {
        if (!productQuantities.Any())
        {
            return Result.Success();
        }
        
        var validationResult = await ValidateStockAvailability(productQuantities, appUserId);
        if (validationResult.IsError)
        {
            return validationResult;
        }
        
        var productIds = productQuantities.Keys.ToList();
        var products = await dbContext.Set<Product>()
            .Where(p => productIds.Contains(p.Id) && p.AppUserId == appUserId)
            .ToListAsync();
        
        foreach (var product in products)
        {
            var quantityToDeduct = productQuantities[product.Id];
        
            if (product is { Type: ProductType.Product, TrackInventory: true, StockQuantity: not null })
            {
                product.StockQuantity -= quantityToDeduct;
            }
        }
        
        await dbContext.SaveChangesAsync();
        return Result.Success();
    }

    public async Task<Result> RestoreStock(Dictionary<long, decimal> productQuantities, string appUserId)
    {
        if (!productQuantities.Any())
        {
            return Result.Success();
        }
        
        var productIds = productQuantities.Keys.ToList();
        var products = await dbContext.Set<Product>()
            .Where(p => productIds.Contains(p.Id) && p.AppUserId == appUserId)
            .ToListAsync();
        
        var missingProductIds = productIds.Except(products.Select(p => p.Id)).ToList();
        if (missingProductIds.Any())
        {
            return Result.NotFound($"Products with IDs {string.Join(", ", missingProductIds)} were not found.");
        }
        
        foreach (var product in products)
        {
            var quantityToRestore = productQuantities[product.Id];
        
            if (product is { Type: ProductType.Product, TrackInventory: true, StockQuantity: not null })
            {
                product.StockQuantity += quantityToRestore;
            }
        }

        await dbContext.SaveChangesAsync();
        return Result.Success();
    }
}
