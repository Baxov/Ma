﻿namespace InvadePay.Inventory.Models;

public enum ProductType
{
    Product,
    Service
}
