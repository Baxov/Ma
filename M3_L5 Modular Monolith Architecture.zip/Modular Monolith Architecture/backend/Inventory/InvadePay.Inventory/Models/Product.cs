﻿using InvadePay.Common.Models;

namespace InvadePay.Inventory.Models;

public class Product: BaseEntity, IUserOwnedResource
{
    public static class MaxLengths
    {
        public const int Name = 100;
        public const int UnitOfMeasure = 50;
    }

    public string Name { get; set; } = null!;
    public decimal? DefaultPrice { get; set; }
    
    public ProductType Type { get; set; } = ProductType.Product;
    public string? UnitOfMeasure { get; set; }
    public decimal? StockQuantity { get; set; }
    public bool TrackInventory { get; set; } = false;

    public string AppUserId { get; set; } = null!;
}