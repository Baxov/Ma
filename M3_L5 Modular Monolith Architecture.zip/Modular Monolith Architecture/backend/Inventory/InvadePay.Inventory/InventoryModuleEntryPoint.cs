using FluentValidation;
using InvadePay.Common.Api;
using InvadePay.Common.Interceptors;
using InvadePay.Inventory.Contracts;
using InvadePay.Inventory.Database;
using InvadePay.Inventory.Features.Create;
using InvadePay.Inventory.Features.Delete;
using InvadePay.Inventory.Features.GetById;
using InvadePay.Inventory.Features.GetList;
using InvadePay.Inventory.Features.Update;
using InvadePay.Inventory.Integrations;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using IDbContext = InvadePay.Inventory.Database.IDbContext;

namespace InvadePay.Inventory;

public static class InventoryModuleEntryPoint
{
    public static IServiceCollection AddInventoryModule(this IServiceCollection services, IConfiguration configuration)
    {
        ConfigureCustomOptions(services, configuration);
        ConfigureDependencyInjection(services);
        ConfigureDatabase(services);
        
        services.AddEndpoints(typeof(InventoryModuleEntryPoint).Assembly);
        
        return services;
    }

    public static IApplicationBuilder UseInventoryModule(this IApplicationBuilder app)
    {
        UseDatabase(app);
        return app;
    }
    
    private static void UseDatabase(IApplicationBuilder app)
    {
        if (app is not WebApplication webApplication)
        {
            throw new InvalidOperationException("UseDatabase can only be used with WebApplication");
        }

        using var scope = webApplication.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<InventoryContext>();
        dbContext.Database.Migrate();
    }
    
    private static void ConfigureCustomOptions(IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<InventoryDatabaseOptions>()
            .Bind(configuration.GetSection("InventoryDatabase"))
            .ValidateDataAnnotations();
    }
    
    private static void ConfigureDatabase(IServiceCollection services)
    {
        services.AddDbContext<InventoryContext>((serviceProvider, options) =>
        {
            var dbOptions = serviceProvider.GetRequiredService<IOptions<InventoryDatabaseOptions>>().Value;

            options.UseSqlServer(dbOptions.ConnectionString,
                    optionsActions =>
                    {
                        optionsActions.CommandTimeout(dbOptions.CommandTimeout);
                        optionsActions.EnableRetryOnFailure(dbOptions.MaxRetryCount);
                    })
                .AddInterceptors(serviceProvider.GetRequiredService<AuditInterceptor>());
        });
    }
    
    private static void ConfigureDependencyInjection(IServiceCollection services)
    {
        services.AddScoped<IDbContext, InventoryContext>();
        services.AddValidatorsFromAssemblyContaining<CreateProductValidator>();
        
        services.AddTransient<CreateProductUseCase>();
        services.AddTransient<GetProductByIdUseCase>();
        services.AddTransient<GetProductListUseCase>();
        services.AddTransient<UpdateProductUseCase>();
        services.AddTransient<DeleteProductUseCase>();
        services.AddTransient<IProductDetailsHandler, ProductDetailsHandler>();
        services.AddTransient<IInventoryTracker, InventoryTracker>();
    }
}