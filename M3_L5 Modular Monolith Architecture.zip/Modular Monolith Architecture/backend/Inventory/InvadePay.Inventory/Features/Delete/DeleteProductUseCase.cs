using InvadePay.Common.Models;
using InvadePay.Inventory.Models;
using InvadePay.Invoicing.Contracts;
using Microsoft.EntityFrameworkCore;
using IDbContext = InvadePay.Inventory.Database.IDbContext;

namespace InvadePay.Inventory.Features.Delete;

public class DeleteProductUseCase(IDbContext dbContext, IProductUsageChecker productUsageChecker)
{
    public async Task<Result> Execute(long id)
    {
        var product = await dbContext.Set<Product>()
            .FirstOrDefaultAsync(x => x.Id == id);

        if (product == null)
        {
            return Result.NotFound($"Product with id {id} was not found.");
        }

        var isUsedInInvoices = await productUsageChecker.IsProductUsedInInvoices(id);
        if (isUsedInInvoices)
        {
            return Result.Conflict("Product cannot be deleted because it is used in invoices.");
        }

        dbContext.Set<Product>().Remove(product);
        await dbContext.SaveChangesAsync();

        return Result.Success();
    }
}