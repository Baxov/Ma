﻿using InvadePay.Common.Api;
using InvadePay.Common.Models;
using InvadePay.Inventory.Filters;
using InvadePay.Inventory.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Inventory.Features.Delete;

public class DeleteProductEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapDelete("/api/products/{id:long}", DeleteProduct)
            .WithSummary("Deletes a specific product by its ID.")
            .WithTags("Products")
            .RequireAuthorization()
            .UserOwnedResource<Product>();
    }
    
    private static async Task<Results<NoContent, NotFound<string>, Conflict<string>>> DeleteProduct(
        long id,
        DeleteProductUseCase useCase)
    {
        var result = await useCase.Execute(id);

        if (result.IsSuccess)
        {
            return TypedResults.NoContent();
        }

        return result.Status switch
        {
            ResultStatus.NotFound => TypedResults.NotFound(result.ErrorMessage),
            ResultStatus.Conflict => TypedResults.Conflict(result.ErrorMessage),
            _ => throw new NotImplementedException()
        };
    }
}
