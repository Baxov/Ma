using InvadePay.Inventory.Models;

namespace InvadePay.Inventory.Features.GetList;

public record ProductResponse(
    long Id,
    string Name,
    decimal? DefaultPrice,
    ProductType Type,
    string? UnitOfMeasure,
    decimal? StockQuantity,
    bool TrackInventory);