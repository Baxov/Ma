﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Responses;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Inventory.Features.GetList;

public class GetProductListEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/products", GetAllProducts)
            .WithSummary("Retrieves a paginated list of all available products.")
            .WithTags("Products")
            .RequireAuthorization();
    }
    
    private static async Task<Results<Ok<PagedResponse<ProductResponse>>, UnauthorizedHttpResult>> GetAllProducts(
        int? page,
        int? pageSize,
        GetProductListUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(page.GetValueOrDefault(), pageSize.GetValueOrDefault(), userId);
        return TypedResults.Ok(result);
    }
}
