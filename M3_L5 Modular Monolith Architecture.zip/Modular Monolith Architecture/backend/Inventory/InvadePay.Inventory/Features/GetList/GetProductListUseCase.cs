﻿using InvadePay.Common.Responses;
using InvadePay.Inventory.Models;
using Microsoft.EntityFrameworkCore;
using IDbContext = InvadePay.Inventory.Database.IDbContext;

namespace InvadePay.Inventory.Features.GetList;

public class GetProductListUseCase(IDbContext dbContext)
{
    public async Task<PagedResponse<ProductResponse>> Execute(int page, int pageSize, string appUserId)
    {
        if (page == 0)
        {
            page = 1;
        }

        if (pageSize == 0)
        {
            pageSize = 10;
        }

        var query = dbContext.Set<Product>()
            .Where(x => x.AppUserId == appUserId)
            .OrderBy(x => x.CreatedAt);

        var totalCount = await query.CountAsync();

        var items = await query
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(x => new ProductResponse(
                x.Id,
                x.Name,
                x.DefaultPrice,
                x.Type,
                x.UnitOfMeasure,
                x.StockQuantity,
                x.TrackInventory))
            .ToListAsync();

        return new PagedResponse<ProductResponse>(items, totalCount);
    }
}
