using InvadePay.Inventory.Models;

namespace InvadePay.Inventory.Features.Create;

public record CreateProductResponse(
    long Id,
    string Name,
    decimal? DefaultPrice,
    ProductType Type,
    string? UnitOfMeasure,
    decimal? StockQuantity,
    bool TrackInventory);