﻿using InvadePay.Common;
using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Inventory.Features.Create;

public class CreateProductEndpoint : IEndpoint
{
    private const string GetProductEndpointName = "GetProduct";
    
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPost("/api/products", CreateProduct)
            .WithSummary("Creates a new product with specified details.")
            .Validator<CreateProductRequest>()
            .WithTags("Products")
            .RequireAuthorization();
    }
    
    private static async Task<Results<CreatedAtRoute<CreateProductResponse>, BadRequest<string>, UnauthorizedHttpResult>> CreateProduct(
        CreateProductRequest request,
        CreateProductUseCase useCase,
        IUserContext userContext)
    {
        var userId = userContext.GetUserId();

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        var result = await useCase.Execute(request, userId);
        return result.IsSuccess
            ? TypedResults.CreatedAtRoute(result.Value, GetProductEndpointName, new { id = result.Value.Id })
            : TypedResults.BadRequest(result.ErrorMessage);
    }
}
