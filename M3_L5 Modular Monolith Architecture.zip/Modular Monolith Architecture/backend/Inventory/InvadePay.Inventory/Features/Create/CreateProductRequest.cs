﻿using InvadePay.Inventory.Models;

namespace InvadePay.Inventory.Features.Create;

public record CreateProductRequest(
    string Name,
    decimal? DefaultPrice,
    ProductType Type = ProductType.Product,
    string? UnitOfMeasure = null,
    decimal? StockQuantity = null,
    bool TrackInventory = false);