using InvadePay.Common.Models;
using InvadePay.Inventory.Database;
using InvadePay.Inventory.Models;

namespace InvadePay.Inventory.Features.Create;

public class CreateProductUseCase(IDbContext dbContext)
{
    public async Task<Result<CreateProductResponse>> Execute(CreateProductRequest request, string appUserId)
    {
        var product = new Product
        {
            Name = request.Name,
            DefaultPrice = request.DefaultPrice,
            Type = request.Type,
            UnitOfMeasure = request.UnitOfMeasure,
            StockQuantity = request.StockQuantity,
            TrackInventory = request.TrackInventory,
            AppUserId = appUserId
        };

        dbContext.Set<Product>().Add(product);
        await dbContext.SaveChangesAsync();

        return new CreateProductResponse(
            product.Id,
            product.Name,
            product.DefaultPrice,
            product.Type,
            product.UnitOfMeasure,
            product.StockQuantity,
            product.TrackInventory);
    }
}