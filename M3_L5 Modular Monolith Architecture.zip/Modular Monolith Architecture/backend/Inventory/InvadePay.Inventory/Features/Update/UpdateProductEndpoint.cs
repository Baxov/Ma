﻿using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using InvadePay.Common.Models;
using InvadePay.Inventory.Filters;
using InvadePay.Inventory.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Inventory.Features.Update;

public class UpdateProductEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPut("/api/products/{id:long}", UpdateProduct)
            .WithSummary("Updates an existing product with specified details.")
            .Validator<UpdateProductRequest>()
            .WithTags("Products")
            .RequireAuthorization()
            .UserOwnedResource<Product>();
    }

    private static async Task<Results<Ok<UpdateProductResponse>, NotFound<string>, BadRequest<string>>> UpdateProduct(
        long id,
        UpdateProductRequest request,
        UpdateProductUseCase useCase)
    {
        var result = await useCase.Execute(id, request);

        if (result.IsSuccess)
        {
            return TypedResults.Ok(result.Value);
        }

        if (result.Status == ResultStatus.NotFound)
        {
            return TypedResults.NotFound(result.ErrorMessage);
        }

        return TypedResults.BadRequest(result.ErrorMessage);
    }
}
