using InvadePay.Inventory.Models;

namespace InvadePay.Inventory.Features.Update;

public record UpdateProductResponse(
    long Id,
    string Name,
    decimal? DefaultPrice,
    ProductType Type,
    string? UnitOfMeasure,
    decimal? StockQuantity,
    bool TrackInventory);