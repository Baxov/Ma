using InvadePay.Common.Models;
using InvadePay.Inventory.Models;
using Microsoft.EntityFrameworkCore;
using IDbContext = InvadePay.Inventory.Database.IDbContext;

namespace InvadePay.Inventory.Features.Update;

public class UpdateProductUseCase(IDbContext dbContext)
{
    public async Task<Result<UpdateProductResponse>> Execute(long id, UpdateProductRequest request)
    {
        var product = await dbContext.Set<Product>()
            .FirstOrDefaultAsync(x => x.Id == id);

        if (product == null)
        {
            return Result.NotFound($"Product with id {id} was not found.");
        }

        product.Name = request.Name;
        product.DefaultPrice = request.DefaultPrice;
        product.Type = request.Type;
        product.UnitOfMeasure = request.UnitOfMeasure;
        product.StockQuantity = request.StockQuantity;
        product.TrackInventory = request.TrackInventory;

        await dbContext.SaveChangesAsync();

        return new UpdateProductResponse(
            product.Id,
            product.Name,
            product.DefaultPrice,
            product.Type,
            product.UnitOfMeasure,
            product.StockQuantity,
            product.TrackInventory);
    }
}