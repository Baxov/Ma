﻿using InvadePay.Inventory.Models;

namespace InvadePay.Inventory.Features.Update;

public record UpdateProductRequest(
    string Name,
    decimal? DefaultPrice,
    ProductType Type = ProductType.Product,
    string? UnitOfMeasure = null,
    decimal? StockQuantity = null,
    bool TrackInventory = false);