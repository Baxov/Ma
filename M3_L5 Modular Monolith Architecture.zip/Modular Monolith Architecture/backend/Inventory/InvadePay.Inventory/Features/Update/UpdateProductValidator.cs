using FluentValidation;
using InvadePay.Inventory.Models;

namespace InvadePay.Inventory.Features.Update;

public class UpdateProductValidator : AbstractValidator<UpdateProductRequest>
{
    public UpdateProductValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty()
            .MaximumLength(Product.MaxLengths.Name);

        RuleFor(x => x.DefaultPrice)
            .GreaterThan(0)
            .When(x => x.DefaultPrice.HasValue);

        RuleFor(x => x.UnitOfMeasure)
            .MaximumLength(Product.MaxLengths.UnitOfMeasure)
            .When(x => !string.IsNullOrEmpty(x.UnitOfMeasure));

        RuleFor(x => x.StockQuantity)
            .GreaterThanOrEqualTo(0)
            .When(x => x.StockQuantity.HasValue);
        
        RuleFor(x => x.StockQuantity)
            .NotNull()
            .WithMessage("Stock quantity is required when inventory tracking is enabled for products.")
            .When(x => x.TrackInventory && x.Type == ProductType.Product);
    }
}