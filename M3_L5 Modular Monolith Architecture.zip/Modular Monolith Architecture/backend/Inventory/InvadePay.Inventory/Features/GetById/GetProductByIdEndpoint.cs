﻿using InvadePay.Common.Api;
using InvadePay.Inventory.Filters;
using InvadePay.Inventory.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Inventory.Features.GetById;

public class GetProductByIdEndpoint : IEndpoint
{
    private const string GetProductEndpointName = "GetProduct";
    
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapGet("/api/products/{id:long}", GetProductById)
            .WithSummary("Retrieves details for a specific product by its ID.")
            .WithName(GetProductEndpointName)
            .WithTags("Products")
            .RequireAuthorization()
            .UserOwnedResource<Product>();
    }
    
    private static async Task<Results<Ok<SingleProductResponse>, NotFound<string>>> GetProductById(
        long id,
        GetProductByIdUseCase useCase)
    {
        var result = await useCase.Execute(id);
        return result.IsSuccess
            ? TypedResults.Ok(result.Value)
            : TypedResults.NotFound(result.ErrorMessage);
    }
}
