﻿using InvadePay.Inventory.Models;

namespace InvadePay.Inventory.Features.GetById;

public record SingleProductResponse(
    long Id,
    string Name,
    decimal? DefaultPrice,
    ProductType Type,
    string? UnitOfMeasure,
    decimal? StockQuantity,
    bool TrackInventory);