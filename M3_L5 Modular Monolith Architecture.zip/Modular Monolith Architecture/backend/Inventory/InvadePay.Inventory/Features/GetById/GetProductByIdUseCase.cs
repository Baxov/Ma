﻿using InvadePay.Common.Models;
using InvadePay.Inventory.Models;
using Microsoft.EntityFrameworkCore;
using IDbContext = InvadePay.Inventory.Database.IDbContext;

namespace InvadePay.Inventory.Features.GetById;

public class GetProductByIdUseCase(IDbContext dbContext)
{
    public async Task<Result<SingleProductResponse>> Execute(long id)
    {
        var product = await dbContext.Set<Product>()
            .Where(x => x.Id == id)
            .Select(x => new SingleProductResponse(
                x.Id,
                x.Name,
                x.DefaultPrice,
                x.Type,
                x.UnitOfMeasure,
                x.StockQuantity,
                x.TrackInventory))
            .FirstOrDefaultAsync();

        if (product == null)
        {
            return Result.NotFound($"Product with id {id} was not found.");
        }

        return product;
    }
}
