using System.Security.Claims;
using InvadePay.Common.Models;
using InvadePay.Inventory.Database;
using Microsoft.AspNetCore.Http;

namespace InvadePay.Inventory.Filters;

public sealed class UserOwnedEndpointFilter<T>(InventoryContext dbContext) : IEndpointFilter
    where T : class, IUserOwnedResource
{
    public async ValueTask<object?> InvokeAsync(
        EndpointFilterInvocationContext context,
        EndpointFilterDelegate next)
    {
        var http = context.HttpContext;

        // Ensure user is authenticated
        if (!http.User.Identity?.IsAuthenticated ?? true)
        {
            return TypedResults.Unauthorized();
        }

        var userId = http.User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                     ?? http.User.FindFirst("sub")?.Value;

        if (string.IsNullOrEmpty(userId))
        {
            return TypedResults.Unauthorized();
        }

        // Get {id} from route
        if (!http.Request.RouteValues.TryGetValue("id", out var idObj) ||
            !long.TryParse(idObj?.ToString(), out var id))
        {
            return TypedResults.BadRequest("Missing or invalid id.");
        }

        var entity = await dbContext.Set<T>().FindAsync(id);
        if (entity is null)
        {
            return TypedResults.NotFound();
        }

        if (entity.AppUserId != userId)
        {
            return TypedResults.Forbid();
        }

        return await next(context);
    }
}
