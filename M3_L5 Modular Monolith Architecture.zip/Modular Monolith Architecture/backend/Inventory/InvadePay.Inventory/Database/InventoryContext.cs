using InvadePay.Common.Models;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Inventory.Database;

public class InventoryContext : DbContext, IDbContext
{
    public InventoryContext(DbContextOptions<InventoryContext> options) : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("Inventory");
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(InventoryContext).Assembly);
        base.OnModelCreating(modelBuilder);
    }

    public async Task<int> SaveChangesAsync()
    {
        return await base.SaveChangesAsync();
    }

    public new DbSet<TEntity> Set<TEntity>() where TEntity : class, IEntity
    {
        return base.Set<TEntity>();
    }
}