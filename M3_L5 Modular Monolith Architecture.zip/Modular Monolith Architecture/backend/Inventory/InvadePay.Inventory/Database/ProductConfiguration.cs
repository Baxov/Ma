﻿using InvadePay.Inventory.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InvadePay.Inventory.Database;

public class ProductConfiguration: IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        builder.ToTable("Products");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Name)
            .IsRequired()
            .HasMaxLength(Product.MaxLengths.Name);
        builder.Property(x => x.DefaultPrice)
            .HasPrecision(18, 2);
        builder.Property(x => x.AppUserId)
            .IsRequired();
        
        builder.Property(x => x.Type)
            .IsRequired()
            .HasDefaultValue(ProductType.Product);
        builder.Property(x => x.UnitOfMeasure)
            .HasMaxLength(Product.MaxLengths.UnitOfMeasure);
        builder.Property(x => x.StockQuantity)
            .HasPrecision(18, 2);
        builder.Property(x => x.TrackInventory)
            .IsRequired()
            .HasDefaultValue(false);
    }
}