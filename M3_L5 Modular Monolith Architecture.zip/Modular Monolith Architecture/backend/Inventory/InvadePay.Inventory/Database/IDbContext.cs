﻿using InvadePay.Common.Models;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Inventory.Database;

public interface IDbContext
{
    DbSet<TEntity> Set<TEntity>() where TEntity : class, IEntity;
    Task<int> SaveChangesAsync();
}