﻿using InvadePay.Common.Models;
using InvadePay.Users.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace InvadePay.Users.Database;

public class UsersContext : IdentityDbContext<AppUser>
{
    public UsersContext(DbContextOptions<UsersContext> options) : base(options)
    {

    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        builder.HasDefaultSchema("Users");
        builder.ApplyConfigurationsFromAssembly(typeof(UsersContext).Assembly);
        base.OnModelCreating(builder);
    }

    public async Task<int> SaveChangesAsync()
    {
        return await base.SaveChangesAsync();
    }

    public new DbSet<TEntity> Set<TEntity>() where TEntity : class, IEntity
    {
        return base.Set<TEntity>();
    }
}
