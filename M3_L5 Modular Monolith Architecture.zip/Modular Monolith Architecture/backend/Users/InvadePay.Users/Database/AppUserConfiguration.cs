﻿using InvadePay.Users.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InvadePay.Users.Database;

public class AppUserConfiguration : IEntityTypeConfiguration<AppUser>
{
    public void Configure(EntityTypeBuilder<AppUser> builder)
    {
        builder.Property(x => x.FirstName)
            .IsRequired()
            .HasMaxLength(AppUser.MaxLengths.FirstName);
        
        builder.Property(x => x.LastName)
            .IsRequired()
            .HasMaxLength(AppUser.MaxLengths.LastName);
    }
}