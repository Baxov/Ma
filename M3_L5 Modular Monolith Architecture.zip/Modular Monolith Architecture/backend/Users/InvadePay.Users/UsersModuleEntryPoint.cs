﻿using FluentValidation;
using InvadePay.Common.Api;
using InvadePay.Common.Interceptors;
using InvadePay.Users.Database;
using InvadePay.Users.Features.ForgotPassword;
using InvadePay.Users.Features.Login;
using InvadePay.Users.Features.RefreshToken;
using InvadePay.Users.Features.Register;
using InvadePay.Users.Features.ResetPassword;
using InvadePay.Users.Models;
using InvadePay.Users.Shared;
using InvadePay.Users.Shared.Emailing;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace InvadePay.Users;

public static class UsersModuleEntryPoint
{
    public static IServiceCollection AddUsersModule(this IServiceCollection services, IConfiguration configuration)
    {
        ConfigureCustomOptions(services, configuration);
        ConfigureDependencyInjection(services);
        ConfigureDatabase(services);
        
        services.AddEndpoints(typeof(UsersModuleEntryPoint).Assembly);
        
        return services;
    }

    public static IApplicationBuilder UseUsersModule(this IApplicationBuilder app)
    {
        UseDatabase(app);
        return app;
    }
    
    private static void UseDatabase(IApplicationBuilder app)
    {
        if (app is not WebApplication webApplication)
        {
            throw new InvalidOperationException("UseDatabase can only be used with WebApplication");
        }

        using var scope = webApplication.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<UsersContext>();
        dbContext.Database.Migrate();
    }
    
    private static void ConfigureCustomOptions(IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<UserDatabaseOptions>()
            .Bind(configuration.GetSection("UsersDatabase"))
            .ValidateDataAnnotations();

        services.AddOptions<JwtOptions>()
            .Bind(configuration.GetSection("Jwt"))
            .ValidateDataAnnotations();
    }
    
    private static void ConfigureDatabase(IServiceCollection services)
    {
        services.AddDbContext<UsersContext>((serviceProvider, options) =>
        {
            var dbOptions = serviceProvider.GetRequiredService<IOptions<UserDatabaseOptions>>().Value;

            options.UseSqlServer(dbOptions.ConnectionString,
                    optionsActions =>
                    {
                        optionsActions.CommandTimeout(dbOptions.CommandTimeout);
                        optionsActions.EnableRetryOnFailure(dbOptions.MaxRetryCount);
                    })
                .AddInterceptors(serviceProvider.GetRequiredService<AuditInterceptor>());
        });
        
        services.AddIdentityCore<AppUser>()
            .AddEntityFrameworkStores<UsersContext>()
            .AddSignInManager()
            .AddDefaultTokenProviders();
    }

    private static void ConfigureDependencyInjection(IServiceCollection services)
    {
        services.AddScoped<UsersContext>();
        services.AddValidatorsFromAssemblyContaining<LoginValidator>();
        
        services.AddTransient<IUserEmailSender, LocalUserEmailSender>();

        services.AddTransient<RegisterUseCase>();
        services.AddTransient<LoginUseCase>();
        services.AddTransient<RefreshTokenUseCase>();
        services.AddTransient<ForgotPasswordUseCase>();
        services.AddTransient<ResetPasswordUseCase>();
        services.AddTransient<ITokenService, TokenService>();
        services.AddTransient<IUserService, UserService>();
    }
}