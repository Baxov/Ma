﻿using InvadePay.Common.Models;
using InvadePay.Users.Shared;

namespace InvadePay.Users.Features.Login;

public class LoginUseCase(IUserService userService, ITokenService tokenService)
{
    public async Task<Result<LoginResponse>> Execute(LoginRequest request)
    {
        var user = await userService.Login(request.Email, request.Password);

        if (user == null)
        {
            return Result.Unauthorized("Invalid email or password.");
        }

        var tokenResponse = await tokenService.GenerateAuthTokens(user);

        return new LoginResponse(user.Id, tokenResponse.AccessToken, tokenResponse.RefreshToken);
    }
}