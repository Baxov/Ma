﻿namespace InvadePay.Users.Features.Login;

public record LoginResponse(string UserId, string AccessToken, string RefreshToken);
