﻿namespace InvadePay.Users.Features.Login;

public record LoginRequest(string Email, string Password);