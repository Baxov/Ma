﻿using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Users.Features.Login;

public class LoginEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPost("/api/login", Login)
            .WithSummary("Authenticates a user and provides an access token upon successful login.")
            .Validator<LoginRequest>()
            .WithTags("Users")
            .AllowAnonymous();
    }
    
    private static async Task<IResult> Login(LoginRequest request, LoginUseCase useCase)
    {
        var result = await useCase.Execute(request);
        
        return result.IsSuccess
            ? TypedResults.Ok(result.Value)
            : Results.Json(new { Error = result.ErrorMessage, Code = "UNAUTHORIZED_ACCESS" }, statusCode: 401);
    }
}
