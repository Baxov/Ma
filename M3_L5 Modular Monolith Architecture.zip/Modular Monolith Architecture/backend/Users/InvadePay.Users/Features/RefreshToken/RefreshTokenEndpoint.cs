﻿using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Users.Features.RefreshToken;

public class RefreshTokenEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPost("/api/refresh-token", RefreshToken)
            .WithSummary("Refreshes an access token using a valid refresh token.")
            .Validator<RefreshTokenRequest>()
            .WithTags("Users")
            .AllowAnonymous();
    }
    
    private static async Task<IResult> RefreshToken(RefreshTokenRequest request, RefreshTokenUseCase useCase)
    {
        var result = await useCase.Execute(request);

        return result.IsSuccess
            ? TypedResults.Ok(result.Value)
            : Results.Json(new { Error = result.ErrorMessage, Code = "UNAUTHORIZED_ACCESS" }, statusCode: 401);
    }
}
