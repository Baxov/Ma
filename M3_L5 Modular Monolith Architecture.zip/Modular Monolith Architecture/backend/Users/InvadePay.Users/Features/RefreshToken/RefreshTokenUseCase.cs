﻿using InvadePay.Common.Models;
using InvadePay.Users.Shared;

namespace InvadePay.Users.Features.RefreshToken;

public class RefreshTokenUseCase(ITokenService tokenService)
{
    public async Task<Result<RefreshTokenResponse>> Execute(RefreshTokenRequest request)
    {
        var user = await tokenService.ValidateRefreshTokenAsync(request.UserId, request.RefreshToken);
        if (user == null)
        {
            return Result.Unauthorized("Invalid refresh token.");
        }

        var tokenResponse = await tokenService.GenerateAuthTokens(user);
            
        return tokenResponse;
    }
}