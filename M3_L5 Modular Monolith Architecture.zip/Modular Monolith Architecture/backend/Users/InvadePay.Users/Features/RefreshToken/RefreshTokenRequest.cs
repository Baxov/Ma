﻿namespace InvadePay.Users.Features.RefreshToken;

public record RefreshTokenRequest(string UserId, string RefreshToken);