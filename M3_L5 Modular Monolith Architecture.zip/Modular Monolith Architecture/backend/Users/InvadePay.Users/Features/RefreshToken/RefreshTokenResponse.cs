﻿namespace InvadePay.Users.Features.RefreshToken;

public record RefreshTokenResponse(string UserId, string AccessToken, string RefreshToken);
