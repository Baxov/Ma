﻿using InvadePay.Common.Models;
using InvadePay.Users.Shared;
using InvadePay.Users.Shared.Emailing;

namespace InvadePay.Users.Features.ForgotPassword;

public class ForgotPasswordUseCase(IUserService userService, IUserEmailSender emailSender)
{
    public async Task<Result<ForgotPasswordResponse>> Execute(ForgotPasswordRequest request)
    {
        var user = await userService.FindByEmail(request.Email);
        
        // Always return success to prevent email enumeration attacks
        if (user == null)
        {
            return new ForgotPasswordResponse("If an account with that email exists, a password reset link has been sent.");
        }

        var resetToken = await userService.GeneratePasswordResetToken(user);
        
        var result = await emailSender.SendPasswordResetEmail(user.Email!, resetToken);
        
        if (result.IsError)
        {
            return Result<ForgotPasswordResponse>.From(result);
        }
        
        return new ForgotPasswordResponse("If an account with that email exists, a password reset link has been sent.");
    }
}
