﻿namespace InvadePay.Users.Features.ForgotPassword;

public record ForgotPasswordResponse(string Message);
