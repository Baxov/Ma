﻿using InvadePay.Common.Api;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using InvadePay.Common.Filters;
using InvadePay.Users.Shared;

namespace InvadePay.Users.Features.ForgotPassword;

public class ForgotPasswordEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPost("/api/forgot-password", ForgotPassword)
            .WithSummary("Sends a password reset email to the user if the email exists.")
            .Validator<ForgotPasswordRequest>()
            .WithTags("Users")
            .AllowAnonymous()
            .RequireRateLimiting(Security.RateLimitPolicy);
    }
    
    private static async Task<IResult> ForgotPassword(ForgotPasswordRequest request, ForgotPasswordUseCase useCase)
    {
        var result = await useCase.Execute(request);

        return result.IsSuccess
            ? TypedResults.Ok(result.Value)
            : TypedResults.BadRequest(result.ErrorMessage);
    }
}
