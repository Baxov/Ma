﻿namespace InvadePay.Users.Features.ForgotPassword;

public record ForgotPasswordRequest(string Email);