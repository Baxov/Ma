﻿namespace InvadePay.Users.Features.ResetPassword;

public record ResetPasswordRequest(string Email, string Token, string NewPassword);