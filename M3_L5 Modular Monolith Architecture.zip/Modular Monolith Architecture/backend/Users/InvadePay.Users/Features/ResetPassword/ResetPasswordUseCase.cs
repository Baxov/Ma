﻿using InvadePay.Common.Models;
using InvadePay.Users.Shared;

namespace InvadePay.Users.Features.ResetPassword;

public class ResetPasswordUseCase(IUserService userService)
{
    public async Task<Result<ResetPasswordResponse>> Execute(ResetPasswordRequest request)
    {
        var user = await userService.FindByEmail(request.Email);
        
        if (user == null)
        {
            return Result.Error("Invalid reset token or email.");
        }

        var result = await userService.ResetPassword(user, request.Token, request.NewPassword);
        
        if (result.IsError)
        {
            return Result.Error("Invalid reset token or email.");
        }
        
        return new ResetPasswordResponse("Password has been reset successfully.");
    }
}
