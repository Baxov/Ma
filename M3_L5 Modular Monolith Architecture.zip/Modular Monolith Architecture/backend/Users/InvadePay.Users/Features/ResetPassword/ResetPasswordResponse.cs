﻿namespace InvadePay.Users.Features.ResetPassword;

public record ResetPasswordResponse(string Message);
