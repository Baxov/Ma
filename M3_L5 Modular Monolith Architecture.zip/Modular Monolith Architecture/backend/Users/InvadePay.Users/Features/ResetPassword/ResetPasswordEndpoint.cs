﻿using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Users.Features.ResetPassword;

public class ResetPasswordEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPost("/api/reset-password", ResetPassword)
            .WithSummary("Resets the user's password using a valid reset token.")
            .Validator<ResetPasswordRequest>()
            .WithTags("Users")
            .AllowAnonymous();
    }
    
    private static async Task<IResult> ResetPassword(ResetPasswordRequest request, ResetPasswordUseCase useCase)
    {
        var result = await useCase.Execute(request);

        return result.IsSuccess
            ? TypedResults.Ok(result.Value)
            : TypedResults.BadRequest(result.ErrorMessage);
    }
}
