﻿using FluentValidation;
using InvadePay.Users.Models;

namespace InvadePay.Users.Features.Register;

public class RegisterValidator : AbstractValidator<RegisterRequest>
{
    public RegisterValidator()
    {
        RuleFor(x => x.Email)
            .NotEmpty()
            .EmailAddress();

        RuleFor(x => x.Password)
            .MinimumLength(6)
            .NotEmpty();

        RuleFor(x => x.FirstName)
            .NotEmpty()
            .MaximumLength(AppUser.MaxLengths.FirstName);

        RuleFor(x => x.LastName)
            .NotEmpty()
            .MaximumLength(AppUser.MaxLengths.LastName);
    }
}
