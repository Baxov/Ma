﻿using InvadePay.Common.Api;
using InvadePay.Common.Filters;
using InvadePay.Common.Models;
using InvadePay.Users.Shared;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace InvadePay.Users.Features.Register;

public class RegisterEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPost("/api/register", Register)
            .WithSummary("Registers a new user account. Requires a username, password, and other necessary details.")
            .Validator<RegisterRequest>()
            .WithTags("Users")
            .AllowAnonymous()
            .RequireRateLimiting(Security.RateLimitPolicy);
    }
    
    private static async Task<Results<Ok<RegisterResponse>, BadRequest<string>, UnprocessableEntity<string>>> Register(RegisterRequest request, RegisterUseCase useCase)
    {
        var result = await useCase.Execute(request);
        
        return result switch
        {
            { IsSuccess: true } => TypedResults.Ok(result.Value),
            { IsError: true, Status: ResultStatus.Conflict } => TypedResults.BadRequest(result.ErrorMessage),
            { IsError: true, Status: ResultStatus.UnprocessableEntity } => TypedResults.UnprocessableEntity(result.ErrorMessage),
            _ => throw new NotImplementedException(),
        };
    }
}
