﻿namespace InvadePay.Users.Features.Register;

public record RegisterResponse(string UserId, string AccessToken, string RefreshToken);
