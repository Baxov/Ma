﻿namespace InvadePay.Users.Features.Register;

public record RegisterRequest(string Email, string FirstName, string LastName, string Password);