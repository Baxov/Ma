﻿using InvadePay.Common.Models;
using InvadePay.Users.Models;
using InvadePay.Users.Shared;
using InvadePay.Users.Shared.Emailing;

namespace InvadePay.Users.Features.Register;

public class RegisterUseCase(
    IUserService userService,
    ITokenService tokenService,
    IUserEmailSender emailSender)
{
    public async Task<Result<RegisterResponse>> Execute(RegisterRequest request)
    {
        var existingUser = await userService.FindByEmail(request.Email);
        if (existingUser != null)
        {
            return Result.Conflict("User with this email already exists.");
        }

        var user = new AppUser(request.Email, request.FirstName, request.LastName);

        var result = await userService.Register(user, request.Password);
        if (result.IsError)
        {
            return Result.UnprocessableEntity(result.ErrorMessage);
        }

        var tokenResponse = await tokenService.GenerateAuthTokens(user);

        await emailSender.SendWelcomeEmail(user.Email!);
        
        return new RegisterResponse(user.Id, tokenResponse.AccessToken, tokenResponse.RefreshToken);
    }
}