﻿using System.ComponentModel.DataAnnotations;

namespace InvadePay.Users.Shared;

public class JwtOptions
{
    [Required]
    public string Issuer { get; init; } = string.Empty;
    [Required]
    public string Audience { get; init; } = string.Empty;
    [Required]
    public string Key { get; init; } = string.Empty;
    [Required]
    public int ExpiryInMinutes { get; set; }
    [Required]
    public int RefreshTokenExpiryInMinutes { get; set; }
}
