namespace InvadePay.Users.Shared;

public static class Security
{
    public const string CorsPolicy = "OpenCorsPolicy";
    public const string RateLimitPolicy = "fixed";
}