﻿using InvadePay.Common.Models;
using InvadePay.Users.Models;

namespace InvadePay.Users.Shared;

public interface IUserService
{

    Task<AppUser?> FindByEmail(string email);

    Task<Result<string>> Register(AppUser user, string password);

    Task<AppUser?> Login(string email, string password);

    Task<string> GeneratePasswordResetToken(AppUser user);
    Task<Result<bool>> ResetPassword(AppUser user, string token, string newPassword);
}
