﻿using InvadePay.Common.Models;
using InvadePay.Users.Models;
using Microsoft.AspNetCore.Identity;

namespace InvadePay.Users.Shared;

public class UserService(UserManager<AppUser> userManager) : IUserService
{
    public Task<AppUser?> FindByEmail(string email)
    {
        return userManager.FindByEmailAsync(email);
    }

    public async Task<AppUser?> Login(string email, string password)
    {
        var user = await userManager.FindByEmailAsync(email);

        if (user == null)
        {
            return null;
        }

        var passwordMatch = await userManager.CheckPasswordAsync(user, password);

        return passwordMatch ? user : null;
    }

    public async Task<Result<string>> Register(AppUser user, string password)
    {
        var result = await userManager.CreateAsync(user, password);

        if (result.Succeeded)
        {
            return user.Id;
        }

        return Result.UnprocessableEntity(
            result.Errors.FirstOrDefault()?.Description ?? "User creation failed.");
    }

    public async Task<string> GeneratePasswordResetToken(AppUser user)
    {
        return await userManager.GeneratePasswordResetTokenAsync(user);
    }

    public async Task<Result<bool>> ResetPassword(AppUser user, string token, string newPassword)
    {
        var result = await userManager.ResetPasswordAsync(user, token, newPassword);

        if (result.Succeeded)
        {
            return true;
        }

        return Result.UnprocessableEntity(
            result.Errors.FirstOrDefault()?.Description ?? "Password reset failed.");
    }
}
