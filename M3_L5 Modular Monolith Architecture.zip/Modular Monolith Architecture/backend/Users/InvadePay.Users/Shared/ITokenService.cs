﻿using InvadePay.Users.Features.RefreshToken;
using InvadePay.Users.Models;

namespace InvadePay.Users.Shared;

public interface ITokenService
{
    Task<RefreshTokenResponse> GenerateAuthTokens(AppUser user);
    Task<AppUser?> ValidateRefreshTokenAsync(string userId, string refreshToken);
}