﻿using InvadePay.Common.Models;

namespace InvadePay.Users.Shared.Emailing;

public interface IUserEmailSender
{
    public Task SendWelcomeEmail(string email);
    public Task<Result> SendPasswordResetEmail(string email, string resetToken);
}