﻿using InvadePay.Common.Models;
using InvadePay.Common.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace InvadePay.Users.Shared.Emailing;

public class SendgridUserEmailSender(IOptions<EmailOptions> emailOptions, ILogger<SendgridUserEmailSender> logger)
    : IUserEmailSender
{
    private readonly EmailOptions _emailOptions = emailOptions.Value;

    private SendGridClient CreateClient()
    {
        if (string.IsNullOrEmpty(_emailOptions.SendGridApiKey))
        {
            throw new InvalidOperationException("SendGrid API key is required but not configured.");
        }

        return new SendGridClient(_emailOptions.SendGridApiKey);
    }

    public async Task SendWelcomeEmail(string email)
    {
        try
        {
            var client = CreateClient();
            var from = new EmailAddress(_emailOptions.FromEmail, _emailOptions.FromName);
            var to = new EmailAddress(email);
            var subject = "Welcome to InvadePay!";
            var htmlContent = $@"
                <html>
                <body>
                    <h2>Welcome to InvadePay!</h2>
                    <p>Thank you for registering with InvadePay. Your account has been successfully created.</p>
                    <br/>
                    <p>You can now start creating invoices and managing your payments.</p>
                    <br>
                    <p>Best regards,<br/><br/>The InvadePay Team</p>
                </body>
                </html>";

            var msg = MailHelper.CreateSingleEmail(from, to, subject, null, htmlContent);
            var response = await client.SendEmailAsync(msg);

            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Body.ReadAsStringAsync();
                logger.LogError("Failed to send welcome email to {Email}. Status: {Status}, Body: {Body}",
                    email, response.StatusCode, body);
                throw new InvalidOperationException($"Failed to send welcome email: {response.StatusCode}");
            }

            logger.LogInformation("Welcome email sent successfully to {Email}", email);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to send welcome email to {Email}", email);
        }
    }

    public async Task<Result> SendPasswordResetEmail(string email, string resetToken)
    {
        try
        {
            var encodedToken = Uri.EscapeDataString(resetToken);
            var resetUrl =
                $"{_emailOptions.FrontendUrl}/reset-password?email={Uri.EscapeDataString(email)}&token={encodedToken}";

            var client = CreateClient();
            var from = new EmailAddress(_emailOptions.FromEmail, _emailOptions.FromName);
            var to = new EmailAddress(email);
            var subject = "Reset Your InvadePay Password";
            var htmlContent = $@"
                <html>
                <body>
                    <h2>Reset Your InvadePay Password</h2>
                    <p>You have requested to reset your password for your InvadePay account.</p>
                    <p>Click the link below to reset your password:</p>
                    <p><a href=""{resetUrl}"" style=""background-color: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;"">Reset Password</a></p>
                    <p>If the button doesn't work, copy and paste this link into your browser:</p>
                    <p>{resetUrl}</p>
                    <p>This link will expire in 24 hours for security reasons.</p>
                    <p>If you didn't request this password reset, please ignore this email.</p>
                    <br>
                    <p>Best regards,<br/><br/>The InvadePay Team</p>
                </body>
                </html>";

            var msg = MailHelper.CreateSingleEmail(from, to, subject, null, htmlContent);
            var response = await client.SendEmailAsync(msg);

            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Body.ReadAsStringAsync();
                logger.LogError("Failed to send password reset email to {Email}. Status: {Status}, Body: {Body}",
                    email, response.StatusCode, body);
                return Result.Error("Failed to send password reset email.");
            }

            logger.LogInformation("Password reset email sent successfully to {Email}", email);
            return Result.Success();
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to send password reset email to {Email}", email);
            return Result.Error("Failed to send password reset email.");
        }
    }
}