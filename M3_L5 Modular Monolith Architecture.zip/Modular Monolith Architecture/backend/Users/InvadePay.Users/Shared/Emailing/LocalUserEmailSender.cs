using InvadePay.Common.Models;
using InvadePay.Common.Options;
using MailKit.Net.Smtp;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MimeKit;

namespace InvadePay.Users.Shared.Emailing;

public class LocalUserEmailSender(
    ILogger<LocalUserEmailSender> logger,
    IOptions<EmailOptions> emailOptions) : IUserEmailSender
{
    private readonly EmailOptions _emailOptions = emailOptions.Value;

    public async Task SendWelcomeEmail(string email)
    {
        try
        {
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(_emailOptions.FromName, _emailOptions.FromEmail));
            message.To.Add(new MailboxAddress("", email));
            message.Subject = "Welcome to InvadePay!";

            var bodyBuilder = new BodyBuilder
            {
                HtmlBody = $@"
                    <html>
                    <body>
                        <h2>Welcome to InvadePay!</h2>
                        <p>Thank you for registering with InvadePay. Your account has been successfully created.</p>
                        <br/>
                        <p>You can now start creating invoices and managing your payments.</p>
                        <br>
                        <p>Best regards,<br/><br/>The InvadePay Team</p>
                    </body>
                    </html>",
                TextBody = @"
                    Welcome to InvadePay!

                    Thank you for registering with InvadePay. Your account has been successfully created.
                    You can now start creating invoices and managing your payments.

                    Best regards,
                    The InvadePay Team"
            };

            message.Body = bodyBuilder.ToMessageBody();

            using var client = new SmtpClient();
            await client.ConnectAsync(_emailOptions.SmtpHost, _emailOptions.SmtpPort, false);
            await client.SendAsync(message);
            await client.DisconnectAsync(true);

            logger.LogInformation("Welcome email sent successfully to {Email}", email);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "An error occured while sending email");
        }
    }

    public async Task<Result> SendPasswordResetEmail(string email, string resetToken)
    {
        try
        {
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(_emailOptions.FromName, _emailOptions.FromEmail));
            message.To.Add(new MailboxAddress("", email));
            message.Subject = "Reset Your InvadePay Password";

            // URL encode the token for safe transmission
            var encodedToken = Uri.EscapeDataString(resetToken);
            var resetUrl = $"{_emailOptions.FrontendUrl}/reset-password?email={Uri.EscapeDataString(email)}&token={encodedToken}";

            var bodyBuilder = new BodyBuilder
            {
                HtmlBody = $@"
                    <html>
                    <body>
                        <h2>Reset Your InvadePay Password</h2>
                        <p>You have requested to reset your password for your InvadePay account.</p>
                        <p>Click the link below to reset your password:</p>
                        <p><a href=""{resetUrl}"" style=""background-color: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;"">Reset Password</a></p>
                        <p>If the button doesn't work, copy and paste this link into your browser:</p>
                        <p>{resetUrl}</p>
                        <p>This link will expire in 24 hours for security reasons.</p>
                        <p>If you didn't request this password reset, please ignore this email.</p>
                        <br>
                        <p>Best regards,<br/><br/>The InvadePay Team</p>
                    </body>
                    </html>",
                TextBody = $@"
                    Reset Your InvadePay Password

                    You have requested to reset your password for your InvadePay account.

                    Copy and paste this link into your browser to reset your password:
                    {resetUrl}

                    This link will expire in 24 hours for security reasons.

                    If you didn't request this password reset, please ignore this email.

                    Best regards,
                    The InvadePay Team"
            };

            message.Body = bodyBuilder.ToMessageBody();

            using var client = new SmtpClient();
            await client.ConnectAsync(_emailOptions.SmtpHost, _emailOptions.SmtpPort, false);
            await client.SendAsync(message);
            await client.DisconnectAsync(true);

            logger.LogInformation("Password reset email sent successfully to {Email}", email);

            return Result.Success();
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to send password reset email to {Email}", email);
            return Result.Error("Failed to send password reset email.");
        }
    }
}
