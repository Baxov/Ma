/**
 * Utility function to clean up any lingering modal/dialog overlays
 * This is particularly useful for Radix UI components that might leave
 * overlay elements in the DOM after closing
 */
export const cleanupModalOverlays = () => {
  // Remove any Radix UI overlay elements
  const radixOverlays = document.querySelectorAll(
    "[data-radix-alert-dialog-overlay], [data-radix-dialog-overlay], [data-radix-popover-content]"
  );
  radixOverlays.forEach((overlay) => overlay.remove());

  // Remove any Radix UI portals
  const radixPortals = document.querySelectorAll(
    "[data-radix-alert-dialog-portal], [data-radix-dialog-portal]"
  );
  radixPortals.forEach((portal) => portal.remove());

  // Remove any fixed overlay elements with high z-index
  const potentialOverlays = document.querySelectorAll(
    '.fixed.inset-0, [style*="position: fixed"][style*="inset: 0"]'
  );
  potentialOverlays.forEach((element) => {
    const styles = window.getComputedStyle(element);
    const zIndex = parseInt(styles.zIndex);

    // Remove if it has a high z-index and looks like an overlay
    if (
      zIndex >= 50 &&
      (styles.backgroundColor.includes("rgba") ||
        styles.backgroundColor.includes("rgb") ||
        element.classList.contains("z-50") ||
        element.classList.contains("bg-black"))
    ) {
      element.remove();
    }
  });

  // Reset body styles that might be set by modal libraries
  document.body.style.overflow = "";
  document.body.style.pointerEvents = "";
  document.body.style.paddingRight = "";

  // Remove common modal-related data attributes
  document.body.removeAttribute("data-scroll-locked");
  document.body.removeAttribute("data-radix-scroll-area-viewport");

  // Remove any classes that might disable scrolling
  document.body.classList.remove("overflow-hidden", "modal-open");

  // Force a reflow to ensure changes are applied
  void document.body.offsetHeight;
};

/**
 * Debounced version of cleanupModalOverlays to prevent excessive calls
 */
let cleanupTimeout: NodeJS.Timeout | null = null;

export const debouncedCleanupModalOverlays = (delay: number = 100) => {
  if (cleanupTimeout) {
    clearTimeout(cleanupTimeout);
  }

  cleanupTimeout = setTimeout(() => {
    cleanupModalOverlays();
    cleanupTimeout = null;
  }, delay);
};

/**
 * Set up a MutationObserver to watch for and remove any overlay elements
 * that might be added after our cleanup
 */
let overlayObserver: MutationObserver | null = null;

export const startOverlayWatcher = () => {
  if (overlayObserver) {
    overlayObserver.disconnect();
  }

  overlayObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          const element = node as Element;

          // Check if it's a potential overlay element
          if (
            element.hasAttribute("data-radix-alert-dialog-overlay") ||
            element.hasAttribute("data-radix-dialog-overlay") ||
            (element.classList.contains("fixed") &&
              element.classList.contains("inset-0") &&
              element.classList.contains("z-50"))
          ) {
            // Remove it after a short delay to allow for proper animations
            setTimeout(() => {
              if (element.parentNode) {
                element.remove();
              }
            }, 500);
          }
        }
      });
    });
  });

  overlayObserver.observe(document.body, {
    childList: true,
    subtree: true,
  });
};

export const stopOverlayWatcher = () => {
  if (overlayObserver) {
    overlayObserver.disconnect();
    overlayObserver = null;
  }
};
