"use client";

import { LoaderCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface SubmitButtonProps {
  isSubmitting: boolean;
  text: string;
  loadingText?: string;
}

export const SubmitButton = ({ isSubmitting, text, loadingText }: SubmitButtonProps) => {
  return (
    <Button
      className="relative w-full font-semibold bg-blue-600 hover:bg-blue-700"
      disabled={isSubmitting}
    >
      {isSubmitting ? (
        <div className="flex items-center gap-2">
          <LoaderCircle className="animate-spin h-4 w-4" />
          <span>{loadingText || text}</span>
        </div>
      ) : (
        <span>{text}</span>
      )}
    </Button>
  );
};
