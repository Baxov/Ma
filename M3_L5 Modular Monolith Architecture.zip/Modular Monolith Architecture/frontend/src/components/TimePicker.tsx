"use client";

import { type ChangeEvent, useState } from "react";
import { Input } from "@/components/ui/input";

interface TimePickerProps {
  value?: string;
  onChange?: (time: string) => void;
}

const formatCurrentTime = () => {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  return `${hours}:${minutes}`;
};

export default function TimePicker({ value, onChange }: TimePickerProps) {
  const [timeValue, setTimeValue] = useState(value || formatCurrentTime());

  const handleTimeChange = (e: ChangeEvent<HTMLInputElement>) => {
    const input = e.target.value;

    // Allow complete clearing of the input
    if (input === "") {
      setTimeValue("");
      onChange?.("");
      return;
    }

    // Handle backspace near colon
    if (input.length === timeValue.length - 1) {
      if (timeValue[input.length] === ":") {
        const newValue = input.slice(0, -1);
        setTimeValue(newValue);
        onChange?.(newValue);
        return;
      }
    }

    // Remove any non-digits except colon
    let value = input.replace(/[^0-9:]/g, "");

    // Format the time
    if (value.length === 2 && !value.includes(":")) {
      value = value + ":";
    }

    // Validate hours
    if (value.length >= 2) {
      const hours = parseInt(value.slice(0, 2));
      if (hours > 23) {
        value = "23" + value.slice(2);
      }
    }

    // Validate minutes
    if (value.length >= 5) {
      const minutes = parseInt(value.slice(3, 5));
      if (minutes > 59) {
        value = value.slice(0, 3) + "59";
      }
    }

    // Only update if the value is in valid format or empty
    if (value.length <= 5) {
      setTimeValue(value);
      onChange?.(value);
    }
  };

  return (
    <Input
      type="text"
      value={timeValue}
      onChange={handleTimeChange}
      pattern="^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$"
      placeholder="HH:mm"
      maxLength={5}
    />
  );
}
