import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

type InvoiceStatusType = "Draft" | "Sent" | "Paid" | "Reversed";

interface InvoiceStatusProps {
  status: InvoiceStatusType;
}

export function InvoiceStatus({ status }: InvoiceStatusProps) {
  return (
    <Badge
      className={cn(
        "rounded-full capitalize",
        status === "Draft" && "bg-black hover:bg-black/80",
        status === "Sent" && "bg-blue-500 hover:bg-blue-500/80",
        status === "Paid" && "bg-green-600 hover:bg-green-600/80",
        status === "Reversed" && "bg-red-600 hover:bg-red-600/80"
      )}
    >
      {status.toLowerCase()}
    </Badge>
  );
}
