import Container from "@/components/Container";

export const Footer = () => {
  return (
    <footer className="mt-12 mb-8">
      <Container className="flex justify-between gap-4">
        <p className="text-sm">InvadePay &copy; {new Date().getFullYear()}</p>
        <p className="text-sm">
          Created by Kristijan Kralj with .NET 9 & Next.js
        </p>
      </Container>
    </footer>
  );
};

export default Footer;
