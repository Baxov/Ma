"use client";

import Container from "@/components/Container";
import Link from "next/link";
import { LogoutButton } from "./LogoutButton";

export const Header = () => {
  return (
    <header className="mt-8 mb-12">
      <Container>
        <div className="flex justify-between items-center gap-4">
          <div className="flex items-center gap-5">
            <p className="font-bold">
              <Link className="text-slate-900" href="/dashboard">
                Dashboard
              </Link>
            </p>
            <p className="font-bold">
              <Link className="text-slate-900" href="/products">
                Products
              </Link>
            </p>
            <p className="font-bold">
              <Link className="text-slate-900" href="/customers">
                Customers
              </Link>
            </p>
            <p className="font-bold">
              <Link className="text-slate-900" href="/recurring-invoices">
                Recurring
              </Link>
            </p>
            <p className="font-bold">
              <Link className="text-slate-900" href="/settings">
                Settings
              </Link>
            </p>
          </div>
          <div>
            <LogoutButton />
          </div>
        </div>
        <div className="w-full border-b border-gray-200 mt-4" />
      </Container>
    </header>
  );
};
