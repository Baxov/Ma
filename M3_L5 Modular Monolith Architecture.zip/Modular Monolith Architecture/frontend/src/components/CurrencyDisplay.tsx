interface CurrencyDisplayProps {
  amount: number | null | undefined;
  locale?: string;
  currency?: string;
}

export function CurrencyDisplay({
  amount = 0,
  locale = "hr-HR",
  currency = "EUR",
}: CurrencyDisplayProps) {
  const safeAmount = amount ?? 0;

  return (
    <span>
      {safeAmount.toLocaleString(locale, {
        style: "currency",
        currency: currency,
      })}
    </span>
  );
}
