"use client";

import * as React from "react";
import { format } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

//datepicker props
export interface DatePickerProps {
  value?: Date;
  onChange?: (date: Date) => void;
}

const DatePicker = ({ value, onChange }: DatePickerProps) => {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant={"outline"}
          className={cn(
            "w-full justify-start text-left font-normal",
            !value && "text-muted-foreground"
          )}
        >
          <div className="flex w-full items-center justify-between">
            <CalendarIcon className="h-4 w-4" />
            <span className="mr-2">
              {value ? format(value, "PPP") : "Pick a date"}
            </span>
          </div>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0">
        <Calendar
          mode="single"
          selected={value}
          onSelect={(day) => day && onChange && onChange(day)}
          initialFocus
        />
      </PopoverContent>
    </Popover>
  );
};

export default DatePicker;
