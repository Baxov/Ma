﻿import { ReactNode } from "react";

interface AlertProps {
  type: "error" | "success" | "info";
  children: ReactNode;
}

export const Alert = ({ type, children }: AlertProps) => {
  const baseClasses = "rounded-md p-4";
  
  const typeClasses = {
    error: "bg-red-50 text-red-700",
    success: "bg-green-50 text-green-700", 
    info: "bg-blue-50 text-blue-700"
  };

  return (
    <div className={`${baseClasses} ${typeClasses[type]}`}>
      <div className="text-sm">{children}</div>
    </div>
  );
};
