﻿"use client";

import { useState, useEffect } from "react";
import { useRecurringInvoices } from "./hooks/useRecurringInvoices";
import { useDeleteRecurringInvoice } from "./hooks/useDeleteRecurringInvoice";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { CalendarDays, Clock, Mail, User } from "lucide-react";
import Link from "next/link";
import { format } from "date-fns";
import { debouncedCleanupModalOverlays } from "@/utils/overlayCleanup";

export default function RecurringInvoicesPage() {
  const [page, setPage] = useState(1);
  const pageSize = 10;
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedRecurringInvoiceId, setSelectedRecurringInvoiceId] = useState<
    number | null
  >(null);
  const [selectedRecurringInvoiceName, setSelectedRecurringInvoiceName] =
    useState<string>("");

  const { data, isLoading, error } = useRecurringInvoices(page, pageSize);
  const deleteMutation = useDeleteRecurringInvoice();

  // Clean up dialog state when component unmounts or data changes
  useEffect(() => {
    return () => {
      // Cleanup function to ensure dialog state is reset
      setDeleteDialogOpen(false);
      setSelectedRecurringInvoiceId(null);
      setSelectedRecurringInvoiceName("");

      // Force cleanup of any lingering overlay elements
      debouncedCleanupModalOverlays();
    };
  }, [data]);

  const handleDeleteClick = (id: number, customerName: string) => {
    setSelectedRecurringInvoiceId(id);
    setSelectedRecurringInvoiceName(customerName);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (selectedRecurringInvoiceId) {
      try {
        await deleteMutation.mutateAsync(selectedRecurringInvoiceId);
      } catch {
        // Error is handled by the mutation
      } finally {
        // Close dialog immediately
        setDeleteDialogOpen(false);

        // Use a longer timeout to ensure complete cleanup of portal and overlay
        setTimeout(() => {
          setSelectedRecurringInvoiceId(null);
          setSelectedRecurringInvoiceName("");

          // Force cleanup of any lingering overlays
          debouncedCleanupModalOverlays(500);
        }, 300); // Increased timeout to match animation duration
      }
    }
  };

  // Handle dialog close to ensure state is properly reset
  const handleDialogOpenChange = (open: boolean) => {
    setDeleteDialogOpen(open);
    if (!open) {
      // Reset state when dialog is closed
      setSelectedRecurringInvoiceId(null);
      setSelectedRecurringInvoiceName("");

      // Force cleanup of any lingering overlays after a short delay
      debouncedCleanupModalOverlays(200);
    }
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), "MMM dd, yyyy");
  };

  const getFrequencyColor = (frequency: string) => {
    switch (frequency.toLowerCase()) {
      case "weekly":
        return "bg-blue-100 text-blue-800";
      case "monthly":
        return "bg-green-100 text-green-800";
      case "quarterly":
        return "bg-purple-100 text-purple-800";
      case "yearly":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-8">
        <div className="space-y-6">
          <div>
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-4 w-96 mt-2" />
          </div>
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center space-x-4">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-4 w-48" />
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-32" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto py-8">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-red-600">Failed to load recurring invoices</p>
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => window.location.reload()}
              >
                Try Again
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const totalPages = Math.ceil((data?.totalCount || 0) / pageSize);

  return (
    <div className="container mx-auto py-8">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              Recurring Invoices
            </h1>
            <p className="text-muted-foreground">
              Manage your automated invoice schedules
            </p>
          </div>
          <Button asChild>
            <Link href="/recurring-invoices/create">
              Create Recurring Invoice
            </Link>
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <CalendarDays className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Total Recurring</p>
                  <p className="text-2xl font-bold">{data?.totalCount || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 text-green-600" />
                <div>
                  <p className="text-sm font-medium">Active</p>
                  <p className="text-2xl font-bold text-green-600">
                    {data?.items.filter((item) => item.isActive).length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 text-gray-600" />
                <div>
                  <p className="text-sm font-medium">Inactive</p>
                  <p className="text-2xl font-bold text-gray-600">
                    {data?.items.filter((item) => !item.isActive).length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <CalendarDays className="h-4 w-4 text-blue-600" />
                <div>
                  <p className="text-sm font-medium">Due Soon</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {data?.items.filter(
                      (item) =>
                        item.nextRunDate &&
                        new Date(item.nextRunDate) <=
                          new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
                    ).length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recurring Invoices Table */}
        <Card>
          <CardHeader>
            <CardTitle>Recurring Invoice Schedules</CardTitle>
            <CardDescription>
              View and manage your automated invoice schedules
            </CardDescription>
          </CardHeader>
          <CardContent>
            {data?.items.length === 0 ? (
              <div className="text-center py-8">
                <CalendarDays className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">
                  No recurring invoices
                </h3>
                <p className="text-muted-foreground mb-4">
                  Create your first recurring invoice to automate your billing
                  process.
                </p>
                <Button asChild>
                  <Link href="/recurring-invoices/create">
                    Create Recurring Invoice
                  </Link>
                </Button>
              </div>
            ) : (
              <>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Customer</TableHead>
                      <TableHead>Frequency</TableHead>
                      <TableHead>Next Run</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Tax</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data?.items.map((recurringInvoice) => (
                      <TableRow key={recurringInvoice.id}>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="flex items-center space-x-2">
                              <User className="h-4 w-4 text-muted-foreground" />
                              <span className="font-medium">
                                {recurringInvoice.customerName}
                              </span>
                            </div>
                            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                              <Mail className="h-3 w-3" />
                              <span>{recurringInvoice.customerEmail}</span>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="secondary"
                            className={getFrequencyColor(
                              recurringInvoice.frequency
                            )}
                          >
                            {recurringInvoice.frequency}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {recurringInvoice.nextRunDate ? (
                            <div className="space-y-1">
                              <div className="font-medium">
                                {formatDate(recurringInvoice.nextRunDate)}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                Started:{" "}
                                {formatDate(recurringInvoice.startDate)}
                              </div>
                            </div>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              recurringInvoice.isActive
                                ? "default"
                                : "secondary"
                            }
                          >
                            {recurringInvoice.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {recurringInvoice.taxName || (
                            <span className="text-muted-foreground">
                              No tax
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                className="bg-gray-50 cursor-pointer"
                                variant="outline"
                              >
                                Actions
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent className="bg-gray-50">
                              <DropdownMenuItem className="cursor-pointer">
                                <Link
                                  className="w-full"
                                  href={`/recurring-invoices/${recurringInvoice.id}`}
                                >
                                  View
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem className="cursor-pointer">
                                <Link
                                  className="w-full"
                                  href={`/recurring-invoices/${recurringInvoice.id}/edit`}
                                >
                                  Edit
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="cursor-pointer text-destructive focus:text-destructive"
                                onClick={() =>
                                  handleDeleteClick(
                                    recurringInvoice.id,
                                    recurringInvoice.customerName
                                  )
                                }
                              >
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-between mt-6">
                    <div className="text-sm text-muted-foreground">
                      Showing {(page - 1) * pageSize + 1} to{" "}
                      {Math.min(page * pageSize, data?.totalCount || 0)} of{" "}
                      {data?.totalCount || 0} results
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setPage(page - 1)}
                        disabled={page <= 1}
                      >
                        Previous
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setPage(page + 1)}
                        disabled={page >= totalPages}
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Delete Confirmation Dialog - Only render when we have a selected invoice */}
      {selectedRecurringInvoiceId && (
        <AlertDialog
          key={`delete-${selectedRecurringInvoiceId}`}
          open={deleteDialogOpen}
          onOpenChange={handleDialogOpenChange}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Recurring Invoice</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete the recurring invoice for{" "}
                <strong>{selectedRecurringInvoiceName}</strong>? This action
                cannot be undone. The scheduled job will be removed and no
                future invoices will be generated automatically.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDeleteConfirm}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                disabled={deleteMutation.isPending}
              >
                {deleteMutation.isPending ? "Deleting..." : "Delete"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}
