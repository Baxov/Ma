﻿"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { useRecurringInvoice } from "../../hooks/useRecurringInvoice";
import { useUpdateRecurringInvoice } from "../../hooks/useUpdateRecurringInvoice";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Save, Calendar } from "lucide-react";
import Link from "next/link";
import DatePicker from "@/components/DatePicker";
import { format } from "date-fns";
import { formatDateForApi, formatOptionalDateForApi } from "@/lib/dateUtils";

export default function EditRecurringInvoicePage() {
  const params = useParams();
  const router = useRouter();
  const id = parseInt(params.id as string);
  
  const { data: recurringInvoice, isLoading, error } = useRecurringInvoice(id);
  const updateMutation = useUpdateRecurringInvoice();

  // Form state
  const [frequency, setFrequency] = useState<"Weekly" | "Monthly" | "Quarterly" | "Yearly">("Monthly");
  const [startDate, setStartDate] = useState<Date>(new Date());
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [isActive, setIsActive] = useState(true);

  // Initialize form with existing data
  useEffect(() => {
    if (recurringInvoice) {
      setFrequency(recurringInvoice.frequency as "Weekly" | "Monthly" | "Quarterly" | "Yearly");
      setStartDate(new Date(recurringInvoice.startDate));
      setEndDate(recurringInvoice.endDate ? new Date(recurringInvoice.endDate) : undefined);
      setIsActive(recurringInvoice.isActive);
    }
  }, [recurringInvoice]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!recurringInvoice) return;

    try {
      await updateMutation.mutateAsync({
        id: recurringInvoice.id,
        data: {
          frequency,
          startDate: formatDateForApi(startDate),
          endDate: formatOptionalDateForApi(endDate),
          isActive,
        },
      });

      router.push(`/recurring-invoices/${recurringInvoice.id}`);
    } catch {
      // Error is handled by the mutation
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-8">
        <div className="space-y-6">
          <div className="flex items-center space-x-4">
            <Skeleton className="h-10 w-10" />
            <div>
              <Skeleton className="h-8 w-64" />
              <Skeleton className="h-4 w-96 mt-2" />
            </div>
          </div>
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48" />
              <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="space-y-2">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (error || !recurringInvoice) {
    return (
      <div className="container mx-auto py-8">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-red-600">Failed to load recurring invoice</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => window.location.reload()}
              >
                Try Again
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" asChild>
            <Link href={`/recurring-invoices/${recurringInvoice.id}`}>
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              Edit Recurring Invoice
            </h1>
            <p className="text-muted-foreground">
              Update the schedule for {recurringInvoice.customerName}
            </p>
          </div>
        </div>

        {/* Customer Info Card */}
        <Card>
          <CardHeader>
            <CardTitle>Customer Information</CardTitle>
            <CardDescription>
              This information cannot be changed for existing recurring invoices
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Customer Name</Label>
                <p className="text-lg font-medium">{recurringInvoice.customerName}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Email</Label>
                <p className="text-lg font-medium">{recurringInvoice.customerEmail}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Edit Form */}
        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle>Schedule Settings</CardTitle>
              <CardDescription>
                Update the frequency and dates for this recurring invoice
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Active Status */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Active Status</Label>
                  <div className="text-sm text-muted-foreground">
                    {isActive 
                      ? "This recurring invoice will generate new invoices automatically" 
                      : "This recurring invoice is paused and will not generate new invoices"
                    }
                  </div>
                </div>
                <Switch
                  checked={isActive}
                  onCheckedChange={setIsActive}
                />
              </div>

              {/* Frequency */}
              <div className="space-y-2">
                <Label htmlFor="frequency">Frequency</Label>
                <Select
                  value={frequency}
                  onValueChange={(value) => 
                    setFrequency(value as "Weekly" | "Monthly" | "Quarterly" | "Yearly")
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Weekly">Weekly</SelectItem>
                    <SelectItem value="Monthly">Monthly</SelectItem>
                    <SelectItem value="Quarterly">Quarterly</SelectItem>
                    <SelectItem value="Yearly">Yearly</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Start Date */}
              <div className="space-y-2">
                <Label>Start Date</Label>
                <DatePicker
                  value={startDate}
                  onChange={setStartDate}
                />
                <div className="text-sm text-muted-foreground">
                  The date when this recurring schedule should begin
                </div>
              </div>

              {/* End Date */}
              <div className="space-y-2">
                <Label>End Date (Optional)</Label>
                <DatePicker
                  value={endDate}
                  onChange={setEndDate}
                />
                <div className="text-sm text-muted-foreground">
                  Leave empty for indefinite recurring. The schedule will stop after this date.
                </div>
              </div>

              {/* Current Schedule Info */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Calendar className="h-4 w-4 text-blue-600" />
                  <span className="font-medium text-blue-900">Current Schedule</span>
                </div>
                <div className="text-sm text-blue-800 space-y-1">
                  <p>
                    <strong>Next Invoice:</strong> {
                      recurringInvoice.nextRunDate 
                        ? format(new Date(recurringInvoice.nextRunDate), "MMM dd, yyyy")
                        : "Not scheduled"
                    }
                  </p>
                  <p>
                    <strong>Current Status:</strong> {recurringInvoice.isActive ? "Active" : "Inactive"}
                  </p>
                  <p className="mt-2 text-xs">
                    Changes will take effect immediately and may reschedule the next invoice generation.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end space-x-4 pt-6">
                <Button variant="outline" asChild>
                  <Link href={`/recurring-invoices/${recurringInvoice.id}`}>
                    Cancel
                  </Link>
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateMutation.isPending}
                >
                  {updateMutation.isPending ? (
                    <>Saving...</>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </form>
      </div>
    </div>
  );
}
