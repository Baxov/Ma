﻿"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useRecurringInvoice } from "../hooks/useRecurringInvoice";
import { useDeleteRecurringInvoice } from "../hooks/useDeleteRecurringInvoice";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ArrowLeft,
  CalendarDays,
  Clock,
  User,
  Edit,
  Package,
  DollarSign,
} from "lucide-react";
import Link from "next/link";
import { format } from "date-fns";
import { debouncedCleanupModalOverlays } from "@/utils/overlayCleanup";

export default function RecurringInvoiceDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id = parseInt(params.id as string);

  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const { data: recurringInvoice, isLoading, error } = useRecurringInvoice(id);
  const deleteMutation = useDeleteRecurringInvoice();

  const handleDelete = async () => {
    try {
      await deleteMutation.mutateAsync(id);
      router.push("/recurring-invoices");
    } catch {
      // Error is handled by the mutation
    } finally {
      // Close dialog immediately
      setShowDeleteDialog(false);

      // Force cleanup of any lingering overlays
      debouncedCleanupModalOverlays(300);
    }
  };

  // Handle dialog close to ensure state is properly reset
  const handleDialogOpenChange = (open: boolean) => {
    setShowDeleteDialog(open);
    if (!open) {
      // Force cleanup of any lingering overlays
      debouncedCleanupModalOverlays(200);
    }
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), "MMM dd, yyyy");
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("hr-HR", {
      style: "currency",
      currency: "EUR",
    }).format(amount);
  };

  const getFrequencyColor = (frequency: string) => {
    switch (frequency.toLowerCase()) {
      case "weekly":
        return "bg-blue-100 text-blue-800";
      case "monthly":
        return "bg-green-100 text-green-800";
      case "quarterly":
        return "bg-purple-100 text-purple-800";
      case "yearly":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-8">
        <div className="space-y-6">
          <div className="flex items-center space-x-4">
            <Skeleton className="h-10 w-10" />
            <div>
              <Skeleton className="h-8 w-64" />
              <Skeleton className="h-4 w-96 mt-2" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="flex justify-between">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-4 w-32" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="flex justify-between">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-4 w-32" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (error || !recurringInvoice) {
    return (
      <div className="container mx-auto py-8">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-red-600">Failed to load recurring invoice</p>
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => window.location.reload()}
              >
                Try Again
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const subtotal = recurringInvoice.items.reduce(
    (sum, item) => sum + item.total,
    0
  );
  const taxAmount = recurringInvoice.taxRate
    ? (subtotal * recurringInvoice.taxRate) / 100
    : 0;
  const total = subtotal + taxAmount;

  return (
    <div className="container mx-auto py-8">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/recurring-invoices">
                <ArrowLeft className="h-4 w-4" />
              </Link>
            </Button>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">
                Recurring Invoice #{recurringInvoice.id}
              </h1>
              <p className="text-muted-foreground">
                Automated invoice schedule for {recurringInvoice.customerName}
              </p>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" asChild>
              <Link href={`/recurring-invoices/${recurringInvoice.id}/edit`}>
                <Edit className="h-4 w-4 mr-2" />
                Edit Schedule
              </Link>
            </Button>
            <Button
              variant="destructive"
              onClick={() => setShowDeleteDialog(true)}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </div>
        </div>

        {/* Status and Frequency */}
        <div className="flex items-center space-x-4">
          <Badge
            variant={recurringInvoice.isActive ? "default" : "secondary"}
            className="text-sm"
          >
            {recurringInvoice.isActive ? "Active" : "Inactive"}
          </Badge>
          <Badge
            variant="secondary"
            className={`text-sm ${getFrequencyColor(
              recurringInvoice.frequency
            )}`}
          >
            {recurringInvoice.frequency}
          </Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Customer & Schedule Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <User className="h-5 w-5" />
                <span>Customer & Schedule</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Customer Name:</span>
                <span className="font-medium">
                  {recurringInvoice.customerName}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Email:</span>
                <span className="font-medium">
                  {recurringInvoice.customerEmail}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Frequency:</span>
                <Badge
                  variant="secondary"
                  className={getFrequencyColor(recurringInvoice.frequency)}
                >
                  {recurringInvoice.frequency}
                </Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Start Date:</span>
                <span className="font-medium">
                  {formatDate(recurringInvoice.startDate)}
                </span>
              </div>
              {recurringInvoice.endDate && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">End Date:</span>
                  <span className="font-medium">
                    {formatDate(recurringInvoice.endDate)}
                  </span>
                </div>
              )}
              {recurringInvoice.nextRunDate && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Next Invoice:</span>
                  <div className="flex items-center space-x-2">
                    <CalendarDays className="h-4 w-4 text-blue-600" />
                    <span className="font-medium text-blue-600">
                      {formatDate(recurringInvoice.nextRunDate)}
                    </span>
                  </div>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">Invoice Time:</span>
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4" />
                  <span className="font-medium">{recurringInvoice.time}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tax & Totals */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <DollarSign className="h-5 w-5" />
                <span>Tax & Totals</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal:</span>
                <span className="font-medium">{formatCurrency(subtotal)}</span>
              </div>
              {recurringInvoice.taxName && (
                <>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      Tax ({recurringInvoice.taxName}):
                    </span>
                    <span className="font-medium">
                      {recurringInvoice.taxRate}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tax Amount:</span>
                    <span className="font-medium">
                      {formatCurrency(taxAmount)}
                    </span>
                  </div>
                </>
              )}
              <div className="border-t pt-4">
                <div className="flex justify-between">
                  <span className="text-lg font-semibold">Total:</span>
                  <span className="text-lg font-bold">
                    {formatCurrency(total)}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Invoice Items */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Package className="h-5 w-5" />
              <span>Invoice Items Template</span>
            </CardTitle>
            <CardDescription>
              These items will be included in each generated invoice
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead className="text-right">Quantity</TableHead>
                  <TableHead className="text-right">Price</TableHead>
                  <TableHead className="text-right">Discount</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recurringInvoice.items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">
                      {item.productName}
                    </TableCell>
                    <TableCell className="text-right">
                      {item.quantity}
                    </TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(item.price)}
                    </TableCell>
                    <TableCell className="text-right">
                      {item.discount ? `${item.discount}%` : "-"}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {formatCurrency(item.total)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Delete Confirmation Dialog - Only render when dialog should be shown */}
      {showDeleteDialog && (
        <AlertDialog
          key={`delete-dialog-${id}-${Date.now()}`}
          open={showDeleteDialog}
          onOpenChange={handleDialogOpenChange}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Recurring Invoice</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete this recurring invoice? This
                action cannot be undone. The scheduled job will be removed and
                no future invoices will be generated automatically.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                disabled={deleteMutation.isPending}
              >
                {deleteMutation.isPending ? "Deleting..." : "Delete"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}
