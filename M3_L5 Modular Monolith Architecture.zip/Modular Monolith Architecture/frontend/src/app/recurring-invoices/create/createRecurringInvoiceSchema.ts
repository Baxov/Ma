﻿import { z } from "zod";

export const createRecurringInvoiceLineSchema = z.object({
  productId: z.number().int().positive("Product is required."),
  quantity: z.number().min(1, "Quantity must be at least 1."),
  price: z.number().min(0, "Price must be positive."),
  discount: z
    .number()
    .min(0, "Discount must be positive.")
    .optional()
    .default(0),
});

export const createRecurringInvoiceSchema = z.object({
  customerId: z.number().int().positive("Customer is required."),
  time: z
    .string()
    .regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Invalid time format."),
  frequency: z.enum(["Weekly", "Monthly", "Quarterly", "Yearly"], {
    required_error: "Frequency is required.",
  }),
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Start date must be in YYYY-MM-DD format."),
  endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "End date must be in YYYY-MM-DD format.").optional(),
  items: z
    .array(createRecurringInvoiceLineSchema)
    .min(1, "At least one item is required."),
  taxId: z.number().int().positive().optional(),
}).refine((data) => {
  if (data.endDate && data.startDate) {
    return new Date(data.endDate) > new Date(data.startDate);
  }
  return true;
}, {
  message: "End date must be after start date",
  path: ["endDate"],
});

export type CreateRecurringInvoiceSchema = z.infer<typeof createRecurringInvoiceSchema>;
export type CreateRecurringInvoiceLineSchema = z.infer<typeof createRecurringInvoiceLineSchema>;
