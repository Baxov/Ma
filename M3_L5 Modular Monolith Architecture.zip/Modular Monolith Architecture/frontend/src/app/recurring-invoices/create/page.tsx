﻿"use client";

import Form from "next/form";
import { type SyntheticEvent, useState, useMemo } from "react";

import useCustomers from "@/app/customers/hooks/useCustomers";
import { CreateCustomerDialog } from "@/app/customers/CreateCustomerDialog";
import { useCreateRecurringInvoice } from "@/app/recurring-invoices/hooks/useCreateRecurringInvoice";
import useProducts from "@/app/products/hooks/useProducts";
import useTaxes from "@/app/settings/hooks/useTaxes";
import { ProtectedRoute } from "@/auth/ProtectedRoute";
import Container from "@/components/Container";
import { CurrencyDisplay } from "@/components/CurrencyDisplay";
import DatePicker from "@/components/DatePicker";
import { SubmitButton } from "@/components/SubmitButton";
import TimePicker from "@/components/TimePicker";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import axios from "axios";
import { Check, ChevronsUpDown } from "lucide-react";
import { useRouter } from "next/navigation";
import { z } from "zod";
import { createRecurringInvoiceSchema } from "./createRecurringInvoiceSchema";
import {
  InvoiceLineItemsTable,
  type InvoiceLineItemData,
} from "../../invoices/create/InvoiceLineItem";
import { formatDateForApi, formatOptionalDateForApi } from "@/lib/dateUtils";

function formatCurrentTime() {
  const now = new Date();
  const hours = now.getHours().toString().padStart(2, "0");
  const minutes = now.getMinutes().toString().padStart(2, "0");
  return `${hours}:${minutes}`;
}

export default function CreateRecurringInvoice() {
  const [error, setError] = useState<string>();
  const [success, setSuccess] = useState<boolean>();
  const [time, setTime] = useState(formatCurrentTime());
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState<Date>();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const router = useRouter();
  const createRecurringInvoice = useCreateRecurringInvoice();
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>();
  const [isCustomerOpen, setIsCustomerOpen] = useState(false);
  const [selectedTaxId, setSelectedTaxId] = useState<string>();
  const [isTaxOpen, setIsTaxOpen] = useState(false);
  const [frequency, setFrequency] = useState<
    "Weekly" | "Monthly" | "Quarterly" | "Yearly"
  >();

  const { data: customersData } = useCustomers(1, 100);
  const { data: taxesData } = useTaxes(1, 100);

  const customers = useMemo(() => {
    return customersData?.items || [];
  }, [customersData?.items]);

  const [lineItems, setLineItems] = useState<InvoiceLineItemData[]>([
    {
      id: crypto.randomUUID(),
      productId: undefined,
      quantity: 1,
      price: 0,
      discount: 0,
      discountEnabled: false,
    },
  ]);

  const { data: productsData } = useProducts(1, 100); // Fetch first 100 products
  const products = productsData?.items || [];

  const taxes = useMemo(() => {
    return taxesData?.items || [];
  }, [taxesData?.items]);

  const selectedCustomer = useMemo(() => {
    return customers.find(
      (customer) => customer.id.toString() === selectedCustomerId
    );
  }, [customers, selectedCustomerId]);

  const selectedTax = useMemo(() => {
    return taxes.find((tax) => tax.id.toString() === selectedTaxId);
  }, [taxes, selectedTaxId]);

  const subtotal = useMemo(() => {
    return lineItems.reduce((sum, item) => {
      if (item.productId) {
        const itemSubtotal = item.quantity * item.price;
        const discountAmount =
          item.discountEnabled && item.discount > 0
            ? (itemSubtotal * item.discount) / 100
            : 0;
        return sum + (itemSubtotal - discountAmount);
      }
      return sum;
    }, 0);
  }, [lineItems]);

  const taxAmount = useMemo(() => {
    return selectedTax ? (subtotal * selectedTax.rate) / 100 : 0;
  }, [subtotal, selectedTax]);

  const total = subtotal + taxAmount;

  // Line item management functions
  const updateLineItem = (
    id: string,
    updates: Partial<InvoiceLineItemData>
  ) => {
    setLineItems(
      lineItems.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
  };

  const removeLineItem = (id: string) => {
    if (lineItems.length > 1) {
      setLineItems(lineItems.filter((item) => item.id !== id));
    }
  };

  const addLineItem = () => {
    setLineItems([
      ...lineItems,
      {
        id: crypto.randomUUID(),
        productId: undefined,
        quantity: 1,
        price: 0,
        discount: 0,
        discountEnabled: false,
      },
    ]);
  };

  async function handleOnSubmit(event: SyntheticEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsSubmitting(true);
    setError(undefined);
    setSuccess(false);

    try {
      // Validate line items
      const items = lineItems.map((item) => ({
        productId: item.productId!,
        quantity: item.quantity,
        price: item.price,
        discount: item.discountEnabled ? item.discount : 0,
      }));

      if (!selectedCustomerId) {
        setError("Please select a customer");
        return;
      }

      const validatedData = createRecurringInvoiceSchema.parse({
        customerId: Number(selectedCustomerId),
        time: time,
        frequency: frequency,
        startDate: formatDateForApi(startDate),
        endDate: formatOptionalDateForApi(endDate),
        items: items,
        ...(selectedTaxId && { taxId: Number(selectedTaxId) }),
      });

      // If validation passes, proceed with the API call
      await createRecurringInvoice.mutateAsync(validatedData);
      setSuccess(true);
      setError(undefined);
      setTimeout(() => {
        router.push("/recurring-invoices");
      }, 3000);
    } catch (error) {
      if (error instanceof z.ZodError) {
        // Handle Zod validation errors
        setError(error.errors.map((err) => `• ${err.message}`).join("\n"));
      } else if (axios.isAxiosError(error)) {
        const errors = error.response?.data;
        if (Array.isArray(errors)) {
          setError(errors.map((err: string) => `• ${err}`).join("\n"));
        } else {
          setError("An error occurred");
        }
      } else {
        setError("An unexpected error occurred");
      }
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <ProtectedRoute>
      <Container>
        <div className="space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              Create Recurring Invoice
            </h1>
            <p className="text-muted-foreground">
              Set up an automated invoice schedule
            </p>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative">
              <strong className="font-bold">Error: </strong>
              <span className="block sm:inline whitespace-pre-line">
                {error}
              </span>
            </div>
          )}

          {success && (
            <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded relative">
              <strong className="font-bold">Success! </strong>
              <span className="block sm:inline">
                Recurring invoice created successfully. Redirecting...
              </span>
            </div>
          )}

          <Form
            action="/recurring-invoices"
            onSubmit={handleOnSubmit}
            className="grid gap-4"
          >
            {/* Basic Form Fields - Constrained Width */}
            <div className="max-w-xl space-y-4">
              {/* Customer Selection */}
              <div>
                <Label className="block font-semibold text-sm mb-2">
                  Customer
                </Label>
                <div className="flex gap-2">
                  <Popover
                    open={isCustomerOpen}
                    onOpenChange={setIsCustomerOpen}
                  >
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={isCustomerOpen}
                        className="flex-1 justify-between"
                      >
                        {selectedCustomer
                          ? `${selectedCustomer.name} (${selectedCustomer.email})`
                          : "Select customer..."}
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0">
                      <Command>
                        <CommandInput placeholder="Search customers..." />
                        <CommandEmpty>No customer found.</CommandEmpty>
                        <CommandGroup>
                          {customers.map((customer) => (
                            <CommandItem
                              key={customer.id}
                              value={`${customer.name} ${customer.email}`}
                              onSelect={() => {
                                setSelectedCustomerId(customer.id.toString());
                                setIsCustomerOpen(false);
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  selectedCustomerId === customer.id.toString()
                                    ? "opacity-100"
                                    : "opacity-0"
                                )}
                              />
                              {customer.name} ({customer.email})
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  <CreateCustomerDialog
                    buttonVariant="icon"
                    onCustomerCreated={(customer) => {
                      setSelectedCustomerId(customer.id.toString());
                    }}
                  />
                </div>
              </div>

              {/* Recurring Settings */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="block font-semibold text-sm mb-2">
                    Frequency
                  </Label>
                  <Select
                    value={frequency}
                    onValueChange={(
                      value: "Weekly" | "Monthly" | "Quarterly" | "Yearly"
                    ) => setFrequency(value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select frequency..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Weekly">Weekly</SelectItem>
                      <SelectItem value="Monthly">Monthly</SelectItem>
                      <SelectItem value="Quarterly">Quarterly</SelectItem>
                      <SelectItem value="Yearly">Yearly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label
                    htmlFor="time"
                    className="block font-semibold text-sm mb-2"
                  >
                    Time
                  </Label>
                  <TimePicker value={time} onChange={setTime} />
                </div>
              </div>

              {/* Date Settings */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="block font-semibold text-sm mb-2">
                    Start Date
                  </Label>
                  <DatePicker value={startDate} onChange={setStartDate} />
                </div>
                <div>
                  <Label className="block font-semibold text-sm mb-2">
                    End Date (Optional)
                  </Label>
                  <DatePicker value={endDate} onChange={setEndDate} />
                </div>
              </div>

              {/* Tax Selection */}
              <div>
                <Label className="block font-semibold text-sm mb-2">
                  Tax (Optional)
                </Label>
                <Popover open={isTaxOpen} onOpenChange={setIsTaxOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={isTaxOpen}
                      className="w-full justify-between"
                    >
                      {selectedTax
                        ? `${selectedTax.name} (${selectedTax.rate}%)`
                        : "Select tax..."}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-full p-0">
                    <Command>
                      <CommandInput placeholder="Search taxes..." />
                      <CommandEmpty>No tax found.</CommandEmpty>
                      <CommandGroup>
                        {taxes.map((tax) => (
                          <CommandItem
                            key={tax.id}
                            value={`${tax.name} ${tax.rate}`}
                            onSelect={() => {
                              setSelectedTaxId(tax.id.toString());
                              setIsTaxOpen(false);
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                selectedTaxId === tax.id.toString()
                                  ? "opacity-100"
                                  : "opacity-0"
                              )}
                            />
                            {tax.name} ({tax.rate}%)
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            {/* Invoice Items */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Invoice Items</h3>
                <Button
                  type="button"
                  onClick={addLineItem}
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2"
                >
                  <span className="text-lg">+</span>
                  Add Item
                </Button>
              </div>
              <InvoiceLineItemsTable
                lineItems={lineItems}
                products={products}
                onUpdate={updateLineItem}
                onRemove={removeLineItem}
              />
            </div>

            {/* Total Display */}
            <div className="border-t pt-4">
              <div className="text-right space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>
                    <CurrencyDisplay amount={subtotal} />
                  </span>
                </div>
                {selectedTax && (
                  <div className="flex justify-between">
                    <span>
                      Tax ({selectedTax.name} - {selectedTax.rate}%):
                    </span>
                    <span>
                      <CurrencyDisplay amount={taxAmount} />
                    </span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>Total:</span>
                  <span>
                    <CurrencyDisplay amount={total} />
                  </span>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex justify-end">
              <SubmitButton
                isSubmitting={isSubmitting}
                text="Create Recurring Invoice"
                loadingText="Creating..."
              />
            </div>
          </Form>
        </div>
      </Container>
    </ProtectedRoute>
  );
}
