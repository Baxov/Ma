﻿import { useQuery } from "@tanstack/react-query";
import ApiClient from "@/services/apiClient";

interface RecurringInvoiceItem {
  id: number;
  productId: number;
  productName: string;
  quantity: number;
  price: number;
  discount?: number;
  total: number;
}

interface SingleRecurringInvoiceResponse {
  id: number;
  customerName: string;
  customerEmail: string;
  time: string;
  frequency: string;
  startDate: string;
  endDate?: string;
  nextRunDate?: string;
  isActive: boolean;
  items: RecurringInvoiceItem[];
  taxId?: number;
  taxName?: string;
  taxRate?: number;
}

export function useRecurringInvoice(id: number) {
  return useQuery({
    queryKey: ["recurring-invoice", id],
    queryFn: async (): Promise<SingleRecurringInvoiceResponse> => {
      const client = new ApiClient<SingleRecurringInvoiceResponse>("/api/recurring-invoices");
      return await client.getById(id);
    },
    enabled: !!id,
  });
}
