﻿import { useQuery } from "@tanstack/react-query";
import ApiClient from "@/services/apiClient";

interface RecurringInvoiceListItem {
  id: number;
  customerName: string;
  customerEmail: string;
  frequency: string;
  startDate: string;
  endDate?: string;
  nextRunDate?: string;
  isActive: boolean;
  taxName?: string;
}

interface PagedRecurringInvoiceListResponse {
  items: RecurringInvoiceListItem[];
  totalCount: number;
  page: number;
  pageSize: number;
}

export function useRecurringInvoices(page: number = 1, pageSize: number = 10) {
  return useQuery({
    queryKey: ["recurring-invoices", page, pageSize],
    queryFn: async (): Promise<PagedRecurringInvoiceListResponse> => {
      const client = new ApiClient<PagedRecurringInvoiceListResponse>("/api/recurring-invoices");
      return await client.getAll({ page, pageSize });
    },
  });
}
