﻿import ApiClient from "@/services/apiClient";
import { useMutation } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";
import { AxiosError } from "axios";

interface CreateRecurringInvoiceLineRequest {
  productId: number;
  quantity: number;
  price: number;
  discount?: number;
}

interface CreateRecurringInvoiceRequest {
  customerId: number;
  time: string;
  frequency: "Weekly" | "Monthly" | "Quarterly" | "Yearly";
  startDate: string;
  endDate?: string;
  items: CreateRecurringInvoiceLineRequest[];
  taxId?: number;
}

export function useCreateRecurringInvoice() {
  const recurringInvoiceClient = new ApiClient<CreateRecurringInvoiceRequest>(
    "/api/recurring-invoices"
  );

  return useMutation({
    mutationFn: async (request: CreateRecurringInvoiceRequest) => {
      return await recurringInvoiceClient.post(request);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Recurring invoice created successfully",
      });
    },
    onError: (error: unknown) => {
      let errorMessage = "Failed to create recurring invoice";

      if (error instanceof AxiosError) {
        const responseData = error.response?.data;

        if (typeof responseData === "string") {
          // Business logic errors return a single error message string
          errorMessage = responseData;
        } else if (Array.isArray(responseData)) {
          // Validation errors return an array of error messages
          errorMessage = responseData.join(", ");
        } else if (
          responseData &&
          typeof responseData === "object" &&
          "message" in responseData
        ) {
          // Some APIs might return an object with a message property
          errorMessage = responseData.message as string;
        }
      }

      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });
}
