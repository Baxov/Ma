﻿import { useMutation, useQueryClient } from "@tanstack/react-query";
import ApiClient from "@/services/apiClient";
import { toast } from "@/hooks/use-toast";
import { AxiosError } from "axios";

export const useDeleteRecurringInvoice = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: number) => {
      const client = new ApiClient<void>("/api/recurring-invoices");
      await client.delete(id);
    },
    onSuccess: () => {
      // Invalidate and refetch recurring invoices queries
      queryClient.invalidateQueries({ queryKey: ["recurring-invoices"] });
      toast({
        title: "Success",
        description: "Recurring invoice deleted successfully",
      });
    },
    onError: (error) => {
      if (error instanceof AxiosError) {
        toast({
          variant: "destructive",
          title: "Error",
          description: error.response?.data || "Failed to delete recurring invoice",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to delete recurring invoice",
        });
      }
    },
  });
};
