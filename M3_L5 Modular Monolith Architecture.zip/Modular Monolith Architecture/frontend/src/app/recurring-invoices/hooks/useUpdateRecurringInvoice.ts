﻿import { useMutation, useQueryClient } from "@tanstack/react-query";
import ApiClient from "@/services/apiClient";
import { toast } from "@/hooks/use-toast";
import { AxiosError } from "axios";

interface UpdateRecurringInvoiceRequest {
  frequency: "Weekly" | "Monthly" | "Quarterly" | "Yearly";
  startDate: string;
  endDate?: string;
  isActive: boolean;
}

interface UpdateRecurringInvoiceResponse {
  id: number;
  frequency: string;
  startDate: string;
  endDate?: string;
  nextRunDate?: string;
  isActive: boolean;
}

export function useUpdateRecurringInvoice() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      id,
      data,
    }: {
      id: number;
      data: UpdateRecurringInvoiceRequest;
    }): Promise<UpdateRecurringInvoiceResponse> => {
      const client = new ApiClient<UpdateRecurringInvoiceResponse>(
        "/api/recurring-invoices"
      );
      return await client.put(id, data);
    },
    onSuccess: (data, variables) => {
      toast({
        title: "Success",
        description: "Recurring invoice updated successfully!",
      });

      // Invalidate and refetch recurring invoices list
      queryClient.invalidateQueries({ queryKey: ["recurring-invoices"] });

      // Update the specific recurring invoice cache
      queryClient.invalidateQueries({
        queryKey: ["recurring-invoice", variables.id],
      });
    },
    onError: (error: unknown) => {
      let errorMessage = "Failed to update recurring invoice";

      if (error instanceof AxiosError) {
        const responseData = error.response?.data;

        if (typeof responseData === "string") {
          // Business logic errors return a single error message string
          errorMessage = responseData;
        } else if (Array.isArray(responseData)) {
          // Validation errors return an array of error messages
          errorMessage = responseData.join(", ");
        } else if (
          responseData &&
          typeof responseData === "object" &&
          "message" in responseData
        ) {
          // Some APIs might return an object with a message property
          errorMessage = responseData.message as string;
        }
      }

      toast({
        variant: "destructive",
        title: "Error",
        description: errorMessage,
      });
    },
  });
}
