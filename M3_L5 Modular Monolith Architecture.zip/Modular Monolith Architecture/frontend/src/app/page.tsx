import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen flex">
      {/* Info Section */}
      <div className="hidden lg:flex w-1/2 bg-blue-600 text-white flex-col justify-center px-12">
        <h1 className="text-4xl font-bold mb-6">Welcome to InvadePay</h1>
        <div className="space-y-6">
          <p className="text-xl">Create and manage invoices with ease.</p>
          <ul className="space-y-4">
            <li className="flex items-center">
              <svg
                className="w-6 h-6 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
              Professional invoice generation
            </li>
            <li className="flex items-center">
              <svg
                className="w-6 h-6 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
              Track payments in real-time
            </li>
            <li className="flex items-center">
              <svg
                className="w-6 h-6 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
              Send invoices to clients
            </li>
          </ul>
        </div>
      </div>

      {/* CTA Section */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="flex flex-col items-center gap-6">
          <h1 className="text-5xl font-bold lg:hidden">InvadePay</h1>
          <p className="text-xl text-center mb-4 lg:hidden">
            Create and manage invoices with ease.
          </p>
          <Button asChild size="lg">
            <Link href="/login">Get Started</Link>
          </Button>
        </div>
      </div>
    </main>
  );
}
