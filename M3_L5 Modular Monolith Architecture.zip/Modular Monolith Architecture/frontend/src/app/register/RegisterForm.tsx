"use client";

import { useState } from "react";
import { SubmitButton } from "@/components/SubmitButton";
import { Alert } from "@/components/Alert";
import { authService } from "../login/authService";
import { useRouter } from "next/navigation";
import { tokenService } from "@/services/tokenService";

export default function RegisterForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setIsSubmitting(true);

    try {
      const response = await authService.register({
        email,
        firstName,
        lastName,
        password,
      });

      tokenService.setTokens({
        accessToken: response.accessToken,
        refreshToken: response.refreshToken,
        userId: response.userId,
      });
      // Show success message
      setSuccess("Account created successfully! Redirecting to login page...");

      // Clear the form
      setEmail("");
      setPassword("");
      setFirstName("");
      setLastName("");

      // Redirect to login after 3 seconds
      setTimeout(() => {
        router.push("/login");
      }, 3000);
    } catch (error: unknown) {
      // Extract error message from API response
      let errorMessage = "Registration failed. Please try again.";

      // Type guard to check if error is an axios error
      if (
        error &&
        typeof error === "object" &&
        "response" in error &&
        error.response &&
        typeof error.response === "object" &&
        "data" in error.response
      ) {
        const responseData = (error.response as { data: unknown }).data;

        // Handle different error response formats
        if (typeof responseData === "string") {
          errorMessage = responseData;
        } else if (Array.isArray(responseData)) {
          // Handle array of error messages
          const errorMessages = responseData.filter(
            (item): item is string => typeof item === "string"
          );
          if (errorMessages.length > 0) {
            errorMessage = errorMessages.join(" ");
          }
        } else if (
          responseData &&
          typeof responseData === "object" &&
          "message" in responseData &&
          typeof (responseData as { message: unknown }).message === "string"
        ) {
          errorMessage = (responseData as { message: string }).message;
        } else if (
          responseData &&
          typeof responseData === "object" &&
          "error" in responseData &&
          typeof (responseData as { error: unknown }).error === "string"
        ) {
          errorMessage = (responseData as { error: string }).error;
        }
      }

      setError(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="h-full w-full flex items-center justify-center mt-32">
      <div className="w-full max-w-md space-y-8 p-8 bg-white rounded-xl shadow-lg border border-gray-200">
        <div>
          <h2 className="text-center text-3xl font-extrabold text-gray-900">
            Create your account
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Already have an account?{" "}
            <a
              href="/login"
              className="font-medium text-blue-600 hover:text-blue-400"
            >
              Sign in
            </a>
          </p>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && <Alert type="error">{error}</Alert>}

          {success && <Alert type="success">{success}</Alert>}

          {!success && (
            <>
              <div className="rounded-md shadow-sm space-y-2">
                <div>
                  <label htmlFor="firstName" className="sr-only">
                    First Name
                  </label>
                  <input
                    id="firstName"
                    name="firstName"
                    type="text"
                    required
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                    placeholder="First Name"
                    disabled={isSubmitting}
                  />
                </div>
                <div>
                  <label htmlFor="lastName" className="sr-only">
                    Last Name
                  </label>
                  <input
                    id="lastName"
                    name="lastName"
                    type="text"
                    required
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    className="appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                    placeholder="Last Name"
                    disabled={isSubmitting}
                  />
                </div>
                <div>
                  <label htmlFor="email" className="sr-only">
                    Email address
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                    placeholder="Email address"
                    disabled={isSubmitting}
                  />
                </div>
                <div>
                  <label htmlFor="password" className="sr-only">
                    Password
                  </label>
                  <input
                    id="password"
                    name="password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                    placeholder="Password"
                    disabled={isSubmitting}
                  />
                </div>
              </div>

              <div>
                <SubmitButton
                  isSubmitting={isSubmitting}
                  text="Create Account"
                />
              </div>
            </>
          )}
        </form>
      </div>
    </div>
  );
}
