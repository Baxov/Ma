﻿import { useQuery } from "@tanstack/react-query";
import { axiosInstance } from "@/services/apiClient";

interface StatementInvoiceItem {
  invoiceId: number;
  invoiceNumber: string;
  invoiceDate: string;
  status: string;
  subtotalAmount: number;
  taxAmount: number;
  totalAmount: number;
  taxName?: string;
  taxRate?: number;
}

interface CustomerStatementResponse {
  customerId: number;
  customerName: string;
  customerEmail: string;
  statementStartDate: string;
  statementEndDate: string;
  totalOutstanding: number;
  totalPaid: number;
  accountBalance: number;
  outstandingInvoices: StatementInvoiceItem[];
  paidInvoices: StatementInvoiceItem[];
}

interface UseCustomerStatementParams {
  customerId: number;
  startDate: string;
  endDate: string;
}

export const useCustomerStatement = ({
  customerId,
  startDate,
  endDate,
}: UseCustomerStatementParams) => {
  return useQuery({
    queryKey: ["customer-statement", customerId, startDate, endDate],
    queryFn: async (): Promise<CustomerStatementResponse> => {
      const response = await axiosInstance.get<CustomerStatementResponse>(
        `/api/customers/${customerId}/statement?startDate=${startDate}&endDate=${endDate}`
      );
      return response.data;
    },
    enabled: !!customerId && !!startDate && !!endDate,
  });
};

export type { CustomerStatementResponse, StatementInvoiceItem };
