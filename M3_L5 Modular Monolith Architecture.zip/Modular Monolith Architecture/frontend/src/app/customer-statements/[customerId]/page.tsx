﻿"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { useCustomerStatement } from "../hooks/useCustomerStatement";
import useCustomers from "@/app/customers/hooks/useCustomers";
import { ProtectedRoute } from "@/auth/ProtectedRoute";
import Container from "@/components/Container";

import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  CalendarDays,
  FileText,
  DollarSign,
  TrendingUp,
  TrendingDown,
} from "lucide-react";
import { format } from "date-fns";
import DatePicker from "@/components/DatePicker";
import { CurrencyDisplay } from "@/components/CurrencyDisplay";

export default function CustomerStatementPage() {
  const params = useParams();
  const customerId = parseInt(params.customerId as string);

  const [startDate, setStartDate] = useState<Date>(
    new Date(new Date().getFullYear(), new Date().getMonth(), 1)
  );
  const [endDate, setEndDate] = useState<Date>(new Date());

  const { data: customers } = useCustomers(1, 100);

  const {
    data: statement,
    isLoading: statementLoading,
    error,
  } = useCustomerStatement({
    customerId: customerId || 0,
    startDate: format(startDate, "yyyy-MM-dd"),
    endDate: format(endDate, "yyyy-MM-dd"),
  });

  // Find the customer name for display
  const customer = customers?.items.find((c) => c.id === customerId);

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "paid":
        return "bg-green-100 text-green-800 hover:bg-green-200";
      case "sent":
        return "bg-yellow-100 text-yellow-800 hover:bg-yellow-200";
      case "draft":
        return "bg-gray-100 text-gray-800 hover:bg-gray-200";
      case "reversed":
        return "bg-red-100 text-red-800 hover:bg-red-200";
      default:
        return "bg-gray-100 text-gray-800 hover:bg-gray-200";
    }
  };

  return (
    <ProtectedRoute>
      <main>
        <Container>
          <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center gap-4">
              <div>
                <h1 className="text-3xl font-bold tracking-tight">
                  Customer Statement
                </h1>
                <p className="text-muted-foreground">
                  {customer
                    ? `Statement for ${customer.name}`
                    : "Loading customer..."}
                </p>
              </div>
            </div>

            {/* Date Range Selector */}
            <Card>
              <CardHeader>
                <CardTitle>Statement Period</CardTitle>
                <CardDescription>
                  Select the date range for the statement
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Start Date</label>
                    <DatePicker value={startDate} onChange={setStartDate} />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">End Date</label>
                    <DatePicker value={endDate} onChange={setEndDate} />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Statement Results */}
            {statementLoading && (
              <Card>
                <CardHeader>
                  <Skeleton className="h-6 w-48" />
                  <Skeleton className="h-4 w-64" />
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Skeleton className="h-20 w-full" />
                    <Skeleton className="h-40 w-full" />
                  </div>
                </CardContent>
              </Card>
            )}

            {error && (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">
                      Error Loading Statement
                    </h3>
                    <p className="text-muted-foreground">
                      {error.message ||
                        "Failed to load customer statement. Please try again."}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {statement && (
              <>
                {/* Statement Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle>Statement Summary</CardTitle>
                    <CardDescription>
                      {format(
                        new Date(statement.statementStartDate),
                        "MMM dd, yyyy"
                      )}{" "}
                      -{" "}
                      {format(
                        new Date(statement.statementEndDate),
                        "MMM dd, yyyy"
                      )}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="flex items-center space-x-3 p-4 bg-yellow-50 rounded-lg">
                        <TrendingUp className="h-8 w-8 text-yellow-600" />
                        <div>
                          <p className="text-sm font-medium text-yellow-800">
                            Total Outstanding
                          </p>
                          <p className="text-2xl font-bold text-yellow-900">
                            <CurrencyDisplay
                              amount={statement.totalOutstanding}
                            />
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3 p-4 bg-green-50 rounded-lg">
                        <TrendingDown className="h-8 w-8 text-green-600" />
                        <div>
                          <p className="text-sm font-medium text-green-800">
                            Total Paid
                          </p>
                          <p className="text-2xl font-bold text-green-900">
                            <CurrencyDisplay amount={statement.totalPaid} />
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3 p-4 bg-blue-50 rounded-lg">
                        <DollarSign className="h-8 w-8 text-blue-600" />
                        <div>
                          <p className="text-sm font-medium text-blue-800">
                            Account Balance
                          </p>
                          <p className="text-2xl font-bold text-blue-900">
                            <CurrencyDisplay
                              amount={statement.accountBalance}
                            />
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Outstanding Invoices */}
                {statement.outstandingInvoices.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Outstanding Invoices</CardTitle>
                      <CardDescription>
                        Invoices that are still pending payment
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Invoice #</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Tax</TableHead>
                            <TableHead className="text-right">Amount</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {statement.outstandingInvoices.map((invoice) => (
                            <TableRow key={invoice.invoiceId}>
                              <TableCell className="font-medium">
                                {invoice.invoiceNumber}
                              </TableCell>
                              <TableCell>
                                {format(
                                  new Date(invoice.invoiceDate),
                                  "MMM dd, yyyy"
                                )}
                              </TableCell>
                              <TableCell>
                                <Badge
                                  className={getStatusColor(invoice.status)}
                                >
                                  {invoice.status}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {invoice.taxName ? (
                                  <span className="text-sm">
                                    {invoice.taxName} ({invoice.taxRate}%)
                                  </span>
                                ) : (
                                  <span className="text-muted-foreground">
                                    No tax
                                  </span>
                                )}
                              </TableCell>
                              <TableCell className="text-right font-medium">
                                <CurrencyDisplay amount={invoice.totalAmount} />
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                )}

                {/* Paid Invoices */}
                {statement.paidInvoices.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Paid Invoices</CardTitle>
                      <CardDescription>
                        Invoices that have been paid during this period
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Invoice #</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Tax</TableHead>
                            <TableHead className="text-right">Amount</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {statement.paidInvoices.map((invoice) => (
                            <TableRow key={invoice.invoiceId}>
                              <TableCell className="font-medium">
                                {invoice.invoiceNumber}
                              </TableCell>
                              <TableCell>
                                {format(
                                  new Date(invoice.invoiceDate),
                                  "MMM dd, yyyy"
                                )}
                              </TableCell>
                              <TableCell>
                                <Badge
                                  className={getStatusColor(invoice.status)}
                                >
                                  {invoice.status}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {invoice.taxName ? (
                                  <span className="text-sm">
                                    {invoice.taxName} ({invoice.taxRate}%)
                                  </span>
                                ) : (
                                  <span className="text-muted-foreground">
                                    No tax
                                  </span>
                                )}
                              </TableCell>
                              <TableCell className="text-right font-medium">
                                <CurrencyDisplay amount={invoice.totalAmount} />
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                )}

                {/* No Invoices Message */}
                {statement.outstandingInvoices.length === 0 &&
                  statement.paidInvoices.length === 0 && (
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-center py-8">
                          <CalendarDays className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                          <h3 className="text-lg font-semibold mb-2">
                            No Invoices Found
                          </h3>
                          <p className="text-muted-foreground">
                            No invoices found for this customer in the selected
                            date range.
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
              </>
            )}
          </div>
        </Container>
      </main>
    </ProtectedRoute>
  );
}
