﻿import ApiClient from "@/services/apiClient";
import { useQuery } from "@tanstack/react-query";

export interface TaxResponse {
  id: number;
  name: string;
  description: string | null;
  rate: number;
}

export interface PagedResponse<T> {
  items: T[];
  totalCount: number;
}

const TEN_SECONDS = 10 * 1000;

const useTaxes = (page: number, pageSize: number) => {
  const fetchTaxes = async () => {
    const taxClient = new ApiClient<PagedResponse<TaxResponse>>(
      "/api/taxes"
    );
    return await taxClient.getAll({
      page,
      pageSize,
    });
  };

  return useQuery({
    queryKey: ["taxes", page],
    queryFn: fetchTaxes,
    staleTime: TEN_SECONDS,
  });
};

export default useTaxes;
