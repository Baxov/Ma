﻿import ApiClient from "@/services/apiClient";
import { useQuery } from "@tanstack/react-query";

export interface CompanySettingsResponse {
  id: number;
  companyName: string;
  address: string | null;
  email: string | null;
}

const TEN_SECONDS = 10 * 1000;

const useCompanySettings = () => {
  const fetchCompanySettings = async () => {
    const companySettingsClient = new ApiClient<CompanySettingsResponse>(
      "/api/company-settings"
    );
    return await companySettingsClient.get();
  };

  return useQuery({
    queryKey: ["company-settings"],
    queryFn: fetchCompanySettings,
    staleTime: TEN_SECONDS,
    retry: false, // Don't retry if company settings don't exist yet
  });
};

export default useCompanySettings;
