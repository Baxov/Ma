﻿"use client";

import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import ApiClient from "@/services/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AxiosError } from "axios";
import { TaxResponse } from "./hooks/useTaxes";

interface UpdateTaxRequest {
  name: string;
  description: string | null;
  rate: number;
}

interface EditTaxDialogProps {
  tax: TaxResponse;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function EditTaxDialog({
  tax,
  open,
  onOpenChange,
}: EditTaxDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [name, setName] = useState(tax.name);
  const [description, setDescription] = useState(tax.description || "");
  const [rate, setRate] = useState(tax.rate.toString());
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    setName(tax.name);
    setDescription(tax.description || "");
    setRate(tax.rate.toString());
  }, [tax]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const client = new ApiClient<TaxResponse>("/api/taxes");
      await client.put<UpdateTaxRequest>(tax.id, {
        name,
        description: description.trim() || null,
        rate: parseFloat(rate),
      });

      await queryClient.invalidateQueries({ queryKey: ["taxes"] });

      toast({
        title: "Success",
        description: "Tax updated successfully",
      });

      onOpenChange(false);
    } catch (error) {
      if (error instanceof AxiosError) {
        toast({
          variant: "destructive",
          title: "Error",
          description: error.response?.data || "Failed to update tax",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to update tax",
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Tax</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter tax name (e.g., VAT, GST)"
              required
              maxLength={100}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter tax description"
              maxLength={500}
              rows={3}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="rate">Rate (%)</Label>
            <Input
              id="rate"
              type="number"
              step="0.01"
              min="0"
              max="100"
              value={rate}
              onChange={(e) => setRate(e.target.value)}
              placeholder="Enter tax rate (0-100)"
              required
            />
          </div>
          <div className="flex justify-end">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Save Changes
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
