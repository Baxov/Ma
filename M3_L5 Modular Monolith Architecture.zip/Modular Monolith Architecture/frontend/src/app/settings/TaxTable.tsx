﻿"use client";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { LoaderCircle, Trash, Pencil } from "lucide-react";
import { useState } from "react";
import { TablePagination } from "@/components/TablePagination";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import ApiClient from "@/services/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AxiosError } from "axios";
import { EditTaxDialog } from "./EditTaxDialog";
import useTaxes from "./hooks/useTaxes";

export function TaxTable() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const pageSize = 10;
  const [page, setPage] = useState(1);
  const [editingTaxId, setEditingTaxId] = useState<number | null>(null);

  const { data, isLoading } = useTaxes(page, pageSize);
  const { items: taxes, totalCount } = data || {
    items: [],
    totalCount: 0,
  };

  const handleDelete = async (id: number) => {
    try {
      const client = new ApiClient<void>("/api/taxes");
      await client.delete(id);
      await queryClient.invalidateQueries({ queryKey: ["taxes"] });
      toast({
        title: "Success",
        description: "Tax deleted successfully",
      });
    } catch (error) {
      if (error instanceof AxiosError) {
        toast({
          variant: "destructive",
          title: "Error",
          description: error.response?.data || "Failed to delete tax",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to delete tax",
        });
      }
    }
  };

  if (isLoading)
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <LoaderCircle className="animate-spin w-8 h-8 text-gray-400" />
      </div>
    );

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="p-4">Name</TableHead>
            <TableHead className="p-4">Description</TableHead>
            <TableHead className="p-4 text-right">Rate (%)</TableHead>
            <TableHead className="p-4">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {taxes?.map((tax) => (
            <TableRow key={tax.id}>
              <TableCell className="font-medium text-left p-4">
                <span>{tax.name}</span>
              </TableCell>
              <TableCell className="text-left p-4">
                <span className="text-gray-600">
                  {tax.description || "No description"}
                </span>
              </TableCell>
              <TableCell className="text-right p-4">
                <span className="font-mono">{tax.rate}%</span>
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button className="bg-gray-50" variant="outline">
                      Actions
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-gray-50">
                    <DropdownMenuItem>
                      <button
                        className="w-full flex items-center gap-2"
                        onClick={() => setEditingTaxId(tax.id)}
                      >
                        <Pencil className="h-4 w-4" />
                        Edit
                      </button>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <button
                        className="w-full flex items-center gap-2 text-red-600"
                        onClick={() => handleDelete(tax.id)}
                      >
                        <Trash className="h-4 w-4" />
                        Delete
                      </button>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <TablePagination
        page={page}
        pageSize={pageSize}
        totalCount={totalCount}
        onPageChange={setPage}
      />
      {editingTaxId && (
        <EditTaxDialog
          tax={taxes.find((t) => t.id === editingTaxId)!}
          open={true}
          onOpenChange={(open) =>
            setEditingTaxId(open ? editingTaxId : null)
          }
        />
      )}
    </>
  );
}
