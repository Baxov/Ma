﻿import Container from "@/components/Container";
import { ProtectedRoute } from "@/auth/ProtectedRoute";
import { TaxTable } from "./TaxTable";
import { CreateTaxDialog } from "./CreateTaxDialog";
import { CompanySettingsForm } from "./CompanySettingsForm";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function SettingsPage() {
  return (
    <ProtectedRoute>
      <main>
        <Container>
          <div className="flex flex-col gap-8">
            <div>
              <h1 className="text-3xl font-bold">Settings</h1>
              <p className="text-gray-600 mt-2">
                Manage your account settings and configurations.
              </p>
            </div>

            <Accordion type="multiple" defaultValue={["company", "tax"]} className="w-full">
              <AccordionItem value="company">
                <AccordionTrigger className="text-xl font-semibold">
                  Company Settings
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4">
                    <p className="text-gray-600">
                      Configure your company information for invoices and documents.
                    </p>
                    <CompanySettingsForm />
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="tax">
                <AccordionTrigger className="text-xl font-semibold">
                  Tax Settings
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <p className="text-gray-600">
                        Configure tax rates for your invoices.
                      </p>
                      <CreateTaxDialog />
                    </div>
                    <TaxTable />
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </Container>
      </main>
    </ProtectedRoute>
  );
}
