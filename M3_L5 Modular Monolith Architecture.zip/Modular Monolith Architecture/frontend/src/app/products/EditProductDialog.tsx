"use client";

import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import ApiClient from "@/services/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AxiosError } from "axios";
import { ProductResponse } from "./hooks/useProducts";
import { ProductType, ProductTypeLabels } from "@/types/ProductType";
import { debouncedCleanupModalOverlays } from "@/utils/overlayCleanup";

interface UpdateProductRequest {
  name: string;
  defaultPrice: number | null;
  type: ProductType;
  unitOfMeasure: string | null;
  stockQuantity: number | null;
  trackInventory: boolean;
}

interface EditProductDialogProps {
  product: ProductResponse;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function EditProductDialog({
  product,
  open,
  onOpenChange,
}: EditProductDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [name, setName] = useState(product.name);
  const [price, setPrice] = useState(product.defaultPrice?.toString() ?? "");
  const [type, setType] = useState(product.type);
  const [unitOfMeasure, setUnitOfMeasure] = useState(
    product.unitOfMeasure ?? ""
  );
  const [stockQuantity, setStockQuantity] = useState(
    product.stockQuantity?.toString() ?? ""
  );
  const [trackInventory, setTrackInventory] = useState(product.trackInventory);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    setName(product.name);
    setPrice(product.defaultPrice?.toString() ?? "");
    setType(product.type);
    setUnitOfMeasure(product.unitOfMeasure ?? "");
    setStockQuantity(product.stockQuantity?.toString() ?? "");
    setTrackInventory(product.trackInventory);
  }, [product]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const client = new ApiClient<ProductResponse>("/api/products");
      await client.put<UpdateProductRequest>(product.id, {
        name,
        defaultPrice: price ? parseFloat(price) : null,
        type,
        unitOfMeasure: unitOfMeasure || null,
        stockQuantity: stockQuantity ? parseFloat(stockQuantity) : null,
        trackInventory,
      });

      await queryClient.invalidateQueries({ queryKey: ["products"] });

      toast({
        title: "Success",
        description: "Product updated successfully",
      });

      // Close dialog with proper cleanup
      onOpenChange(false);

      // Force cleanup of any lingering overlays after a short delay
      setTimeout(() => {
        debouncedCleanupModalOverlays(200);
      }, 100);
    } catch (error) {
      if (error instanceof AxiosError) {
        toast({
          variant: "destructive",
          title: "Error",
          description: error.response?.data || "Failed to update product",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to update product",
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Product</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter product name"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="price">Price</Label>
            <Input
              id="price"
              type="number"
              step="0.01"
              min="0"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="Enter product price"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="type">Type</Label>
            <Select
              value={type}
              onValueChange={(value) => setType(value as ProductType)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ProductType.Product}>
                  {ProductTypeLabels[ProductType.Product]}
                </SelectItem>
                <SelectItem value={ProductType.Service}>
                  {ProductTypeLabels[ProductType.Service]}
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="unitOfMeasure">Unit of Measure</Label>
            <Input
              id="unitOfMeasure"
              value={unitOfMeasure}
              onChange={(e) => setUnitOfMeasure(e.target.value)}
              placeholder="e.g., pieces, kg, hours, liters"
            />
          </div>

          {type === ProductType.Product && (
            <>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="trackInventory"
                    checked={trackInventory}
                    onCheckedChange={setTrackInventory}
                  />
                  <Label htmlFor="trackInventory">Track Inventory</Label>
                </div>
              </div>

              {trackInventory && (
                <div className="space-y-2">
                  <Label htmlFor="stockQuantity">Stock Quantity</Label>
                  <Input
                    id="stockQuantity"
                    type="number"
                    step="0.01"
                    min="0"
                    value={stockQuantity}
                    onChange={(e) => setStockQuantity(e.target.value)}
                    placeholder="Enter current stock quantity"
                    required={trackInventory}
                  />
                </div>
              )}
            </>
          )}

          <div className="flex justify-end">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Save Changes
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
