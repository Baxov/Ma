import Container from "@/components/Container";
import { ProtectedRoute } from "@/auth/ProtectedRoute";
import { ProductTable } from "./ProductTable";
import { CreateProductDialog } from "./CreateProductDialog";

export default function ProductsPage() {
  return (
    <ProtectedRoute>
      <main>
        <Container>
          <div className="flex flex-col gap-6">
            <div className="flex justify-between">
              <h1 className="text-3xl font-bold">Products</h1>
              <CreateProductDialog />
            </div>
            <ProductTable />
          </div>
        </Container>
      </main>
    </ProtectedRoute>
  );
}
