"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CirclePlus } from "lucide-react";
import ApiClient from "@/services/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AxiosError } from "axios";
import { ProductType, ProductTypeLabels } from "@/types/ProductType";
import { debouncedCleanupModalOverlays } from "@/utils/overlayCleanup";

interface CreateProductRequest {
  name: string;
  defaultPrice: number | null;
  type: ProductType;
  unitOfMeasure: string | null;
  stockQuantity: number | null;
  trackInventory: boolean;
}

interface CreateProductResponse {
  id: number;
  name: string;
  defaultPrice: number | null;
  type: ProductType;
  unitOfMeasure: string | null;
  stockQuantity: number | null;
  trackInventory: boolean;
}

export function CreateProductDialog() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [type, setType] = useState(ProductType.Product);
  const [unitOfMeasure, setUnitOfMeasure] = useState("");
  const [stockQuantity, setStockQuantity] = useState("");
  const [trackInventory, setTrackInventory] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const client = new ApiClient<CreateProductResponse>("/api/products");
      await client.post<CreateProductRequest>({
        name,
        defaultPrice: price ? parseFloat(price) : null,
        type,
        unitOfMeasure: unitOfMeasure || null,
        stockQuantity: stockQuantity ? parseFloat(stockQuantity) : null,
        trackInventory,
      });

      await queryClient.invalidateQueries({ queryKey: ["products"] });

      toast({
        title: "Success",
        description: "Product created successfully",
      });

      setOpen(false);
      setName("");
      setPrice("");
      setType(ProductType.Product);
      setUnitOfMeasure("");
      setStockQuantity("");
      setTrackInventory(false);

      // Force cleanup of any lingering overlays after a short delay
      setTimeout(() => {
        debouncedCleanupModalOverlays(200);
      }, 100);
    } catch (error) {
      if (error instanceof AxiosError) {
        toast({
          variant: "destructive",
          title: "Error",
          description: error.response?.data || "Failed to create product",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to create product",
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen);
    if (!newOpen) {
      // Force cleanup of any lingering overlays when dialog closes
      setTimeout(() => {
        debouncedCleanupModalOverlays(200);
      }, 100);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button
          className="inline-flex gap-2 bg-blue-600 hover:bg-blue-700"
          onClick={(e) => {
            e.preventDefault();
            setOpen(true);
          }}
        >
          <CirclePlus className="h-4 w-4" />
          Create Product
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create New Product</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter product name"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="price">Price</Label>
            <Input
              id="price"
              type="number"
              step="0.01"
              min="0"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="Enter product price"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="type">Type</Label>
            <Select
              value={type}
              onValueChange={(value) => setType(value as ProductType)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ProductType.Product}>
                  {ProductTypeLabels[ProductType.Product]}
                </SelectItem>
                <SelectItem value={ProductType.Service}>
                  {ProductTypeLabels[ProductType.Service]}
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="unitOfMeasure">Unit of Measure</Label>
            <Input
              id="unitOfMeasure"
              value={unitOfMeasure}
              onChange={(e) => setUnitOfMeasure(e.target.value)}
              placeholder="e.g., pieces, kg, hours, liters"
            />
          </div>

          {type === ProductType.Product && (
            <>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="trackInventory"
                    checked={trackInventory}
                    onCheckedChange={setTrackInventory}
                  />
                  <Label htmlFor="trackInventory">Track Inventory</Label>
                </div>
              </div>

              {trackInventory && (
                <div className="space-y-2">
                  <Label htmlFor="stockQuantity">Stock Quantity</Label>
                  <Input
                    id="stockQuantity"
                    type="number"
                    step="0.01"
                    min="0"
                    value={stockQuantity}
                    onChange={(e) => setStockQuantity(e.target.value)}
                    placeholder="Enter current stock quantity"
                    required={trackInventory}
                  />
                </div>
              )}
            </>
          )}

          <div className="flex justify-end">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Create
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
