"use client";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { LoaderCircle, Trash, Pencil } from "lucide-react";
import { useState, useEffect } from "react";
import { TablePagination } from "@/components/TablePagination";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import ApiClient from "@/services/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AxiosError } from "axios";
import { EditProductDialog } from "./EditProductDialog";
import useProducts from "./hooks/useProducts";
import { CurrencyDisplay } from "@/components/CurrencyDisplay";
import { ProductType, ProductTypeLabels } from "@/types/ProductType";
import { debouncedCleanupModalOverlays } from "@/utils/overlayCleanup";

export function ProductTable() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const pageSize = 10;
  const [page, setPage] = useState(1);
  const [editingProductId, setEditingProductId] = useState<number | null>(null);

  const { data, isLoading } = useProducts(page, pageSize);
  const { items: products, totalCount } = data || {
    items: [],
    totalCount: 0,
  };

  // Clean up dialog state when component unmounts or data changes
  useEffect(() => {
    return () => {
      // Cleanup function to ensure dialog state is reset
      setEditingProductId(null);
      // Force cleanup of any lingering overlay elements
      debouncedCleanupModalOverlays();
    };
  }, [data]);

  const handleDelete = async (id: number) => {
    try {
      const client = new ApiClient<void>("/api/products");
      await client.delete(id);
      await queryClient.invalidateQueries({ queryKey: ["products"] });
      toast({
        title: "Success",
        description: "Product deleted successfully",
      });
    } catch (error) {
      if (error instanceof AxiosError) {
        toast({
          variant: "destructive",
          title: "Error",
          description: error.response?.data || "Failed to delete product",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to delete product",
        });
      }
    }
  };

  if (isLoading)
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <LoaderCircle className="animate-spin w-8 h-8 text-gray-400" />
      </div>
    );

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="p-4">Name</TableHead>
            <TableHead className="p-4">Type</TableHead>
            <TableHead className="p-4">Unit</TableHead>
            <TableHead className="p-4 text-right">Default Price</TableHead>
            <TableHead className="p-4 text-right">Stock</TableHead>
            <TableHead className="p-4">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {products?.map((product) => (
            <TableRow key={product.id}>
              <TableCell className="font-medium text-left p-4">
                <span>{product.name}</span>
              </TableCell>
              <TableCell className="p-4">
                <span
                  className={`px-2 py-1 rounded-full text-xs font-medium ${
                    product.type === ProductType.Product
                      ? "bg-blue-100 text-blue-800"
                      : "bg-green-100 text-green-800"
                  }`}
                >
                  {ProductTypeLabels[product.type]}
                </span>
              </TableCell>
              <TableCell className="p-4">
                <span className="text-gray-600">
                  {product.unitOfMeasure || "-"}
                </span>
              </TableCell>
              <TableCell className="text-right p-4">
                <CurrencyDisplay amount={product.defaultPrice} />
              </TableCell>
              <TableCell className="text-right p-4">
                {product.type === ProductType.Product &&
                product.trackInventory ? (
                  <span
                    className={`font-medium ${
                      product.stockQuantity !== null &&
                      product.stockQuantity <= 10
                        ? "text-red-600"
                        : "text-gray-900"
                    }`}
                  >
                    {product.stockQuantity ?? "N/A"}
                  </span>
                ) : (
                  <span className="text-gray-400">-</span>
                )}
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button className="bg-gray-50" variant="outline">
                      Actions
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-gray-50">
                    <DropdownMenuItem>
                      <button
                        className="w-full flex items-center gap-2"
                        onClick={() => setEditingProductId(product.id)}
                      >
                        <Pencil className="h-4 w-4" />
                        Edit
                      </button>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <button
                        className="w-full flex items-center gap-2 text-red-600"
                        onClick={() => handleDelete(product.id)}
                      >
                        <Trash className="h-4 w-4" />
                        Delete
                      </button>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <TablePagination
        page={page}
        pageSize={pageSize}
        totalCount={totalCount}
        onPageChange={setPage}
      />
      {editingProductId && (
        <EditProductDialog
          key={`edit-product-${editingProductId}`}
          product={products.find((p) => p.id === editingProductId)!}
          open={true}
          onOpenChange={(open) => {
            if (!open) {
              // Use timeout to allow dialog animation to complete
              setTimeout(() => {
                setEditingProductId(null);
                // Force cleanup of any lingering overlays
                debouncedCleanupModalOverlays(200);
              }, 150);
            }
          }}
        />
      )}
    </>
  );
}
