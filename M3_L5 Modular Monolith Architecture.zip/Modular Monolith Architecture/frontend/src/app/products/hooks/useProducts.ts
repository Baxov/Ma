import ApiClient from "@/services/apiClient";
import { useQuery } from "@tanstack/react-query";
import { ProductType } from "@/types/ProductType";

export interface ProductResponse {
  id: number;
  name: string;
  defaultPrice: number | null;
  type: ProductType;
  unitOfMeasure: string | null;
  stockQuantity: number | null;
  trackInventory: boolean;
}

export interface PagedResponse<T> {
  items: T[];
  totalCount: number;
}

const TEN_SECONDS = 10 * 1000;

const useProducts = (page: number, pageSize: number) => {
  const fetchProducts = async () => {
    const productClient = new ApiClient<PagedResponse<ProductResponse>>(
      "/api/products"
    );
    return await productClient.getAll({
      page,
      pageSize,
    });
  };

  return useQuery({
    queryKey: ["products", page],
    queryFn: fetchProducts,
    staleTime: TEN_SECONDS,
  });
};

export default useProducts;
