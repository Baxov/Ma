import {
  LoginRequest,
  LoginResponse,
  RegisterRequest,
  RegisterResponse,
  RefreshTokenRequest,
  RefreshTokenResponse,
  ForgotPasswordRequest,
  ForgotPasswordResponse,
  ResetPasswordRequest,
  ResetPasswordResponse,
} from "../../auth/auth";
import ApiClient from "@/services/apiClient";
import { tokenService } from "@/services/tokenService";

export const authService = {
  async login(data: LoginRequest): Promise<LoginResponse> {
    const authClient = new ApiClient<LoginResponse>("/api/login");

    const response = await authClient.post(data);
    return response;
  },

  async register(data: RegisterRequest): Promise<RegisterResponse> {
    const authClient = new ApiClient<RegisterResponse>("/api/register");
    const response = await authClient.post(data);
    return response;
  },

  async refreshToken(data: RefreshTokenRequest): Promise<RefreshTokenResponse> {
    const authClient = new ApiClient<RefreshTokenResponse>("/api/refresh-token");
    const response = await authClient.post(data);
    return response;
  },

  async logout() {
    try {
      // const authClient = new ApiClient("/api/logout");
      // await authClient.post({}); // Send logout request to backend if needed
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      // Clear all tokens using token service
      tokenService.clearTokens();
    }
  },

  async forgotPassword(data: ForgotPasswordRequest): Promise<ForgotPasswordResponse> {
    const authClient = new ApiClient<ForgotPasswordResponse>("/api/forgot-password");
    const response = await authClient.post(data);
    return response;
  },

  async resetPassword(data: ResetPasswordRequest): Promise<ResetPasswordResponse> {
    const authClient = new ApiClient<ResetPasswordResponse>("/api/reset-password");
    const response = await authClient.post(data);
    return response;
  },
};
