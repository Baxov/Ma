﻿import ApiClient from "@/services/apiClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface UpdateInvoiceLineRequest {
  id?: number; // Null for new items, existing ID for updates
  productId: number;
  quantity: number;
  price: number;
  discount?: number;
}

interface UpdateInvoiceRequest {
  customerId: number;
  date: string;
  dueDate: string;
  time: string;
  items: UpdateInvoiceLineRequest[];
  taxId?: number;
}

export interface UpdateInvoiceResponse {
  id: number;
  invoiceNumber: string;
  customerName: string;
  customerEmail: string;
  date: Date;
  dueDate: Date;
  status: string;
  subtotalAmount: number;
  taxAmount: number;
  totalAmount: number;
  taxId?: number;
  taxName?: string;
  taxRate?: number;
}

export function useUpdateInvoice() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      id,
      request,
    }: {
      id: number;
      request: UpdateInvoiceRequest;
    }) => {
      const invoiceClient = new ApiClient<UpdateInvoiceRequest>(
        "/api/invoices"
      );
      return await invoiceClient.put(id.toString(), request);
    },
    onSuccess: (data, variables) => {
      // Invalidate and refetch invoice queries
      queryClient.invalidateQueries({
        queryKey: ["invoice", variables.id.toString()],
      });
      queryClient.invalidateQueries({ queryKey: ["invoices"] });
    },
  });
}
