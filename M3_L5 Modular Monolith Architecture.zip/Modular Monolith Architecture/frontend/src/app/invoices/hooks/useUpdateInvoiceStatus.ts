import ApiClient from "@/services/apiClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface UpdateInvoiceStatusRequest {
  status: "Sent" | "Paid";
}

interface UpdateStatusParams {
  invoiceId: number;
  status: "Sent" | "Paid";
}

export function useUpdateInvoiceStatus() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ invoiceId, status }: UpdateStatusParams) => {
      const invoiceClient = new ApiClient<UpdateInvoiceStatusRequest>(
        "/api/invoices"
      );
      return await invoiceClient.put(`${invoiceId}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["invoices"] });
    },
  });
}
