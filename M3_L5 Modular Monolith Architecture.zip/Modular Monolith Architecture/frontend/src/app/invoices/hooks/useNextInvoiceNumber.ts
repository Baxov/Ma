import ApiClient from "@/services/apiClient";
import { useQuery } from "@tanstack/react-query";

interface NextInvoiceNumberResponse {
  invoiceNumber: string;
}

const useNextInvoiceNumber = () => {
  const fetchNextInvoiceNumber = async () => {
    const client = new ApiClient<NextInvoiceNumberResponse>(
      "/api/invoices/next-number"
    );
    return await client.getAll();
  };

  return useQuery({
    queryKey: ["nextInvoiceNumber"],
    queryFn: fetchNextInvoiceNumber,
  });
};

export default useNextInvoiceNumber;
