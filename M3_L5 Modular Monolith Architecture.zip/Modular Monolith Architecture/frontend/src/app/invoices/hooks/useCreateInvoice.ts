import ApiClient from "@/services/apiClient";
import { useMutation } from "@tanstack/react-query";

interface CreateInvoiceLineRequest {
  productId: number;
  quantity: number;
  price: number;
  discount?: number;
}

interface CreateInvoiceRequest {
  customerId: number;
  date: string;
  dueDate: string;
  time: string;
  items: CreateInvoiceLineRequest[];
  taxId?: number;
}

export function useCreateInvoice() {
  const invoiceClient = new ApiClient<CreateInvoiceRequest>("/api/invoices");

  return useMutation({
    mutationFn: async (request: CreateInvoiceRequest) => {
      return await invoiceClient.post(request);
    },
  });
}
