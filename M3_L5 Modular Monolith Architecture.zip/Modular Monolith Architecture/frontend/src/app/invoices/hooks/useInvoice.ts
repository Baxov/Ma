import ApiClient from "@/services/apiClient";
import { useQuery } from "@tanstack/react-query";

export interface InvoiceItemResponse {
  id: number;
  productId: number;
  productName: string;
  quantity: number;
  price: number;
  discount?: number;
  lineTotal: number;
}

export interface SingleInvoiceResponse {
  id: number;
  invoiceNumber: string;
  customerName: string;
  customerEmail: string;
  customerId?: number;
  date: Date;
  dueDate: Date;
  time?: string;
  status: "Draft" | "Sent" | "Paid" | "Reversed";
  subtotalAmount: number;
  taxAmount: number;
  totalAmount: number;
  items: InvoiceItemResponse[];
  taxId?: number;
  taxName?: string;
  taxRate?: number;
}

export function useInvoice(invoiceId: string) {
  const fetchInvoice = async () => {
    const invoiceClient = new ApiClient<SingleInvoiceResponse>("/api/invoices");
    return await invoiceClient.getById(invoiceId);
  };

  return useQuery({
    queryKey: ["invoice", invoiceId],
    queryFn: fetchInvoice,
  });
}
