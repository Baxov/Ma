import ApiClient from "@/services/apiClient";
import { useQuery } from "@tanstack/react-query";

export interface PagedResponse<T> {
  items: T[];
  totalCount: number;
}

export interface InvoiceResponse {
  id: number;
  invoiceNumber: string;
  customerName: string;
  customerEmail: string;
  date: Date;
  dueDate: Date;
  status: "Draft" | "Sent" | "Paid" | "Reversed";
  subtotalAmount: number;
  taxAmount: number;
  totalAmount: number;
  taxId?: number;
  taxName?: string;
  taxRate?: number;
}

const TEN_SECONDS = 10 * 1000;

const useInvoices = (page: number, pageSize: number, search?: string) => {
  const fetchInvoices = async () => {
    const invoiceClient = new ApiClient<PagedResponse<InvoiceResponse>>(
      "/api/invoices"
    );

    const params: { page: number; pageSize: number; search?: string } = {
      page,
      pageSize,
    };

    if (search && search.trim()) {
      params.search = search.trim();
    }

    return await invoiceClient.getAll(params);
  };

  return useQuery({
    queryKey: ["invoices", page, search],
    queryFn: fetchInvoices,
    staleTime: TEN_SECONDS,
  });
};

export default useInvoices;
