﻿import ApiClient from "@/services/apiClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";

interface SendInvoiceEmailResponse {
  success: boolean;
  message: string;
}

export function useSendInvoice() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (invoiceId: number) => {
      const invoiceClient = new ApiClient<SendInvoiceEmailResponse>(`/api/invoices/${invoiceId}/send-email`);
      return await invoiceClient.post({});
    },
    onSuccess: (data, invoiceId) => {
      toast({
        title: "Success",
        description: data.message,
      });
      
      // Invalidate and refetch invoice queries to update status
      queryClient.invalidateQueries({ queryKey: ["invoice", invoiceId.toString()] });
      queryClient.invalidateQueries({ queryKey: ["invoices"] });
    },
    onError: (error: unknown) => {
      const errorMessage =
        error && typeof error === "object" && "response" in error
          ? (error as { response?: { data?: { message?: string } } }).response
              ?.data?.message
          : undefined;

      toast({
        title: "Error",
        description: errorMessage || "Failed to send invoice email",
        variant: "destructive",
      });
    },
  });
}
