"use client";

import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import { Input } from "@/components/ui/input";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { Check, ChevronsUpDown, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { CurrencyDisplay } from "@/components/CurrencyDisplay";
import { ProductType, ProductTypeLabels } from "@/types/ProductType";

export interface Product {
  id: number;
  name: string;
  defaultPrice: number | null;
  type: ProductType;
  unitOfMeasure: string | null;
  stockQuantity: number | null;
  trackInventory: boolean;
}

export interface InvoiceLineItemData {
  id: string;
  productId?: number;
  quantity: number;
  price: number;
  discount: number;
  discountEnabled: boolean;
}

interface InvoiceLineItemProps {
  item: InvoiceLineItemData;
  products: Product[];
  onUpdate: (id: string, updates: Partial<InvoiceLineItemData>) => void;
  onRemove: (id: string) => void;
  canRemove: boolean;
}

// Table Header Component
export function InvoiceLineItemsHeader() {
  return (
    <TableHeader>
      <TableRow>
        <TableHead className="min-w-[200px]">Product</TableHead>
        <TableHead className="w-[80px]">Quantity</TableHead>
        <TableHead className="w-[100px]">Price</TableHead>
        <TableHead className="w-[100px] text-center">Discount</TableHead>
        <TableHead className="w-[100px]">Discount %</TableHead>
        <TableHead className="w-[120px] text-right">Line Total</TableHead>
        <TableHead className="w-[80px] text-center">Actions</TableHead>
      </TableRow>
    </TableHeader>
  );
}

// Individual Row Component
export function InvoiceLineItem({
  item,
  products,
  onUpdate,
  onRemove,
  canRemove,
}: InvoiceLineItemProps) {
  const [isProductOpen, setIsProductOpen] = useState(false);

  // Get the selected product for validation
  const selectedProduct = products.find((p) => p.id === item.productId);

  // Update price when product changes
  useEffect(() => {
    if (item.productId) {
      const product = products.find((p) => p.id === item.productId);
      if (
        product?.defaultPrice !== null &&
        product?.defaultPrice !== undefined &&
        item.price === 0
      ) {
        onUpdate(item.id, { price: product.defaultPrice });
      }
    }
  }, [item.productId, products, item.price, item.id, onUpdate]);
  const subtotal = item.price * item.quantity;
  const discountAmount = item.discountEnabled
    ? (subtotal * (item.discount || 0)) / 100
    : 0;
  const lineTotal = subtotal - discountAmount;

  return (
    <TableRow>
      {/* Product Selection */}
      <TableCell>
        <Popover open={isProductOpen} onOpenChange={setIsProductOpen}>
          <PopoverTrigger asChild>
            <Button
              type="button"
              variant="outline"
              role="combobox"
              aria-expanded={isProductOpen}
              className="w-full justify-between text-left"
            >
              <span className="truncate">
                {selectedProduct ? selectedProduct.name : "Select product..."}
              </span>
              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-[300px] p-0">
            <Command>
              <CommandInput placeholder="Search products..." />
              <CommandEmpty>No product found.</CommandEmpty>
              <CommandGroup>
                {products.map((product) => (
                  <CommandItem
                    key={product.id}
                    onSelect={() => {
                      onUpdate(item.id, {
                        productId: product.id,
                        price: product.defaultPrice ?? 0,
                      });
                      setIsProductOpen(false);
                    }}
                  >
                    <Check
                      className={cn(
                        "mr-2 h-4 w-4",
                        item.productId === product.id
                          ? "opacity-100"
                          : "opacity-0"
                      )}
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span>{product.name}</span>
                        <span
                          className={`px-1.5 py-0.5 rounded text-xs font-medium ${
                            product.type === ProductType.Product
                              ? "bg-blue-100 text-blue-800"
                              : "bg-green-100 text-green-800"
                          }`}
                        >
                          {ProductTypeLabels[product.type]}
                        </span>
                      </div>
                      <div className="text-sm text-gray-500 space-y-1">
                        {product.defaultPrice !== null &&
                          product.defaultPrice !== undefined && (
                            <div>
                              Default price:{" "}
                              <CurrencyDisplay amount={product.defaultPrice} />
                            </div>
                          )}
                        {product.unitOfMeasure && (
                          <div>Unit: {product.unitOfMeasure}</div>
                        )}
                        {product.type === ProductType.Product && product.trackInventory && (
                          <div
                            className={`${
                              product.stockQuantity !== null &&
                              product.stockQuantity <= 10
                                ? "text-red-600 font-medium"
                                : "text-gray-600"
                            }`}
                          >
                            Stock: {product.stockQuantity ?? "N/A"}
                            {product.stockQuantity !== null &&
                              product.stockQuantity <= 10 && (
                                <span className="ml-1">(Low stock!)</span>
                              )}
                          </div>
                        )}
                      </div>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            </Command>
          </PopoverContent>
        </Popover>
      </TableCell>

      {/* Quantity */}
      <TableCell>
        <div className="space-y-1">
          <Input
            type="number"
            min="1"
            max={
              selectedProduct?.type === ProductType.Product && selectedProduct?.trackInventory
                ? selectedProduct.stockQuantity ?? undefined
                : undefined
            }
            value={item.quantity?.toString() || ""}
            onChange={(e) =>
              onUpdate(item.id, { quantity: parseInt(e.target.value) || 1 })
            }
            placeholder="1"
            className={`w-full ${
              selectedProduct?.type === ProductType.Product &&
              selectedProduct?.trackInventory &&
              selectedProduct?.stockQuantity !== null &&
              (item.quantity || 0) > selectedProduct.stockQuantity
                ? "border-red-500 focus:border-red-500"
                : ""
            }`}
          />
          {selectedProduct?.type === ProductType.Product &&
            selectedProduct?.trackInventory &&
            selectedProduct?.stockQuantity !== null &&
            (item.quantity || 0) > selectedProduct.stockQuantity && (
              <div className="text-xs text-red-600">
                Exceeds available stock ({selectedProduct.stockQuantity})
              </div>
            )}
          {selectedProduct?.unitOfMeasure && (
            <div className="text-xs text-gray-500">
              Unit: {selectedProduct.unitOfMeasure}
            </div>
          )}
        </div>
      </TableCell>

      {/* Price */}
      <TableCell>
        <Input
          type="number"
          step="0.01"
          min="0"
          value={item.price?.toString() || ""}
          onChange={(e) =>
            onUpdate(item.id, { price: parseFloat(e.target.value) || 0 })
          }
          placeholder="0.00"
          className="w-full"
        />
      </TableCell>

      {/* Discount Toggle */}
      <TableCell className="text-center">
        <Switch
          checked={item.discountEnabled}
          onCheckedChange={(checked) =>
            onUpdate(item.id, {
              discountEnabled: checked,
              discount: checked ? item.discount : 0,
            })
          }
        />
      </TableCell>

      {/* Discount Percentage */}
      <TableCell>
        <Input
          type="number"
          min="0"
          max="100"
          step="0.1"
          value={item.discountEnabled ? item.discount?.toString() || "" : ""}
          onChange={(e) =>
            onUpdate(item.id, { discount: parseFloat(e.target.value) || 0 })
          }
          disabled={!item.discountEnabled}
          placeholder="0"
          className="w-full"
        />
      </TableCell>

      {/* Line Total */}
      <TableCell className="text-right font-medium">
        <CurrencyDisplay amount={lineTotal} />
      </TableCell>

      {/* Actions */}
      <TableCell className="text-center">
        {canRemove && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => onRemove(item.id)}
            className="text-red-600 hover:text-red-700 hover:bg-red-50 p-2"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
      </TableCell>
    </TableRow>
  );
}

// Main Table Component
interface InvoiceLineItemsTableProps {
  lineItems: InvoiceLineItemData[];
  products: Product[];
  onUpdate: (id: string, updates: Partial<InvoiceLineItemData>) => void;
  onRemove: (id: string) => void;
}

export function InvoiceLineItemsTable({
  lineItems,
  products,
  onUpdate,
  onRemove,
}: InvoiceLineItemsTableProps) {
  return (
    <div className="border rounded-lg overflow-x-auto">
      <Table className="min-w-[800px]">
        <InvoiceLineItemsHeader />
        <TableBody>
          {lineItems.map((item) => (
            <InvoiceLineItem
              key={item.id}
              item={item}
              products={products}
              onUpdate={onUpdate}
              onRemove={onRemove}
              canRemove={lineItems.length > 1}
            />
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
