import { z } from "zod";

export const createInvoiceLineSchema = z.object({
  productId: z.number().int().positive("Product is required."),
  quantity: z.number().min(1, "Quantity must be at least 1."),
  price: z.number().min(0, "Price must be positive."),
  discount: z
    .number()
    .min(0, "Discount must be positive.")
    .optional()
    .default(0),
});

export const createInvoiceSchema = z.object({
  customerId: z.number().int().positive("Customer is required."),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format."),
  dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Due date must be in YYYY-MM-DD format."),
  time: z
    .string()
    .regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Invalid time format."),
  items: z
    .array(createInvoiceLineSchema)
    .min(1, "At least one item is required."),
  taxId: z.number().int().positive().optional(),
});

export type CreateInvoiceSchema = z.infer<typeof createInvoiceSchema>;
export type CreateInvoiceLineSchema = z.infer<typeof createInvoiceLineSchema>;
