"use client";

import Form from "next/form";
import { type SyntheticEvent, useState, useMemo } from "react";

import useCustomers from "@/app/customers/hooks/useCustomers";
import { CreateCustomerDialog } from "@/app/customers/CreateCustomerDialog";
import { useCreateInvoice } from "@/app/invoices/hooks/useCreateInvoice";
import useProducts from "@/app/products/hooks/useProducts";
import useTaxes from "@/app/settings/hooks/useTaxes";
import { ProtectedRoute } from "@/auth/ProtectedRoute";
import Container from "@/components/Container";
import { CurrencyDisplay } from "@/components/CurrencyDisplay";
import DatePicker from "@/components/DatePicker";
import { SubmitButton } from "@/components/SubmitButton";
import TimePicker from "@/components/TimePicker";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

import { cn } from "@/lib/utils";
import axios from "axios";
import { Check, ChevronsUpDown, Plus } from "lucide-react";
import { useRouter } from "next/navigation";
import { z } from "zod";
import useNextInvoiceNumber from "../hooks/useNextInvoiceNumber";
import { createInvoiceSchema } from "./createInvoiceSchema";
import {
  InvoiceLineItemsTable,
  type InvoiceLineItemData,
} from "./InvoiceLineItem";
import { formatDateForApi } from "@/lib/dateUtils";

const formatCurrentTime = () => {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  return `${hours}:${minutes}`;
};

const generateId = () => Math.random().toString(36).substr(2, 9);

export default function CreateInvoice() {
  const [error, setError] = useState<string>();
  const [success, setSuccess] = useState<boolean>();
  const [time, setTime] = useState(formatCurrentTime());
  const [date, setDate] = useState(new Date());
  const [dueDate, setDueDate] = useState(
    new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
  ); // Default to 30 days from now
  const [isSubmitting, setIsSubmitting] = useState(false);
  const router = useRouter();
  const createInvoice = useCreateInvoice();
  const { data: nextInvoiceNumber, isLoading: isLoadingInvoiceNumber } =
    useNextInvoiceNumber();
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>();
  const [isCustomerOpen, setIsCustomerOpen] = useState(false);
  const [selectedTaxId, setSelectedTaxId] = useState<string>();
  const [isTaxOpen, setIsTaxOpen] = useState(false);
  const { data: customersData } = useCustomers(1, 100); // Fetch first 100 customers
  const { data: taxesData } = useTaxes(1, 100); // Fetch first 100 taxes
  const customers = useMemo(
    () => customersData?.items || [],
    [customersData?.items]
  );

  const { data: productsData } = useProducts(1, 100); // Fetch first 100 products
  const products = productsData?.items || [];
  const taxes = taxesData?.items || [];

  // Invoice line items state
  const [lineItems, setLineItems] = useState<InvoiceLineItemData[]>([
    {
      id: generateId(),
      quantity: 1,
      price: 0,
      discount: 0,
      discountEnabled: false,
    },
  ]);

  // Line item management functions
  const addLineItem = () => {
    setLineItems([
      ...lineItems,
      {
        id: generateId(),
        quantity: 1,
        price: 0,
        discount: 0,
        discountEnabled: false,
      },
    ]);
  };

  const updateLineItem = (
    id: string,
    updates: Partial<InvoiceLineItemData>
  ) => {
    setLineItems(
      lineItems.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
  };

  const removeLineItem = (id: string) => {
    if (lineItems.length > 1) {
      setLineItems(lineItems.filter((item) => item.id !== id));
    }
  };

  // Calculate total
  const totalAmount = lineItems.reduce((total, item) => {
    const subtotal = item.price * item.quantity;
    const discountAmount = item.discountEnabled
      ? (subtotal * (item.discount || 0)) / 100
      : 0;
    const lineTotal = subtotal - discountAmount;
    return total + lineTotal;
  }, 0);

  async function handleOnSubmit(event: SyntheticEvent) {
    event.preventDefault();

    if (isSubmitting) {
      return;
    }
    setIsSubmitting(true);

    try {
      // Validate line items
      const items = lineItems.map((item) => ({
        productId: item.productId!,
        quantity: item.quantity,
        price: item.price,
        discount: item.discountEnabled ? item.discount : 0,
      }));

      if (!selectedCustomerId) {
        setError("Please select a customer");
        return;
      }

      const validatedData = createInvoiceSchema.parse({
        customerId: Number(selectedCustomerId),
        date: formatDateForApi(date),
        dueDate: formatDateForApi(dueDate),
        time: time,
        items: items,
        ...(selectedTaxId && { taxId: Number(selectedTaxId) }),
      });

      // If validation passes, proceed with the API call
      await createInvoice.mutateAsync(validatedData);
      setSuccess(true);
      setError(undefined);
      setTimeout(() => {
        router.push("/dashboard");
      }, 3000);
    } catch (error) {
      if (error instanceof z.ZodError) {
        // Handle Zod validation errors
        setError(error.errors.map((err) => `• ${err.message}`).join("\n"));
      } else if (axios.isAxiosError(error)) {
        const errors = error.response?.data;
        if (Array.isArray(errors)) {
          setError(errors.map((err: string) => `• ${err}`).join("\n"));
        } else {
          setError("An error occurred");
        }
      } else {
        setError("An unexpected error occurred");
      }
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <ProtectedRoute>
      <main className="pb-12">
        <Container>
          <div className="flex justify-between mb-6">
            <h1 className="text-3xl font-semibold">Create Invoice</h1>
          </div>

          {error && (
            <p className="max-w-xl bg-red-100 text-sm text-red-800 pl-8 pr-3 py-2 rounded-lg mb-6 whitespace-pre-line">
              {error}
            </p>
          )}
          {success && (
            <p className="max-w-xl bg-green-100 text-sm text-green-800 text-center px-3 py-2 rounded-lg mb-6">
              <strong>Invoice created successfully!</strong> Navigating back to
              dashboard...
            </p>
          )}

          <Form
            action="/dashboard"
            onSubmit={handleOnSubmit}
            className="grid gap-4"
          >
            {/* Basic Form Fields - Constrained Width */}
            <div className="max-w-xl space-y-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <Label
                    htmlFor="invoiceId"
                    className="block font-semibold text-sm mb-2"
                  >
                    Invoice Id
                  </Label>
                  <Input
                    id="invoiceId"
                    name="invoiceId"
                    type="text"
                    value={
                      isLoadingInvoiceNumber
                        ? "Loading..."
                        : nextInvoiceNumber?.invoiceNumber
                    }
                    disabled
                  />
                </div>
                <div className="flex-1" />
              </div>
              <div>
                <Label className="block font-semibold text-sm mb-2">
                  Customer
                </Label>
                <div className="flex gap-2">
                  <Popover
                    open={isCustomerOpen}
                    onOpenChange={setIsCustomerOpen}
                  >
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={isCustomerOpen}
                        className="flex-1 justify-between"
                      >
                        {selectedCustomerId
                          ? customers.find(
                              (customer) =>
                                customer.id.toString() === selectedCustomerId
                            )?.name
                          : "Select customer..."}
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0">
                      <Command>
                        <CommandInput placeholder="Search customers..." />
                        <CommandEmpty>No customer found.</CommandEmpty>
                        <CommandGroup>
                          {customers.map((customer) => (
                            <CommandItem
                              key={customer.id}
                              onSelect={() => {
                                const customerId = customer.id.toString();
                                setSelectedCustomerId(
                                  customerId === selectedCustomerId
                                    ? undefined
                                    : customerId
                                );
                                setIsCustomerOpen(false);
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  selectedCustomerId === customer.id.toString()
                                    ? "opacity-100"
                                    : "opacity-0"
                                )}
                              />
                              <div>
                                <div>{customer.name}</div>
                                <div className="text-sm text-gray-500">
                                  {customer.email}
                                </div>
                              </div>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  <CreateCustomerDialog
                    buttonVariant="icon"
                    onCustomerCreated={(customer) => {
                      setSelectedCustomerId(customer.id.toString());
                    }}
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-1">
                  <Label
                    htmlFor="date"
                    className="block font-semibold text-sm mb-2"
                  >
                    Date
                  </Label>
                  <DatePicker value={date} onChange={setDate} />
                </div>
                <div className="flex-1">
                  <Label
                    htmlFor="dueDate"
                    className="block font-semibold text-sm mb-2"
                  >
                    Due Date
                  </Label>
                  <DatePicker value={dueDate} onChange={setDueDate} />
                </div>
                <div className="flex-1">
                  <Label
                    htmlFor="time"
                    className="block font-semibold text-sm mb-2"
                  >
                    Time
                  </Label>
                  <TimePicker value={time} onChange={setTime} />
                </div>
              </div>
            </div>

            {/* Invoice Line Items Section - Full Width */}
            <div className="space-y-4 mt-8">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">Invoice Items</h2>
                <Button
                  type="button"
                  onClick={addLineItem}
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2"
                >
                  <Plus className="h-4 w-4" />
                  Add Item
                </Button>
              </div>

              <InvoiceLineItemsTable
                lineItems={lineItems}
                products={products}
                onUpdate={updateLineItem}
                onRemove={removeLineItem}
              />

              {/* Tax Selection */}
              <div className="border-t pt-4">
                <div className="max-w-md">
                  <Label className="block font-semibold text-sm mb-2">
                    Tax (Optional)
                  </Label>
                  <Popover open={isTaxOpen} onOpenChange={setIsTaxOpen}>
                    <PopoverTrigger asChild>
                      <Button
                        type="button"
                        variant="outline"
                        role="combobox"
                        aria-expanded={isTaxOpen}
                        className="w-full justify-between"
                      >
                        {selectedTaxId
                          ? taxes.find(
                              (tax) => tax.id.toString() === selectedTaxId
                            )?.name
                          : "Select tax..."}
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0">
                      <Command>
                        <CommandInput placeholder="Search taxes..." />
                        <CommandEmpty>No tax found.</CommandEmpty>
                        <CommandGroup>
                          <CommandItem
                            onSelect={() => {
                              setSelectedTaxId(undefined);
                              setIsTaxOpen(false);
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                !selectedTaxId ? "opacity-100" : "opacity-0"
                              )}
                            />
                            No tax
                          </CommandItem>
                          {taxes.map((tax) => (
                            <CommandItem
                              key={tax.id}
                              onSelect={() => {
                                setSelectedTaxId(tax.id.toString());
                                setIsTaxOpen(false);
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  selectedTaxId === tax.id.toString()
                                    ? "opacity-100"
                                    : "opacity-0"
                                )}
                              />
                              <div>
                                <div>{tax.name}</div>
                                <div className="text-sm text-gray-500">
                                  {tax.rate}% -{" "}
                                  {tax.description || "No description"}
                                </div>
                              </div>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* Total Display */}
              <div className="border-t pt-4">
                <div className="text-right space-y-2">
                  <div className="text-sm text-gray-600">
                    <span>
                      Subtotal: <CurrencyDisplay amount={totalAmount} />
                    </span>
                  </div>
                  {selectedTaxId && (
                    <div className="text-sm text-gray-600">
                      <span>
                        Tax (
                        {
                          taxes.find(
                            (tax) => tax.id.toString() === selectedTaxId
                          )?.rate
                        }
                        %):{" "}
                        <CurrencyDisplay
                          amount={
                            (totalAmount *
                              (taxes.find(
                                (tax) => tax.id.toString() === selectedTaxId
                              )?.rate || 0)) /
                            100
                          }
                        />
                      </span>
                    </div>
                  )}
                  <div className="text-lg font-semibold">
                    Total:{" "}
                    <CurrencyDisplay
                      amount={
                        totalAmount +
                        (selectedTaxId
                          ? (totalAmount *
                              (taxes.find(
                                (tax) => tax.id.toString() === selectedTaxId
                              )?.rate || 0)) /
                            100
                          : 0)
                      }
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6">
              <SubmitButton isSubmitting={isSubmitting} text="Create Invoice" />
            </div>
          </Form>
        </Container>
      </main>
    </ProtectedRoute>
  );
}
