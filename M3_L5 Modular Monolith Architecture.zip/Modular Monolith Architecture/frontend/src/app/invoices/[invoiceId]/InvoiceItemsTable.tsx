import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { CurrencyDisplay } from "@/components/CurrencyDisplay";
import { InvoiceItemResponse } from "@/app/invoices/hooks/useInvoice";

interface InvoiceItemsTableProps {
  items: InvoiceItemResponse[];
}

export function InvoiceItemsTable({ items }: InvoiceItemsTableProps) {
  if (!items || items.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        No items found for this invoice.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="font-bold text-lg">Invoice Items</h2>
      <div className="border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="p-4">Product</TableHead>
              <TableHead className="p-4 text-center">Quantity</TableHead>
              <TableHead className="p-4 text-right">Unit Price</TableHead>
              <TableHead className="p-4 text-center">Discount %</TableHead>
              <TableHead className="p-4 text-right">Line Total</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="p-4 font-medium">
                  {item.productName}
                </TableCell>
                <TableCell className="p-4 text-center">
                  {item.quantity}
                </TableCell>
                <TableCell className="p-4 text-right">
                  <CurrencyDisplay amount={item.price} />
                </TableCell>
                <TableCell className="p-4 text-center">
                  {item.discount ? `${item.discount}%` : "0%"}
                </TableCell>
                <TableCell className="p-4 text-right font-medium">
                  <CurrencyDisplay amount={item.lineTotal} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
