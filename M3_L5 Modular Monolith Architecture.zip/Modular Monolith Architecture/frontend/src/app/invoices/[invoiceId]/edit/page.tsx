﻿"use client";

import { useState, useEffect, use } from "react";
import { useRouter } from "next/navigation";
import { z } from "zod";
import { Check, ChevronsUpDown, Plus, LoaderCircle } from "lucide-react";

import useCustomers from "@/app/customers/hooks/useCustomers";
import { CreateCustomerDialog } from "@/app/customers/CreateCustomerDialog";
import { useUpdateInvoice } from "@/app/invoices/hooks/useUpdateInvoice";
import { useInvoice } from "@/app/invoices/hooks/useInvoice";
import useProducts from "@/app/products/hooks/useProducts";
import useTaxes from "@/app/settings/hooks/useTaxes";
import { ProtectedRoute } from "@/auth/ProtectedRoute";
import Container from "@/components/Container";
import { CurrencyDisplay } from "@/components/CurrencyDisplay";
import DatePicker from "@/components/DatePicker";
import { SubmitButton } from "@/components/SubmitButton";
import TimePicker from "@/components/TimePicker";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { updateInvoiceSchema } from "./updateInvoiceSchema";
import {
  InvoiceLineItemsTable,
  type InvoiceLineItemData,
} from "../../create/InvoiceLineItem";
import { formatDateForApi } from "@/lib/dateUtils";

interface UpdateInvoiceProps {
  params: Promise<{
    invoiceId: string;
  }>;
}

export default function UpdateInvoice({ params }: UpdateInvoiceProps) {
  const resolvedParams = use(params);
  const invoiceId = resolvedParams.invoiceId;

  const [error, setError] = useState<string>();
  const [success, setSuccess] = useState<boolean>();
  const [time, setTime] = useState("17:00");
  const [date, setDate] = useState(new Date());
  const [dueDate, setDueDate] = useState(
    new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
  ); // Default to 30 days from now
  const [isSubmitting, setIsSubmitting] = useState(false);
  const router = useRouter();

  const updateInvoice = useUpdateInvoice();
  const { data: invoice, isLoading: isLoadingInvoice } = useInvoice(invoiceId);

  const [selectedCustomerId, setSelectedCustomerId] = useState<string>();
  const [isCustomerOpen, setIsCustomerOpen] = useState(false);
  const [selectedTaxId, setSelectedTaxId] = useState<string>();
  const [isTaxOpen, setIsTaxOpen] = useState(false);
  const [lineItems, setLineItems] = useState<InvoiceLineItemData[]>([
    {
      id: crypto.randomUUID(),
      productId: undefined,
      quantity: 1,
      price: 0,
      discount: 0,
      discountEnabled: false,
    },
  ]);

  const { data: customers } = useCustomers(1, 1000);
  const { data: products } = useProducts(1, 1000);
  const { data: taxes } = useTaxes(1, 1000);

  // Initialize form with existing invoice data
  useEffect(() => {
    if (invoice) {
      setSelectedCustomerId(invoice.customerId?.toString());
      setDate(new Date(invoice.date));
      setDueDate(new Date(invoice.dueDate));
      setTime(invoice.time || "17:00");
      setSelectedTaxId(invoice.taxId?.toString());

      // Convert invoice items to line item format
      const existingLineItems: InvoiceLineItemData[] = invoice.items.map(
        (item) => ({
          id: item.id.toString(),
          productId: item.productId,
          quantity: item.quantity,
          price: item.price,
          discount: item.discount || 0,
          discountEnabled: (item.discount || 0) > 0,
        })
      );

      setLineItems(
        existingLineItems.length > 0
          ? existingLineItems
          : [
              {
                id: crypto.randomUUID(),
                productId: undefined,
                quantity: 1,
                price: 0,
                discount: 0,
                discountEnabled: false,
              },
            ]
      );
    }
  }, [invoice]);

  const handleAddLineItem = () => {
    setLineItems([
      ...lineItems,
      {
        id: crypto.randomUUID(),
        productId: undefined,
        quantity: 1,
        price: 0,
        discount: 0,
        discountEnabled: false,
      },
    ]);
  };

  const handleUpdateLineItem = (
    id: string,
    updates: Partial<InvoiceLineItemData>
  ) => {
    setLineItems(
      lineItems.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
  };

  const handleRemoveLineItem = (id: string) => {
    setLineItems(lineItems.filter((item) => item.id !== id));
  };

  const calculateSubtotal = () => {
    return lineItems.reduce((total, item) => {
      if (!item.productId) return total;
      const lineTotal = item.quantity * item.price;
      const discountAmount = item.discountEnabled
        ? (lineTotal * (item.discount || 0)) / 100
        : 0;
      return total + (lineTotal - discountAmount);
    }, 0);
  };

  const calculateTax = () => {
    const subtotal = calculateSubtotal();
    const selectedTax = taxes?.items?.find(
      (tax) => tax.id.toString() === selectedTaxId
    );
    return selectedTax ? (subtotal * selectedTax.rate) / 100 : 0;
  };

  const calculateTotal = () => {
    return calculateSubtotal() + calculateTax();
  };

  const handleOnSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(undefined);
    setSuccess(false);
    setIsSubmitting(true);

    try {
      // Validate line items
      const items = lineItems.map((item) => ({
        id: item.id !== crypto.randomUUID() ? parseInt(item.id) : undefined,
        productId: item.productId!,
        quantity: item.quantity,
        price: item.price,
        discount: item.discountEnabled ? item.discount : 0,
      }));

      if (!selectedCustomerId) {
        setError("Please select a customer");
        return;
      }

      const validatedData = updateInvoiceSchema.parse({
        customerId: Number(selectedCustomerId),
        date: formatDateForApi(date),
        dueDate: formatDateForApi(dueDate),
        time: time,
        items: items,
        ...(selectedTaxId && { taxId: Number(selectedTaxId) }),
      });

      await updateInvoice.mutateAsync({
        id: parseInt(invoiceId),
        request: validatedData,
      });

      setSuccess(true);
      router.push(`/invoices/${invoiceId}`);
    } catch (err) {
      if (err instanceof z.ZodError) {
        setError(err.errors.map((e) => e.message).join(", "));
      } else {
        setError("Failed to update invoice. Please try again.");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoadingInvoice) {
    return (
      <ProtectedRoute>
        <main className="my-12">
          <Container>
            <div className="flex items-center justify-center min-h-[200px]">
              <LoaderCircle className="animate-spin w-8 h-8 text-gray-400" />
            </div>
          </Container>
        </main>
      </ProtectedRoute>
    );
  }

  if (!invoice) {
    return (
      <ProtectedRoute>
        <main className="my-12">
          <Container>
            <div className="text-center">
              <h1 className="text-2xl font-bold text-red-600">
                Invoice not found
              </h1>
              <p className="text-gray-600 mt-2">
                The invoice you&apos;re looking for doesn&apos;t exist.
              </p>
            </div>
          </Container>
        </main>
      </ProtectedRoute>
    );
  }

  if (invoice.status !== "Draft") {
    return (
      <ProtectedRoute>
        <main className="my-12">
          <Container>
            <div className="text-center">
              <h1 className="text-2xl font-bold text-red-600">
                Cannot Edit Invoice
              </h1>
              <p className="text-gray-600 mt-2">
                Only draft invoices can be edited. This invoice has status:{" "}
                {invoice.status}
              </p>
              <Button
                className="mt-4"
                onClick={() => router.push(`/invoices/${invoiceId}`)}
              >
                View Invoice
              </Button>
            </div>
          </Container>
        </main>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute>
      <main>
        <Container>
          <div className="flex flex-col gap-8">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-bold">
                Edit Invoice {invoice.invoiceNumber}
              </h1>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                {error}
              </div>
            )}

            {success && (
              <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded">
                Invoice updated successfully!
              </div>
            )}

            <form onSubmit={handleOnSubmit} className="grid gap-4">
              {/* Basic Form Fields - Constrained Width */}
              <div className="max-w-xl space-y-4">
                <div className="flex gap-4">
                  <div className="flex-1">
                    <Label
                      htmlFor="invoiceId"
                      className="block font-semibold text-sm mb-2"
                    >
                      Invoice Id
                    </Label>
                    <Input
                      id="invoiceId"
                      name="invoiceId"
                      type="text"
                      value={invoice.invoiceNumber}
                      disabled
                      className="bg-gray-50"
                    />
                  </div>
                  <div className="flex-1">
                    <Label
                      htmlFor="date"
                      className="block font-semibold text-sm mb-2"
                    >
                      Date
                    </Label>
                    <DatePicker value={date} onChange={setDate} />
                  </div>
                  <div className="flex-1">
                    <Label
                      htmlFor="dueDate"
                      className="block font-semibold text-sm mb-2"
                    >
                      Due Date
                    </Label>
                    <DatePicker value={dueDate} onChange={setDueDate} />
                  </div>
                  <div className="flex-1">
                    <Label
                      htmlFor="time"
                      className="block font-semibold text-sm mb-2"
                    >
                      Time
                    </Label>
                    <TimePicker value={time} onChange={setTime} />
                  </div>
                </div>

                {/* Customer Selection */}
                <div>
                  <Label className="block font-semibold text-sm mb-2">
                    Customer
                  </Label>
                  <div className="flex gap-2">
                    <Popover
                      open={isCustomerOpen}
                      onOpenChange={setIsCustomerOpen}
                    >
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          role="combobox"
                          aria-expanded={isCustomerOpen}
                          className="flex-1 justify-between"
                        >
                          {selectedCustomerId
                            ? customers?.items?.find(
                                (customer) =>
                                  customer.id.toString() === selectedCustomerId
                              )?.name
                            : "Select customer..."}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-full p-0">
                        <Command>
                          <CommandInput placeholder="Search customers..." />
                          <CommandEmpty>No customer found.</CommandEmpty>
                          <CommandGroup>
                            {customers?.items?.map((customer) => (
                              <CommandItem
                                key={customer.id}
                                value={customer.name}
                                onSelect={() => {
                                  setSelectedCustomerId(customer.id.toString());
                                  setIsCustomerOpen(false);
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    selectedCustomerId ===
                                      customer.id.toString()
                                      ? "opacity-100"
                                      : "opacity-0"
                                  )}
                                />
                                {customer.name}
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </Command>
                      </PopoverContent>
                    </Popover>
                    <CreateCustomerDialog />
                  </div>
                </div>

                {/* Tax Selection */}
                <div>
                  <Label className="block font-semibold text-sm mb-2">
                    Tax (Optional)
                  </Label>
                  <Popover open={isTaxOpen} onOpenChange={setIsTaxOpen}>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={isTaxOpen}
                        className="w-full justify-between"
                      >
                        {selectedTaxId
                          ? taxes?.items?.find(
                              (tax) => tax.id.toString() === selectedTaxId
                            )?.name
                          : "Select tax..."}
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0">
                      <Command>
                        <CommandInput placeholder="Search taxes..." />
                        <CommandEmpty>No tax found.</CommandEmpty>
                        <CommandGroup>
                          <CommandItem
                            value="no-tax"
                            onSelect={() => {
                              setSelectedTaxId(undefined);
                              setIsTaxOpen(false);
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                !selectedTaxId ? "opacity-100" : "opacity-0"
                              )}
                            />
                            No Tax
                          </CommandItem>
                          {taxes?.items?.map((tax) => (
                            <CommandItem
                              key={tax.id}
                              value={tax.name}
                              onSelect={() => {
                                setSelectedTaxId(tax.id.toString());
                                setIsTaxOpen(false);
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  selectedTaxId === tax.id.toString()
                                    ? "opacity-100"
                                    : "opacity-0"
                                )}
                              />
                              {tax.name} ({tax.rate}%)
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* Line Items Section - Full Width */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">Invoice Items</h2>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleAddLineItem}
                    className="inline-flex items-center gap-2"
                  >
                    <Plus className="h-4 w-4" />
                    Add Item
                  </Button>
                </div>

                <InvoiceLineItemsTable
                  lineItems={lineItems}
                  products={products?.items || []}
                  onUpdate={handleUpdateLineItem}
                  onRemove={handleRemoveLineItem}
                />
              </div>

              {/* Summary Section */}
              <div className="flex justify-end">
                <div className="w-80 space-y-2 bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <CurrencyDisplay amount={calculateSubtotal()} />
                  </div>
                  {selectedTaxId && (
                    <div className="flex justify-between">
                      <span>
                        Tax (
                        {
                          taxes?.items?.find(
                            (tax) => tax.id.toString() === selectedTaxId
                          )?.name
                        }{" "}
                        -{" "}
                        {
                          taxes?.items?.find(
                            (tax) => tax.id.toString() === selectedTaxId
                          )?.rate
                        }
                        %):
                      </span>
                      <CurrencyDisplay amount={calculateTax()} />
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-lg border-t pt-2">
                    <span>Total:</span>
                    <CurrencyDisplay amount={calculateTotal()} />
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex justify-end">
                <SubmitButton
                  isSubmitting={isSubmitting}
                  text="Update Invoice"
                />
              </div>
            </form>
          </div>
        </Container>
      </main>
    </ProtectedRoute>
  );
}
