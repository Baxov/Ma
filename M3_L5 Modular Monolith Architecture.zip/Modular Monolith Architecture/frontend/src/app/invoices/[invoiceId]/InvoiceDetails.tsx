import { format } from "date-fns";
import Link from "next/link";
import { Edit } from "lucide-react";
import { CurrencyDisplay } from "@/components/CurrencyDisplay";
import { SingleInvoiceResponse } from "@/app/invoices/hooks/useInvoice";
import { InvoiceStatus } from "@/components/InvoiceStatus";
import { InvoiceItemsTable } from "./InvoiceItemsTable";
import { Button } from "@/components/ui/button";

interface InvoiceDetailsProps {
  invoice: SingleInvoiceResponse;
}

export function InvoiceDetails({ invoice }: InvoiceDetailsProps) {
  return (
    <div className="flex flex-col gap-8">
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-semibold">
              Invoice {invoice.invoiceNumber}
            </h1>
            <InvoiceStatus status={invoice.status} />
          </div>
          {invoice.status === "Draft" && (
            <Button
              asChild
              variant="outline"
              className="inline-flex items-center gap-2"
            >
              <Link href={`/invoices/${invoice.id}/edit`}>
                <Edit className="h-4 w-4" />
                Edit Invoice
              </Link>
            </Button>
          )}
        </div>
        <div className="space-y-2">
          <div className="text-sm text-gray-600">
            Subtotal: <CurrencyDisplay amount={invoice.subtotalAmount} />
          </div>
          {invoice.taxAmount > 0 && (
            <div className="text-sm text-gray-600">
              Tax ({invoice.taxName} - {invoice.taxRate}%):{" "}
              <CurrencyDisplay amount={invoice.taxAmount} />
            </div>
          )}
          <p className="text-3xl font-semibold">
            Total: <CurrencyDisplay amount={invoice.totalAmount} />
          </p>
        </div>
      </div>

      <div className="flex flex-col gap-6">
        <h2 className="font-bold text-lg">Invoice Details</h2>

        <ul className="grid gap-4">
          <li className="flex gap-8">
            <strong className="w-32 flex-shrink-0 font-medium text-gray-500">
              Invoice ID
            </strong>
            <span>{invoice.id}</span>
          </li>
          <li className="flex gap-8">
            <strong className="w-32 flex-shrink-0 font-medium text-gray-500">
              Invoice Date
            </strong>
            <span>{format(new Date(invoice.date), "dd.MM.yyyy.")}</span>
          </li>
          <li className="flex gap-8">
            <strong className="w-32 flex-shrink-0 font-medium text-gray-500">
              Due Date
            </strong>
            <span>{format(new Date(invoice.dueDate), "dd.MM.yyyy.")}</span>
          </li>
          <li className="flex gap-8">
            <strong className="w-32 flex-shrink-0 font-medium text-gray-500">
              Customer Name
            </strong>
            <span>{invoice.customerName}</span>
          </li>
          <li className="flex gap-8">
            <strong className="w-32 flex-shrink-0 font-medium text-gray-500">
              Customer Email
            </strong>
            <span>{invoice.customerEmail}</span>
          </li>
          {invoice.taxName && (
            <li className="flex gap-8">
              <strong className="w-32 flex-shrink-0 font-medium text-gray-500">
                Tax Applied
              </strong>
              <span>
                {invoice.taxName} ({invoice.taxRate}%)
              </span>
            </li>
          )}
        </ul>
      </div>

      {/* Invoice Items Table */}
      <InvoiceItemsTable items={invoice.items} />
    </div>
  );
}
