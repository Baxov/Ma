"use client";

import Container from "@/components/Container";
import { InvoiceDetails } from "./InvoiceDetails";
import { useInvoice } from "@/app/invoices/hooks/useInvoice";
import { LoaderCircle } from "lucide-react";
import { use } from "react";
import { ProtectedRoute } from "@/auth/ProtectedRoute";

interface ViewInvoiceProps {
  params: Promise<{
    invoiceId: string;
  }>;
}

export default function ViewInvoice({ params }: ViewInvoiceProps) {
  const resolvedParams = use(params);
  const { data: invoice, isLoading } = useInvoice(resolvedParams.invoiceId);

  if (isLoading) {
    return (
      <main className="my-12">
        <Container>
          <div className="flex items-center justify-center min-h-[200px]">
            <LoaderCircle className="animate-spin w-8 h-8 text-gray-400" />
          </div>
        </Container>
      </main>
    );
  }

  return (
    <ProtectedRoute>
      <main>
        <Container>
          {invoice && <InvoiceDetails invoice={invoice} />}
        </Container>
      </main>
    </ProtectedRoute>
  );
}
