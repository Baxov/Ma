"use client";

import { useAuth } from "@/auth/authContext";
import { Header } from "@/components/Header";

export function ClientLayout({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();

  return (
    <div className="min-h-screen grid grid-rows-[auto_1fr_auto]">
      {user && <Header />}
      {children}
    </div>
  );
}
