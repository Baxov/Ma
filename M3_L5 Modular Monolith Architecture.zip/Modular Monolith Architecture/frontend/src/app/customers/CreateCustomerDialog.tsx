"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CirclePlus } from "lucide-react";
import ApiClient from "@/services/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AxiosError } from "axios";

interface CreateCustomerRequest {
  name: string;
  email: string;
}

interface CreateCustomerResponse {
  id: number;
  name: string;
  email: string;
}

interface CreateCustomerDialogProps {
  onCustomerCreated?: (customer: CreateCustomerResponse) => void;
  buttonVariant?: "full" | "icon";
}

export function CreateCustomerDialog({ onCustomerCreated, buttonVariant = "full" }: CreateCustomerDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault(); // Add this line to prevent form navigation
    setIsSubmitting(true);

    try {
      const client = new ApiClient<CreateCustomerResponse>("/api/customers");
      const response = await client.post<CreateCustomerRequest>({ name, email });

      await queryClient.invalidateQueries({ queryKey: ["customers"] });

      toast({
        title: "Success",
        description: "Customer created successfully",
      });

      // Call the callback with the created customer
      if (onCustomerCreated && response) {
        onCustomerCreated(response);
      }

      setOpen(false);
      setName("");
      setEmail("");
    } catch (error) {
      if (error instanceof AxiosError) {
        toast({
          variant: "destructive",
          title: "Error",
          description: error.response?.data || "Failed to create customer",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to create customer",
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          type="button" // Add this to prevent form submission
          className={buttonVariant === "icon" ? "px-3" : "inline-flex gap-2 bg-blue-600 hover:bg-blue-700"}
          variant={buttonVariant === "icon" ? "outline" : "default"}
          onClick={(e) => {
            e.preventDefault(); // Prevent any default navigation
            setOpen(true);
          }}
        >
          <CirclePlus className="h-4 w-4" />
          {buttonVariant === "full" && "Create Customer"}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create New Customer</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter customer name"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter customer email"
              required
            />
          </div>
          <div className="flex justify-end">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSubmitting ? "Creating..." : "Create Customer"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
