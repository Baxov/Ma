import Container from "@/components/Container";
import { ProtectedRoute } from "@/auth/ProtectedRoute";
import { CustomerTable } from "./CustomerTable";
import { CreateCustomerDialog } from "./CreateCustomerDialog";

export default function CustomersPage() {
  return (
    <ProtectedRoute>
      <main>
        <Container>
          <div className="flex flex-col gap-6">
            <div className="flex justify-between">
              <h1 className="text-3xl font-bold">Customers</h1>
              <CreateCustomerDialog />
            </div>
            <CustomerTable />
          </div>
        </Container>
      </main>
    </ProtectedRoute>
  );
}
