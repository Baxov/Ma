"use client";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { LoaderCircle, Trash, Pencil, FileText } from "lucide-react";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { TablePagination } from "@/components/TablePagination";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";

import useCustomers from "./hooks/useCustomers";
import ApiClient from "@/services/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AxiosError } from "axios";
import { EditCustomerDialog } from "./EditCustomerDialog";

export function CustomerTable() {
  const { toast } = useToast();
  const router = useRouter();
  const queryClient = useQueryClient();
  const pageSize = 10;
  const [page, setPage] = useState(1);
  const [editingCustomerId, setEditingCustomerId] = useState<number | null>(
    null
  );

  const { data, isLoading } = useCustomers(page, pageSize);
  const { items: customers, totalCount } = data || {
    items: [],
    totalCount: 0,
  };

  const handleDelete = async (id: number) => {
    try {
      const client = new ApiClient<void>("/api/customers");
      await client.delete(id);
      await queryClient.invalidateQueries({ queryKey: ["customers"] });
      toast({
        title: "Success",
        description: "Customer deleted successfully",
      });
    } catch (error) {
      if (error instanceof AxiosError) {
        toast({
          variant: "destructive",
          title: "Error",
          description: error.response?.data || "Failed to delete customer",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to delete customer",
        });
      }
    }
  };

  if (isLoading)
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <LoaderCircle className="animate-spin w-8 h-8 text-gray-400" />
      </div>
    );

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="p-4">Name</TableHead>
            <TableHead className="p-4">Email</TableHead>
            <TableHead className="p-4">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {customers?.map((customer) => (
            <TableRow key={customer.id}>
              <TableCell className="font-medium text-left p-4">
                <span>{customer.name}</span>
              </TableCell>
              <TableCell className="text-left p-4">
                <span>{customer.email}</span>
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button className="bg-gray-50" variant="outline">
                      Actions
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-gray-50">
                    <DropdownMenuItem>
                      <button
                        className="w-full flex items-center gap-2"
                        onClick={() => router.push(`/customer-statements/${customer.id}`)}
                      >
                        <FileText className="h-4 w-4" />
                        View Statement
                      </button>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <button
                        className="w-full flex items-center gap-2"
                        onClick={() => setEditingCustomerId(customer.id)}
                      >
                        <Pencil className="h-4 w-4" />
                        Edit
                      </button>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <button
                        className="w-full flex items-center gap-2 text-red-600"
                        onClick={() => handleDelete(customer.id)}
                      >
                        <Trash className="h-4 w-4" />
                        Delete
                      </button>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <TablePagination
        page={page}
        pageSize={pageSize}
        totalCount={totalCount}
        onPageChange={setPage}
      />
      {editingCustomerId && (
        <EditCustomerDialog
          customer={customers.find((c) => c.id === editingCustomerId)!}
          open={true}
          onOpenChange={(open) =>
            setEditingCustomerId(open ? editingCustomerId : null)
          }
        />
      )}
    </>
  );
}
