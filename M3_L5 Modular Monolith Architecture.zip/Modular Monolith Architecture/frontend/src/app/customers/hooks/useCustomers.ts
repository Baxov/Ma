import ApiClient from "@/services/apiClient";
import { useQuery } from "@tanstack/react-query";

export interface CustomerResponse {
  id: number;
  name: string;
  email: string;
}

export interface PagedResponse<T> {
  items: T[];
  totalCount: number;
}

const TEN_SECONDS = 10 * 1000;

const useCustomers = (page: number, pageSize: number) => {
  const fetchCustomers = async () => {
    const customerClient = new ApiClient<PagedResponse<CustomerResponse>>("/api/customers");
    return await customerClient.getAll({
      page,
      pageSize,
    });
  };

  return useQuery({
    queryKey: ["customers", page],
    queryFn: fetchCustomers,
    staleTime: TEN_SECONDS,
  });
};

export default useCustomers;