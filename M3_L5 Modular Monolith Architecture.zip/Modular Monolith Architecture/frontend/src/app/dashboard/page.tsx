import { Button } from "@/components/ui/button";
import { CirclePlus } from "lucide-react";
import Link from "next/link";
import { InvoiceTable } from "./InvoiceTable";
import Container from "@/components/Container";
import { ProtectedRoute } from "@/auth/ProtectedRoute";

export default function Home() {
  return (
    <ProtectedRoute>
      <main>
        <Container>
          <div className="flex flex-col gap-6">
            <div className="flex justify-between">
              <h1 className="text-3xl font-bold">Invoices</h1>
              <Button
                className="inline-flex gap-2 bg-blue-600 hover:bg-blue-700"
                asChild
              >
                <Link href="invoices/create">
                  <CirclePlus className="h-4 w-4" />
                  Create Invoice
                </Link>
              </Button>
            </div>
            <InvoiceTable />
          </div>
        </Container>
      </main>
    </ProtectedRoute>
  );
}
