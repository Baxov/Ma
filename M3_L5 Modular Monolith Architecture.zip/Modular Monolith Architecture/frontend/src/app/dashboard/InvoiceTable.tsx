"use client";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format } from "date-fns";
import { LoaderCircle, Search } from "lucide-react";
import useInvoices from "@/app/invoices/hooks/useInvoices";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { TablePagination } from "@/components/TablePagination";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { CurrencyDisplay } from "@/components/CurrencyDisplay";
import { InvoiceStatus } from "@/components/InvoiceStatus";
import { useUpdateInvoiceStatus } from "@/app/invoices/hooks/useUpdateInvoiceStatus";
import { useSendInvoice } from "@/app/invoices/hooks/useSendInvoice";
import { useToast } from "@/hooks/use-toast";
import { axiosInstance } from "@/services/apiClient";

export function InvoiceTable() {
  const pageSize = 10;
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const { toast } = useToast();

  // Debounce search input to avoid too many API calls
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search);
      setPage(1); // Reset to first page when searching
    }, 600);

    return () => clearTimeout(timer);
  }, [search]);

  const { data, isLoading } = useInvoices(page, pageSize, debouncedSearch);
  const updateInvoiceStatus = useUpdateInvoiceStatus();
  const sendInvoice = useSendInvoice();

  const { items: invoices, totalCount } = data || {
    items: [],
    totalCount: 0,
  };

  const handleStatusUpdate = async (
    invoiceId: number,
    status: "Sent" | "Paid"
  ) => {
    try {
      await updateInvoiceStatus.mutateAsync({ invoiceId, status });
      toast({
        title: "Success",
        description: `Invoice marked as ${status.toLowerCase()}`,
      });
    } catch {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to update invoice status`,
      });
    }
  };

  const handleSendInvoice = async (invoiceId: number) => {
    try {
      await sendInvoice.mutateAsync(invoiceId);
    } catch {
      // Error handling is done in the hook
    }
  };

  const handleDownloadPdf = async (invoiceId: number) => {
    try {
      const response = await axiosInstance.get(
        `/api/invoices/${invoiceId}/pdf`,
        {
          responseType: "blob",
        }
      );

      // Create blob link to download
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `invoice-${invoiceId}.pdf`);

      // Append to html link element page
      document.body.appendChild(link);

      // Start download
      link.click();

      // Clean up and remove the link
      link.parentNode?.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: "Success",
        description: "PDF downloaded successfully",
      });
    } catch {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to download PDF",
      });
    }
  };

  if (isLoading)
    return (
      <>
        <div className="flex items-center justify-center min-h-[200px]">
          <LoaderCircle className="animate-spin w-8 h-8 text-gray-400" />
        </div>
      </>
    );

  return (
    <div className="mb-8">
      <div className="flex items-center gap-2 mb-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search invoices..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="p-4">Invoice Id</TableHead>
            <TableHead className="p-4">Date</TableHead>
            <TableHead className="p-4">Customer</TableHead>
            <TableHead className="p-4">Email</TableHead>
            <TableHead className="text-center p-4">Status</TableHead>
            <TableHead className="text-right p-4">Amount</TableHead>
            <TableHead className="text-center p-4">Tax</TableHead>
            <TableHead className="p-4">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {invoices?.map((invoice) => (
            <TableRow key={invoice.id}>
              <TableCell className="font-medium text-left p-4">
                <span className="font-semibold">{invoice.invoiceNumber}</span>
              </TableCell>
              <TableCell className="font-medium text-left p-4">
                <span className="font-semibold">
                  {format(new Date(invoice.date), "dd.MM.yyyy.")}
                </span>
              </TableCell>
              <TableCell className="text-left p-4">
                <span>{invoice.customerName}</span>
              </TableCell>
              <TableCell className="text-left p-4">
                <span>{invoice.customerEmail}</span>
              </TableCell>
              <TableCell className="text-center p-4">
                <InvoiceStatus status={invoice.status} />
              </TableCell>
              <TableCell className="text-right p-4">
                <div className="space-y-1">
                  <div>
                    <CurrencyDisplay amount={invoice.totalAmount} />
                  </div>
                  {invoice.taxAmount > 0 && (
                    <div className="text-xs text-gray-500">
                      (incl. <CurrencyDisplay amount={invoice.taxAmount} /> tax)
                    </div>
                  )}
                </div>
              </TableCell>
              <TableCell className="text-center p-4">
                {invoice.taxName ? (
                  <div className="text-xs">
                    <div className="font-medium">{invoice.taxName}</div>
                    <div className="text-gray-500">{invoice.taxRate}%</div>
                  </div>
                ) : (
                  <span className="text-gray-400">-</span>
                )}
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button className="bg-gray-50" variant="outline">
                      Actions
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-gray-50">
                    <DropdownMenuItem className="cursor-pointer">
                      <Link className="w-full" href={`/invoices/${invoice.id}`}>
                        View
                      </Link>
                    </DropdownMenuItem>
                    {invoice.status === "Draft" && (
                      <DropdownMenuItem className="cursor-pointer">
                        <Link className="w-full" href={`/invoices/${invoice.id}/edit`}>
                          Edit
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem
                      className="cursor-pointer"
                      onClick={() => handleStatusUpdate(invoice.id, "Sent")}
                    >
                      Mark as Sent
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      className="cursor-pointer"
                      onClick={() => handleStatusUpdate(invoice.id, "Paid")}
                    >
                      Mark as Paid
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      className="cursor-pointer"
                      onClick={() => handleSendInvoice(invoice.id)}
                      disabled={sendInvoice.isPending}
                    >
                      {sendInvoice.isPending ? "Sending..." : "Email invoice"}
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      className="cursor-pointer"
                      onClick={() => handleDownloadPdf(invoice.id)}
                    >
                      Download PDF
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <TablePagination
        page={page}
        pageSize={pageSize}
        totalCount={totalCount}
        onPageChange={setPage}
      />
    </div>
  );
}
