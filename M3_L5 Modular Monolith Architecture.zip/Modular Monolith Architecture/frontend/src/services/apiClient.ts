import axios from "axios";
import { tokenService } from "./tokenService";

const axiosInstance = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || "http://localhost:5080",
});

// Request interceptor to add access token
axiosInstance.interceptors.request.use((config) => {
  const accessToken = tokenService.getAccessToken();
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`;
  }
  return config;
});

// Response interceptor to handle token refresh
let isRefreshing = false;
let failedQueue: Array<{
  resolve: (value?: unknown) => void;
  reject: (error?: unknown) => void;
}> = [];

const processQueue = (error: unknown, token: string | null = null) => {
  failedQueue.forEach(({ resolve, reject }) => {
    if (error) {
      reject(error);
    } else {
      resolve(token);
    }
  });

  failedQueue = [];
};

// Auth endpoints that should not trigger token refresh on 401
const authEndpoints = ['/api/login', '/api/register', '/api/refresh-token', '/api/forgot-password', '/api/reset-password'];

axiosInstance.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    const requestUrl = originalRequest?.url || '';

    // Skip token refresh logic for auth endpoints - let them handle their own 401s
    const isAuthEndpoint = authEndpoints.some(endpoint => requestUrl.includes(endpoint));
    if (isAuthEndpoint) {
      return Promise.reject(error);
    }

    if (error.response?.status === 401 && !originalRequest._retry) {
      if (isRefreshing) {
        // If already refreshing, queue this request
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then(() => {
          originalRequest.headers.Authorization = `Bearer ${tokenService.getAccessToken()}`;
          return axiosInstance(originalRequest);
        }).catch(err => {
          return Promise.reject(err);
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const newTokenData = await tokenService.refreshTokens();
        if (newTokenData) {
          processQueue(null, newTokenData.accessToken);
          originalRequest.headers.Authorization = `Bearer ${newTokenData.accessToken}`;
          return axiosInstance(originalRequest);
        } else {
          throw new Error("Token refresh failed");
        }
      } catch (refreshError) {
        processQueue(refreshError, null);
        tokenService.clearTokens();
        // Redirect to login will be handled by the auth context
        window.location.href = "/login";
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  }
);

// Create a function to handle unauthorized responses (legacy support)
export const setupUnauthorizedResponseHandler = () => {
  // The response interceptor above already handles 401s with token refresh
  // This function is kept for backward compatibility but doesn't need to do anything
};

interface QueryParams {
  [key: string]: string | number | boolean | undefined;
}

class ApiClient<T> {
  endpoint: string;

  constructor(endpoint: string) {
    this.endpoint = endpoint;
  }

  getAll = async (params?: QueryParams) => {
    const response = await axiosInstance.get<T>(this.endpoint, {
      params,
    });
    return response.data;
  };

  get = async () => {
    const response = await axiosInstance.get<T>(this.endpoint);
    return response.data;
  };

  getById = async (id: number | string) => {
    const response = await axiosInstance.get<T>(`${this.endpoint}/${id}`);
    return response.data;
  };

  post = async <TRequest>(data: TRequest) => {
    const response = await axiosInstance.post<T>(this.endpoint, data);
    return response.data;
  };

  put = async <TRequest>(id: number | string, data: TRequest) => {
    const response = await axiosInstance.put<T>(`${this.endpoint}/${id}`, data);
    return response.data;
  };

  // PUT without ID for endpoints that don't require an ID
  putWithoutId = async <TRequest>(data: TRequest) => {
    const response = await axiosInstance.put<T>(this.endpoint, data);
    return response.data;
  };

  delete = async (id: number | string) => {
    const response = await axiosInstance.delete(`${this.endpoint}/${id}`);
    return response.data;
  };
}

export default ApiClient;
export { axiosInstance };
