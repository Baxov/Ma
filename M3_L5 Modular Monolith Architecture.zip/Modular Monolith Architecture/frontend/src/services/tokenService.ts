﻿import { RefreshTokenRequest, RefreshTokenResponse } from "@/auth/auth";

export interface TokenData {
  accessToken: string;
  refreshToken: string;
  userId: string;
}

class TokenService {
  private static readonly ACCESS_TOKEN_KEY = "accessToken";
  private static readonly REFRESH_TOKEN_KEY = "refreshToken";
  private static readonly USER_ID_KEY = "userId";

  // Store tokens in localStorage
  setTokens(tokenData: TokenData): void {
    console.log("TokenService: setTokens called with:", tokenData);
    console.log("TokenService: Setting accessToken with key:", TokenService.ACCESS_TOKEN_KEY);
    localStorage.setItem(TokenService.ACCESS_TOKEN_KEY, tokenData.accessToken);
    localStorage.setItem(
      TokenService.REFRESH_TOKEN_KEY,
      tokenData.refreshToken
    );
    localStorage.setItem(TokenService.USER_ID_KEY, tokenData.userId);
    console.log("TokenService: Tokens stored successfully");
    console.log("TokenService: Verification - accessToken:", localStorage.getItem(TokenService.ACCESS_TOKEN_KEY));
  }

  // Get access token
  getAccessToken(): string | null {
    return localStorage.getItem(TokenService.ACCESS_TOKEN_KEY);
  }

  // Get refresh token
  getRefreshToken(): string | null {
    return localStorage.getItem(TokenService.REFRESH_TOKEN_KEY);
  }

  // Get user ID
  getUserId(): string | null {
    return localStorage.getItem(TokenService.USER_ID_KEY);
  }

  // Get all token data
  getTokenData(): TokenData | null {
    const accessToken = this.getAccessToken();
    const refreshToken = this.getRefreshToken();
    const userId = this.getUserId();

    if (!accessToken || !refreshToken || !userId) {
      return null;
    }

    return {
      accessToken,
      refreshToken,
      userId,
    };
  }

  // Clear all tokens
  clearTokens(): void {
    localStorage.removeItem(TokenService.ACCESS_TOKEN_KEY);
    localStorage.removeItem(TokenService.REFRESH_TOKEN_KEY);
    localStorage.removeItem(TokenService.USER_ID_KEY);
    // Also clear legacy token for backward compatibility
    localStorage.removeItem("token");
    localStorage.removeItem("user");
  }

  // Check if tokens exist
  hasTokens(): boolean {
    return !!(
      this.getAccessToken() &&
      this.getRefreshToken() &&
      this.getUserId()
    );
  }

  // Refresh tokens using the refresh token
  async refreshTokens(): Promise<TokenData | null> {
    const refreshToken = this.getRefreshToken();
    const userId = this.getUserId();

    if (!refreshToken || !userId) {
      return null;
    }

    try {
      const response = await fetch("http://localhost:8080/api/refresh-token", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId,
          refreshToken,
        } as RefreshTokenRequest),
      });

      if (!response.ok) {
        throw new Error("Failed to refresh token");
      }

      const data: RefreshTokenResponse = await response.json();

      const newTokenData: TokenData = {
        accessToken: data.accessToken,
        refreshToken: data.refreshToken,
        userId: data.userId,
      };

      // Store the new tokens
      this.setTokens(newTokenData);

      return newTokenData;
    } catch (error) {
      console.error("Token refresh failed:", error);
      // Clear tokens if refresh fails
      this.clearTokens();
      return null;
    }
  }

  // Check if access token is expired (basic check)
  isAccessTokenExpired(): boolean {
    const token = this.getAccessToken();
    if (!token) return true;

    try {
      // Decode JWT payload (basic decode without verification)
      const payload = JSON.parse(atob(token.split(".")[1]));
      const currentTime = Math.floor(Date.now() / 1000);

      // Check if token is expired (with 30 second buffer)
      return payload.exp < currentTime + 30;
    } catch (error) {
      console.error("Error checking token expiration:", error);
      return true;
    }
  }
}

export const tokenService = new TokenService();
