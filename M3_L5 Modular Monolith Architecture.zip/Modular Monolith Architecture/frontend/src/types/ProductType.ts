﻿export enum ProductType {
  Product = "Product",
  Service = "Service",
}

export const ProductTypeLabels = {
  [ProductType.Product]: 'Product',
  [ProductType.Service]: 'Service',
} as const;
