﻿/**
 * Formats a Date object to YYYY-MM-DD format for API requests
 * @param date The Date object to format
 * @returns A string in YYYY-MM-DD format
 */
export function formatDateForApi(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Formats a Date object to YYYY-MM-DD format for API requests, returns undefined if date is null/undefined
 * @param date The Date object to format or undefined
 * @returns A string in YYYY-MM-DD format or undefined
 */
export function formatOptionalDateForApi(date: Date | undefined): string | undefined {
  return date ? formatDateForApi(date) : undefined;
}
