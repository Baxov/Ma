"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { LoginRequest, LoginResponse } from "./auth";
import { authService } from "../app/login/authService";
import { tokenService } from "@/services/tokenService";

interface AuthContextType {
  user: LoginResponse | null;
  login: (data: LoginRequest) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<LoginResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    // Load user from token service on initial mount
    const tokenData = tokenService.getTokenData();

    if (tokenData) {
      // Create user object from token data
      const userData: LoginResponse = {
        userId: tokenData.userId,
        accessToken: tokenData.accessToken,
        refreshToken: tokenData.refreshToken,
      };
      setUser(userData);
    } else {
      // Check for legacy token storage and migrate
      const legacyUser = localStorage.getItem("user");
      const legacyToken = localStorage.getItem("token");

      if (legacyUser && legacyToken) {
        try {
          // Clear legacy storage
          localStorage.removeItem("user");
          localStorage.removeItem("token");

          // If it's the old format, user needs to login again
          console.log("Legacy token format detected, please login again");
        } catch (error) {
          console.error("Failed to parse legacy user data", error);
          localStorage.removeItem("user");
          localStorage.removeItem("token");
        }
      }
    }

    setIsLoading(false);
  }, []);

  const login = async (data: LoginRequest) => {
    try {
      const response = await authService.login(data);
      setUser(response);

      // Store tokens using token service
      tokenService.setTokens({
        accessToken: response.accessToken,
        refreshToken: response.refreshToken,
        userId: response.userId,
      });

      router.push("/dashboard"); // Redirect to dashboard after login
    } catch (error) {
      throw error;
    }
  };

  const logout = async () => {
    try {
      // Clear the user state
      setUser(null);

      // Call the auth service logout (which will clear tokens)
      await authService.logout();

      // Finally redirect
      router.push("/login");
    } catch (error) {
      console.error("Logout error:", error);
      // Make sure we still clear everything even if there's an error
      setUser(null);
      tokenService.clearTokens();
      router.push("/login");
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
